# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>NumPy Basics</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 NumPy Basics.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Grundkonzepte von NumPy

# %% tags=["keep"]
import numpy as np

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Vektoren

# %% tags=["keep"]
v1 = np.array([3.0, 2.1, 4.2])
v2 = np.array([8.0, 8.9, 6.8])

# %%
v1

# %%
type(v1)

# %%
v1.dtype

# %%
v1.shape

# %% tags=["keep"]
v3 = np.array([1, 2, 3])

# %%
v3.dtype

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Rechnen mit Vektoren
#
# ### Grundlegende Operationen

# %%
v1 + v2

# %%
v1 - v2

# %%
v1 * v2

# %%
v1.dot(v2)

# %%
v1 @ v2

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Maximum und Minimum

# %%
v1.max()

# %%
v1.min()

# %%
v1

# %%
v1.argmax()

# %%
v1.argmin()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Aggregatfunktionen und Statistik

# %%
v1.sum()

# %%
v1.mean()

# %%
v1.std()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Matrizen

# %% tags=["keep"]
m1 = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
m1

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Form von Matrizen und Transposition

# %%
m1.shape

# %%
m1

# %%
m1.T

# %%
m1.T.shape

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Indizieren von Matrizen

# %% tags=["keep"]
m1 = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
m1

# %%
m1[1]

# %%
m1[1, 1]

# %%
m1[:, 0]

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Rechnen mit Matrizen

# %% tags=["keep"]
m1 = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
m1

# %% tags=["keep"]
m2 = np.array([[1.0, 0.0], [0.0, 1.0], [2.0, 3.0]])
m2

# %%
m1 + m1

# %%
m2 + m2

# %%
# m1 + m2

# %%
m1.T + m2

# %%
m1 + m2.T

# %%
# m1 * m2

# %%
m1.T * m2

# %%
m1.dot(m2)

# %%
m1 @ m2

# %%
m2 @ m1

# %%
m1

# %%
m1.sum()

# %%
m1.sum(axis=0)

# %%
m1.sum(axis=1)
