# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Glückszahl 7 mit MNIST</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">07 Glückszahl 7 mit MNIST.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Glückszahl 7 mit MNIST

# %%
from sklearn.metrics import classification_report
import sklearn.metrics as metrics
import pickle

import matplotlib.pyplot as plt
import numpy as np

# %% tags=["keep"]
with open("mnist.pkl", "rb") as mnist_file:
    mnist_data = pickle.load(mnist_file)

# %% tags=["keep"]
x_train = mnist_data["x_train"]
x_test = mnist_data["x_test"]
y_train = mnist_data["y_train"]
y_test = mnist_data["y_test"]

# %%
lucky7_train = y_train == 7
lucky7_test = y_test == 7

# %%
lucky7_test[:3], y_test[:3]

# %%
plt.imshow(x_test[0].reshape(28, 28), cmap="binary")

# %%
from sklearn.linear_model import SGDClassifier  # noqa: E402

# %%
sgd_clf = SGDClassifier(random_state=42)

# %%
sgd_clf.fit(x_train, lucky7_train)

# %%
sgd_clf.predict([x_test[0]])

# %%
sgd_clf.predict(x_test[:3])

# %%
lucky7_predict = sgd_clf.predict(x_test)

# %%
correct_predictions = lucky7_predict == lucky7_test

# %%
correct_predictions[:10]

# %%
np.sum(correct_predictions)

# %%
from sklearn.metrics import (  # noqa: E402
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    precision_score,
)

# %%
accuracy_score(lucky7_test, lucky7_predict)

# %%
balanced_accuracy_score(lucky7_test, lucky7_predict)

# %%
precision_score(lucky7_test, lucky7_predict)

# %%
f1_score(lucky7_test, lucky7_predict)

# %%
metrics.confusion_matrix(lucky7_predict, lucky7_test)

# %%
metrics.ConfusionMatrixDisplay.from_predictions(lucky7_predict, lucky7_test)
plt.show()

# %% tags=["alt"]
metrics.ConfusionMatrixDisplay.from_predictions(lucky7_predict, lucky7_test, cmap="brg")
plt.show()

# %% tags=["alt"]
metrics.ConfusionMatrixDisplay.from_predictions(
    lucky7_predict, lucky7_test, cmap="winter"
)
plt.show()

# %% tags=["alt"]
metrics.ConfusionMatrixDisplay.from_predictions(
    lucky7_predict, lucky7_test, cmap="bwr_r"
)
plt.show()

# %%
metrics.ConfusionMatrixDisplay.from_predictions(
    lucky7_predict, lucky7_test, normalize="pred"
)
plt.show()

# %%
metrics.ConfusionMatrixDisplay.from_predictions(
    lucky7_predict, lucky7_test, normalize="true"
)
plt.show()

# %%
print(classification_report(lucky7_predict, lucky7_test))

# %% tags=["alt"]
metrics.ConfusionMatrixDisplay.from_predictions(lucky7_predict, lucky7_test, cmap="brg")
plt.show()

# %%
from sklearn.tree import DecisionTreeClassifier  # noqa: E402

# %%
dt_clf = DecisionTreeClassifier(max_depth=3)

# %%
dt_clf.fit(x_train, lucky7_train)

# %%
lucky7_predict_dt = dt_clf.predict(x_test)

# %%
print(classification_report(lucky7_predict_dt, lucky7_test))

# %%
metrics.ConfusionMatrixDisplay.from_predictions(
    lucky7_predict_dt, lucky7_test, normalize="pred"
)
plt.show()

# %%
metrics.ConfusionMatrixDisplay.from_predictions(lucky7_predict_dt, lucky7_test)
plt.show()

# %%
dt_clf2 = DecisionTreeClassifier(min_samples_leaf=10)

# %%
dt_clf2.fit(x_train, lucky7_train)

# %%
lucky7_predict_dt2 = dt_clf2.predict(x_test)

# %%
print(classification_report(lucky7_predict_dt2, lucky7_test))

# %%
metrics.ConfusionMatrixDisplay.from_predictions(
    lucky7_predict_dt2, lucky7_test, normalize="pred"
)
plt.show()

# %%
from sklearn.ensemble import RandomForestClassifier  # noqa: E402

# %%
rf_clf = RandomForestClassifier(random_state=42, n_estimators=200, n_jobs=128)

# %%
rf_clf.fit(x_train, lucky7_train)

# %%
lucky7_predict_rf = rf_clf.predict(x_test)

# %%
print(classification_report(lucky7_predict_rf, lucky7_test))

# %%
metrics.ConfusionMatrixDisplay.from_predictions(
    lucky7_predict_rf, lucky7_test, normalize="pred"
)
plt.show()

# %%
from sklearn.model_selection import RandomizedSearchCV

# %%
parameters = {
    "n_estimators": [400],
    "min_samples_split": [2, 8],
    "min_samples_leaf": [1, 4],
    "max_leaf_nodes": [None, 100],
    "max_features": ["sqrt", 16, 64, 128],
}

# %% tags=["alt"]
# Original values:
# parameters = {
#     "n_estimators": [100],
#     "min_samples_split": [2, 4, 8],
#     "min_samples_leaf": [1, 4, 16],
#     "max_leaf_nodes": [None, 100, 1000],
#     "max_features": ["sqrt", None, 64, 128],
# }

# %%
best_parameters = {
    "n_estimators": 400,
    "min_samples_split": 2,
    "min_samples_leaf": 1,
    "max_leaf_nodes": None,
    "max_features": 64,
}

# %%
rs_rf = RandomForestClassifier(n_jobs=16)

# %%
rs_clf = RandomizedSearchCV(rs_rf, parameters, cv=3, n_iter=20, n_jobs=12)

# %%
RANDOM_SEARCH_SAMPLES = 60_000

# %%
rs_clf.fit(x_train[:RANDOM_SEARCH_SAMPLES], lucky7_train[:RANDOM_SEARCH_SAMPLES])

# %%
lucky7_predict_rs = rs_clf.predict(x_test)

# %%
print(classification_report(lucky7_predict_rs, lucky7_test))

# %%
metrics.ConfusionMatrixDisplay.from_predictions(
    lucky7_predict_rs, lucky7_test, normalize="pred"
)
plt.show()

# %%
rs_clf.best_params_

# %%
from sklearn.base import BaseEstimator  # noqa: E402


# %%
class UnluckyClassifier(BaseEstimator):
    def fit(self, _X, _y=None):
        return self

    # noinspection PyMethodMayBeStatic
    def predict(self, X):
        return np.zeros((len(X),), dtype=bool)


# %%
unlucky_clf = UnluckyClassifier()

# %%
unlucky_clf.fit(x_train, lucky7_train)

# %%
unlucky_predict = unlucky_clf.predict(x_test)

# %%
print(classification_report(unlucky_predict, lucky7_test))

# %%
from sklearn.linear_model import RidgeClassifier

# %%
lr_clf = RidgeClassifier()

# %%
lr_clf.fit(x_train, y_train)

# %%
pred_lr = lr_clf.predict(x_test)


# %%
def show_classification_results(pred, cmap="viridis"):
    print(classification_report(pred, y_test))

    fig, ax = plt.subplots(1, 1, figsize=(12, 9), dpi=150)
    fig.tight_layout()

    metrics.ConfusionMatrixDisplay.from_predictions(
        pred,
        y_test,
        normalize="pred",
        values_format=".3f",
        ax=ax,
        colorbar=True,
        cmap=cmap,
    )
    plt.show()


# %%
show_classification_results(pred_lr)

# %%
show_classification_results(pred_lr, cmap="tab20b")

# %%
rf_clf = RandomForestClassifier(n_jobs=128)

# %%
rf_clf.fit(x_train, y_train)

# %%
pred_rf = rf_clf.predict(x_test)
