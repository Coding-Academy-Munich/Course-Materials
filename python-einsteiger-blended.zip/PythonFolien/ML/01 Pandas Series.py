# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Pandas Series</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Pandas Series.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_610_pandas/topic_110_pandas_series.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Pandas Typ `Series`
#
# Eine Pandas `Series` Instanz stellt eine Folge von Werten dar, ähnlich wie
# eine Python-Liste. Die Elemente einer Serie können über ihren numerischen
# Index abgerufen werden, aber zusätzlich kann eine Serie einen semantisch
# sinnvollen Index haben (z. B. für Zeitreihen).
#
# Intern wird eine Pandas-Serie durch ein Numpy-Array unterstützt, daher sind
# die meisten der Numpy-Operationen auch auf Serien anwendbar sind.
#
# Darüber hinaus ist es einfach (und billig), Serien nach Numpy zu konvertieren.

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Erzeugung
#
# ### Aus Listen

# %%
pd.Series(data=[10, 20, 30, 40])

# %%
pd.Series(["a", "b", "c"])

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Aus Listen mit Index

# %%
pd.Series(data=[1, 2, 3, 4], index=["w", "x", "y", "z"])

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Aus Range oder Iterable

# %%
pd.Series(data=range(1, 201, 2))

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
data = pd.Series(data=range(1, 201, 2))
data.head()

# %%
data.tail()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Aus Dictionary

# %%
pd.Series(data={"Ice Cream": 2.49, "Cake": 4.99, "Fudge": 7.99})

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Indizes

# %% tags=["keep"]
food = pd.Series({"Ice Cream": 2.49, "Cake": 4.99, "Fudge": 7.99})

# %%
food

# %%
food.index

# %%
food.size

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Zugriff auf Werte

# %%
food["Cake"]

# %%
food.loc["Cake"]

# %%
# Error!
# food["Pie"]

# %%
food[0]

# %%
food.iloc[0]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
confusing = pd.Series(data=np.arange(-1, 5), index=np.arange(-3, 3))
confusing

# %%
confusing[0]

# %%
confusing.loc[0]

# %%
confusing.iloc[0]

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Methoden

# %%
food.sum()

# %%
food.mean()

# %%
food.argmin()


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def discount(price):
    return price * 0.9


# %%
food.apply(discount)

# %%
food

# %%
food.apply(lambda price: price * 0.9)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Namen von Serien

# %%
food.name

# %%
food.name = "Deserts"

# %%
food.name

# %%
food

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Plotten von Serien

# %% tags=["keep"]
food = pd.Series({"Ice Cream": 2.49, "Cake": 4.99, "Fudge": 7.99})

# %%
food.plot.bar()
plt.show()

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
food.plot(kind="bar")
plt.show()

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
import random

# %% tags=["keep"]
data = pd.Series(data=[random.gauss(0.0, 10.0) for _ in range(5_000)])

# %%
data.plot.hist(legend=False, bins=20)
plt.show()

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Operationen auf mehreren Serien

# %% tags=["keep"]
food1 = pd.Series({"Ice Cream": 2.99, "Cake": 5.99, "Fudge": 6.99})
food2 = pd.Series({"Cake": 4.99, "Ice Cream": 2.99, "Pie": 3.49, "Cheese": 4.99})

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
food_sum = food1 + food2
food_sum

# %%
food1 + 0.5

# %%
food1

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
pd.concat([food1, food2])

# %%
food1

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
all_food = pd.concat([food1, food2])

# %% tags=["keep"]
all_food

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Fehlende Werte

# %%
food = food1 + food2
food

# %%
food.isna()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Feststellen wie viele Werte `NaN`s sind:

# %%
food.isna().sum()

# %%
food.dropna()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Slices und Fancy Indexing

# %%
all_food[0:2]

# %%
all_food.iloc[0:2]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.iloc[0:2] = 2.99

# %%
all_food

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Man kann auch ein Series-Objekt mit Booleschen Werten zum Indexing
# verwenden. Dann wird eine Teilfolge der Series ausgewählt:

# %% tags=["keep"]
food1

# %% tags=["keep"]
food1[pd.Series({"Ice Cream": False, "Cake": True, "Fudge": True})]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food < 4

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food[all_food < 4]

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Mehrfach vorkommende Werte

# %%
food1

# %%
food1.is_unique

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
food2

# %%
food2.is_unique

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Mehrfach vorkommende Index-Werte

# %%
food1.index

# %%
food1.index.is_unique

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.index

# %%
all_food.index.is_unique

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Nochmal: Zugriff auf Werte

# %% tags=["keep"]
all_food

# %%
all_food.loc["Pie"]

# %%
all_food["Pie"]

# %%
type(all_food.loc["Pie"])

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.loc["Cake"]

# %%
all_food["Cake"]

# %%
type(all_food.loc["Cake"])

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.loc[["Pie"]]

# %%
all_food.loc[["Cake"]]

# %%
all_food.loc[["Pie", "Cake"]]

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Gruppieren

# %% tags=["keep"]
all_food

# %%
all_food.groupby(level=0)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.groupby(level=0).indices

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.groupby(level=0).aggregate(list)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.groupby(level=0).aggregate(set)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.groupby(level=0).min()

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Sortierte und unsortierte Indizes

# %%
all_food.index.is_monotonic_increasing

# %%
sorted_food = all_food.sort_index()

# %%
sorted_food

# %%
sorted_food.index.is_monotonic_increasing

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
sorted_food = all_food.sort_values()

# %%
sorted_food.is_monotonic_increasing

# %%
sorted_food.index.is_monotonic_increasing

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Fancy Indexing und sortierte Indizes

# %%
all_food

# %%
all_food.iloc[1:3]

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
# all_food.loc["Cake":"Fudge"]

# %%
sorted_food = all_food.sort_index()

# %%
sorted_food.loc["Cake":"Fudge"]

# %% [markdown] lang="de"
#
# **Wichtig:** Der ober Wert der Slice, `"Fudge"` ist im Resultat enthalten!

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Einfache Zeitreihenanalyse
#
# Wir haben folgende Zeitreihe mit Messwerten:


# %% tags=["keep"]
measurements = pd.Series(
    [13.78, 13.41, 13.21, 10.24, 9.84, 9.35, 6.23, 5.78, 5.26, 3.44],
    index=[1, 4, 5, 6, 6, 7, 8, 8, 9, 11],
    name="Measurements",
)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Sind die Zeiten der Messungen aufsteigend geordnet?
# - Sind die Messwerte aufsteigend oder absteigend geordnet?
# - Sind die Zeiten der Messungen eindeutig?
# - Sind die Werte der Messungen eindeutig?

# %%
measurements.index.is_monotonic_increasing

# %%
measurements.is_monotonic_increasing

# %%
measurements.is_monotonic_decreasing

# %%
measurements.index.is_unique

# %%
measurements.is_unique

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Was ist der Mittelwert, Median und Standardabweichung der Messwerte?

# %%
measurements.mean()

# %%
measurements.median()

# %%
measurements.std()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Erzeugen Sie zwei neue Serien, die für Zeiten mit mehreren Messungen
#   den größten (bzw. kleinsten) Wert erhalten.
# - Erzeugen Sie eine neue Serie, die für Zeiten mit mehreren Messungen
#   den Mittelwert aller Messungen enthält.

# %%
min_measurements = measurements.groupby(measurements.index).min()
min_measurements

# %%
max_measurements = measurements.groupby(measurements.index).max()
max_measurements

# %%
avg_measurements = measurements.groupby(measurements.index).mean()
avg_measurements

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Erzeugen Sie eine neue Serie, die alle Messungen enthält, die zwischen
#   3 und 7 Sekunden stattfanden (einschließlich der Grenzen).
# - Erzeugen Sie eine neue Serie, die alle Messungen zwischen der 2. und der 6. Messung
#   enthält (einschließlich der Grenzen).

# %%
measurements

# %%
measurements.loc[3:7]

# %% tags=["alt"]
# measurements[3:9]

# %%
measurements.iloc[2:7]

# %% [markdown] lang="de"
#
# - Erzeugen Sie eine Serie, die alle Messungen enthält, deren Wert größer als 10 ist.
# - Erzeugen Sie eine Serie, die alle Messungen enthält, deren Wert zwischen 8 und 11 ist.

# %%
measurements[measurements > 10]

# %%
measurements[(8 < measurements) & (measurements < 11)]
