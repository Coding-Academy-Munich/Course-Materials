# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Klassifikation von Ziffern</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">11 Klassifikation von Ziffern.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Klassifikation von Ziffern
#
# Wir wenden uns jetzt dem Multi-Klassen-Klassifikationsproblem zu: Wir wollen
# erkennen, welche Ziffern auf den MNIST-Bildern dargestellt sind.

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
try:
    from python_courses.envconfig import EnvConfig
except ModuleNotFoundError:
    from envconfig import EnvConfig  # noqa

# %% tags=["keep"]
import pickle

import matplotlib.pyplot as plt
import numpy as np

# %% tags=["keep"]
config = EnvConfig()

# %% tags=["keep"]
with open(config.processed_mnist_pkl_path, "rb") as mnist_file:
    mnist_data = pickle.load(mnist_file)

# %% tags=["keep"]
x_train = mnist_data["x_train"]
x_test = mnist_data["x_test"]
y_train = mnist_data["y_train"]
y_test = mnist_data["y_test"]

# %%
y_test[:3]

# %%
plt.imshow(x_test[0].reshape(28, 28), cmap="binary")
plt.show()

# %%
from sklearn.linear_model import RidgeClassifier  # noqa: E402

# %%
ridge_clf = RidgeClassifier(random_state=42)

# %%
ridge_clf.fit(x_train, y_train)

# %%
ridge_clf.predict([x_test[0]])

# %%
ridge_clf.predict(x_test[:3])

# %%
y_predict = ridge_clf.predict(x_test)

# %%
correct_predictions = y_predict == y_test

# %%
correct_predictions[:10]

# %%
np.sum(correct_predictions)

# %%
from sklearn.metrics import (  # noqa: E402
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    f1_score,
    confusion_matrix,
    ConfusionMatrixDisplay,
    classification_report,
)

# %%
accuracy_score(y_test, y_predict)

# %%
balanced_accuracy_score(y_test, y_predict)

# %%
precision_score(y_test, y_predict, average="macro")

# %%
precision_score(y_test, y_predict, average="micro")

# %%
f1_score(y_test, y_predict, average="macro")

# %%
confusion_matrix(y_predict, y_test)

# %%
ConfusionMatrixDisplay.from_predictions(y_predict, y_test)
plt.show()

# %%
ConfusionMatrixDisplay.from_predictions(
    y_predict, y_test, normalize="pred", values_format=".2f"
)
plt.show()

# %%
print(classification_report(y_predict, y_test))

# %%
from typing import Any


# %%
def show_classification_results(pred, cmap="viridis", normalize: Any = "pred"):
    print(classification_report(pred, y_test))

    fig, ax = plt.subplots(figsize=(12, 9), dpi=150)
    fig.tight_layout()

    ConfusionMatrixDisplay.from_predictions(
        pred,
        y_test,
        normalize=normalize,
        values_format=".3f" if normalize else None,
        ax=ax,
        colorbar=True,
        cmap=cmap,
    )
    plt.show()


# %%
show_classification_results(y_predict, normalize=None)

# %%
show_classification_results(y_predict)

# %%
from sklearn.tree import DecisionTreeClassifier  # noqa: E402

# %%
dt_clf = DecisionTreeClassifier()

# %%
dt_clf.fit(x_train, y_train)

# %%
y_predict_dt = dt_clf.predict(x_test)

# %%
show_classification_results(y_predict_dt)

# %%
dt_clf2 = DecisionTreeClassifier(max_depth=3)

# %%
dt_clf2.fit(x_train, y_train)

# %%
y_predict_dt2 = dt_clf2.predict(x_test)

# %%
show_classification_results(y_predict_dt2)

# %%
from sklearn.ensemble import RandomForestClassifier  # noqa: E402

# %%
rf_clf = RandomForestClassifier(random_state=42, n_estimators=200, n_jobs=128)

# %%
rf_clf.fit(x_train, y_train)

# %%
y_predict_rf = rf_clf.predict(x_test)

# %%
show_classification_results(y_predict_rf)

# %%
from sklearn.model_selection import RandomizedSearchCV

# %%
parameters = {
    "n_estimators": [400],
    "min_samples_split": [2, 8, 32],
    "min_samples_leaf": [1, 4, 16],
    "max_leaf_nodes": [None, 100, 1000],
    "max_features": ["sqrt", 16, 32, 64],
}

# %% tags=["alt"]
# Original values:
# parameters = {
#     "n_estimators": [400],
#     "min_samples_split": [2, 4, 8],
#     "min_samples_leaf": [1, 4, 16],
#     "max_leaf_nodes": [None, 100, 1000],
#     "max_features": ["sqrt", None, 64, 128],
# }

# %%
best_parameters = {
    "n_estimators": 400,
    "min_samples_split": 2,
    "min_samples_leaf": 1,
    "max_leaf_nodes": None,
    "max_features": 64,
}

# %%
rs_rf = RandomForestClassifier(n_jobs=16)

# %%
rs_clf = RandomizedSearchCV(rs_rf, parameters, cv=3, n_iter=4, n_jobs=12)

# %%
RANDOM_SEARCH_SAMPLES = 60_000

# %%
rs_clf.fit(x_train[:RANDOM_SEARCH_SAMPLES], y_train[:RANDOM_SEARCH_SAMPLES])

# %%
y_predict_rs = rs_clf.predict(x_test)

# %%
show_classification_results(y_predict_rs)

# %%
rs_clf.best_params_

# %%
from sklearn.base import BaseEstimator  # noqa: E402


# %%
class FixedZeroClassifier(BaseEstimator):
    def fit(self, _X, _y=None):
        return self

    # noinspection PyMethodMayBeStatic
    def predict(self, X):
        return np.zeros((len(X),), dtype=bool)


# %%
fixed_0_clf = FixedZeroClassifier()

# %%
fixed_0_clf.fit(x_train, y_train)

# %%
fixed_0_predict = fixed_0_clf.predict(x_test)

# %%
show_classification_results(fixed_0_predict)
