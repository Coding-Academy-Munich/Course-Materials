# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Vorbereiten der MNIST Daten</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Vorbereiten der MNIST Daten.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Vorbereiten der MNIST Daten

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
try:
    from python_courses.config import Config
except ModuleNotFoundError:
    from config import Config  # noqa

# %%
from textwrap import wrap
import pickle

import numpy as np
import matplotlib.pyplot as plt

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Vorbereitungen

# %%
config = Config()


# %%
def print_wrapped(text: str):
    for paragraph in text.split("\n"):
        print("\n".join(wrap(paragraph)))


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Laden der MNIST-Daten

# %%
with open(config.mnist_pkl_path, "rb") as file:
    mnist = pickle.load(file)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Analysieren der Daten

# %%
type(mnist)

# %%
mnist.keys()

# %%
print_wrapped(mnist["DESCR"])

# %%
mnist.details

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Analysieren von `data` und `target`

# %%
type(mnist.data)

# %%
mnist.data.shape

# %%
type(mnist.target)

# %%
mnist.target.shape

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Verwenden der geläufigen Variablennamen

# %%
X, y = mnist.data, mnist.target

# %%
type(X)

# %%
type(y)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Umwandeln in Numpy Arrays

# %%
X = X.to_numpy()
y = y.to_numpy()

# %%
type(X)

# %%
type(y)

# %%
X.shape

# %%
y.shape

# %%
X.dtype

# %%
y.dtype

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Analysieren des Wertebereichs

# %%
np.min(X)

# %%
np.max(X)

# %%
np.min(y)

# %%
np.max(y)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Analysieren einzelner Einträge

# %%
first_clothing_item = X[0]
second_clothing_item = X[1]

# %%
type(first_clothing_item)

# %%
first_clothing_item.shape

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Umwandeln in Bilder

# %%
first_clothing_item_image = first_clothing_item.reshape(28, 28)
second_clothing_item_image = second_clothing_item.reshape(28, 28)

# %%
first_clothing_item_image.shape

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Anzeigen der Bilder

# %%
plt.imshow(first_clothing_item_image, cmap="binary")
plt.show()

# %%
plt.imshow(second_clothing_item_image, cmap="binary")
plt.show()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Umwandeln der Klassen in Zahlen

# %%
y[:2]

# %%
y = y.astype(np.int32)

# %%
y[:2]

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Die Zahl 7

# %%
first_index_of_7 = np.where(y == 7)[0][0]
first_index_of_7

# %%
plt.imshow(X[first_index_of_7].reshape(28, 28), cmap="binary")
plt.show()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Aufspalten in Trainings- und Test-Set

# %%
x_train, x_test = X[:60_000], X[60_000:]

# %%
y_train, y_test = y[:60_000], y[60_000:]

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Exportieren der Daten

# %%
processed_mnist_data = {
    "x_train": x_train,
    "x_test": x_test,
    "y_train": y_train,
    "y_test": y_test,
}

# %%
with open(config.processed_mnist_pkl_path, "wb") as mnist_file:
    pickle.dump(processed_mnist_data, mnist_file)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Exkurs: Vergleich von Listen und Numpy Arrays

# %%
[1, 2, 3] == [1, 3, 3]  # noqa: B015

# %%
np.array([1, 2, 3]) == np.array([1, 3, 3])  # noqa: B015

# %%
(np.array([1, 2, 3]) == np.array([1, 3, 3])).all()

# %%
(np.array([1, 2, 3]) == np.array([1, 2, 3])).all()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Sanity Checks

# %%
with open(config.processed_mnist_pkl_path, "rb") as mnist_file:
    loaded_mnist_data = pickle.load(mnist_file)

# %%
assert (loaded_mnist_data["x_test"] == x_test).all()  # noqa
assert (loaded_mnist_data["x_train"] == x_train).all()  # noqa
assert (loaded_mnist_data["y_test"] == y_test).all()  # noqa
assert (loaded_mnist_data["y_train"] == y_train).all()  # noqa

# %%
print("\n\nDone!")

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Fashion-MNIST
#
# Bereiten Sie den Fashion-MNIST Datensatz auf die gleiche Weise vor, wie MNIST.


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
try:  # noqa
    from python_courses.config import Config
except ModuleNotFoundError:
    from config import Config  # noqa

# %%
from textwrap import wrap
import pickle

import numpy as np
import matplotlib.pyplot as plt

# %%
config = Config()


# %%
def print_wrapped(text: str):
    for paragraph in text.split("\n"):
        print("\n".join(wrap(paragraph)))


# %%
with open(config.fashion_mnist_pkl_path, "rb") as file:
    fashion_mnist = pickle.load(file)

# %%
type(fashion_mnist)

# %%
fashion_mnist.keys()

# %%
type(fashion_mnist.data)

# %%
fashion_mnist.data.shape

# %%
type(fashion_mnist.target)

# %%
fashion_mnist.target.shape

# %%
fashion_mnist.details

# %%
print_wrapped(fashion_mnist.DESCR)

# %%
X, y = fashion_mnist.data, fashion_mnist.target

# %%
type(X)

# %%
type(y)

# %%
X = X.to_numpy()
y = y.to_numpy()

# %%
type(X)

# %%
type(y)

# %%
X.shape

# %%
y.shape

# %%
X.dtype

# %%
y.dtype

# %%
np.min(X)

# %%
np.max(X)

# %%
np.min(y)

# %%
np.max(y)

# %%
first_clothing_item = X[0]
second_clothing_item = X[1]

# %%
type(first_clothing_item)

# %%
first_clothing_item.shape

# %%
first_clothing_item_image = first_clothing_item.reshape(28, 28)
second_clothing_item_image = second_clothing_item.reshape(28, 28)

# %%
first_clothing_item_image.shape

# %%
plt.imshow(first_clothing_item_image, cmap="binary")
plt.show()

# %%
plt.imshow(second_clothing_item_image, cmap="binary")
plt.show()

# %%
y[:2]

# %%
y = y.astype(np.int32)

# %%
y[:2]

# %%
x_train, x_test = X[:60_000], X[60_000:]  # noqa

# %%
y_train, y_test = y[:60_000], y[60_000:]

# %%
processed_fashion_mnist_data = {
    "x_train": x_train,
    "x_test": x_test,
    "y_train": y_train,
    "y_test": y_test,
}

# %%
with open(config.processed_fashion_mnist_pkl_path, "wb") as fashion_mnist_file:
    pickle.dump(processed_fashion_mnist_data, fashion_mnist_file)

# %%
with open(config.processed_fashion_mnist_pkl_path, "rb") as fashion_mnist_file:
    loaded_fashion_mnist_data = pickle.load(fashion_mnist_file)

# %%
assert (loaded_fashion_mnist_data["x_test"] == x_test).all()  # noqa
assert (loaded_fashion_mnist_data["x_train"] == x_train).all()  # noqa
assert (loaded_fashion_mnist_data["y_test"] == y_test).all()  # noqa
assert (loaded_fashion_mnist_data["y_train"] == y_train).all()  # noqa

# %%
print("\n\nDone!")
