# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Ausnahmen und Fehlerbehandlung</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">10 Ausnahmen und Fehlerbehandlung.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Fehlerbehandlung
#
# Wir wollen eine Funktion `int_sqrt(n: int) -> int` schreiben, die die
# "Ganzzahlige Wurzel" berechnet:
# - Wenn `n` eine Quadratzahl ist, also die Form `m * m` hat, dann soll `m`
#   zurückgegeben werden.
# - Was machen wir, falls `n` keine Quadratzahl ist?
#
# Einige Lösungsversuche:


# %%

# %%


# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %%

# %%

# %%


# %%


# %%


# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
#  Beide Ansätze haben mehrere Probleme:
#  - Die Fehlerbehandlung ist optional. Wird sie nicht durchgeführt, so wird mit
#    einem falschen Wert weitergerechnet.
#  - Kann der Aufrufer den Fehler nicht selber behandeln, so muss der Fehler über
#    mehrere Ebenen von Funktionsaufrufen "durchgereicht" werden. Das führt zu
#    unübersichtlichem Code, da der "interessante" Pfad nicht vom Code zur
#    Fehlerbehandlung getrennt ist.
#
#  Eine bessere Lösung:

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%


# %%


# %%


# %%


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}


# %%


# %%

# %%


# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%


# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Fehlerklassen
#
# In Python gibt es viele vordefinierte Fehlerklassen, mit denen verschiedene
# Fehlerarten signalisiert werden können:
# - `Exception`: Basisklasse aller behandelbaren Exceptions
# - `ArithmeticError`: Basisklasse aller Fehler bei Rechenoperationen:
#   - OverflowError
#   - ZeroDivisionError
# - `LookupError`: Basisklasse wenn ein ungültiger Index für eine Datenstruktur
#   verwendet wurde
# - `AssertionError`: Fehlerklasse, die von `assert` verwendet wird
# - `EOFError`: Fehler wenn `input()` unerwartet das Ende einer Datei erreicht
# - ...
#
# Die Liste der in der Standardbibliothek definierten Fehlerklassen ist
# [hier](https://docs.python.org/3/library/exceptions.html).

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
class MyValueError(ValueError):
    pass


# %% tags=["keep"]
try:
    raise ValueError("ValueError")
    # raise MyValueError("MyValueError")
except MyValueError as error:
    print(f"Case 1: {error}")
except ValueError as error:
    print(f"Case 2: {error}")


# %%

# %% tags=["keep"]
def raise_and_handle_error():
    print("raise_and_handle_error() before")
    try:
        raise ValueError("ValueError was raised.")
        # raise MyValueError("Found no root.")
        # raise TypeError("Bad type")
    except MyValueError as error:
        print(f"Case MyValueError: {error}")
    except ValueError as error:
        print(f"Case ValueError: {error}")
    print("raise_and_handle_error() after")


# %% tags=["keep"]
def f2():
    print("f2() before")
    raise_and_handle_error()
    print("f2() after")


# %% tags=["keep"]
def f1():
    print("f1() before")
    try:
        f2()
    except Exception as error:
        print(f"Case Exception: {error}")
    print("f1() after")


# %% tags=["keep"]
f1()

# %% tags=["keep"]

# %% [markdown] lang="de"
# ## Mini-Workshop
#
# - Notebook `workshop_190_inheritance`
# - Abschnitt "Bank Account"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Mini-Workshop
#
# - Notebook `workshop_090_control_structures`
# - Abschnitt "Knobeln"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Mini-Workshop
#
# - Notebook `topic_900_othellite`
# - `compute_linear_index()`
