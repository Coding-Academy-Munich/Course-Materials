# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>String Methoden (Teil 1)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 String Methoden (Teil 1).py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_120_data_types/topic_180_a3_string_methods_part1.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # String Methoden (Teil 1)
#
# Methoden sind ähnlich zu Funktionen, werden aber "auf einem Objekt" aufgerufen.
#
# Die Syntax ist `objekt.methode(...)`.
#
# In Text werden Methoden entweder als `Typ.methode()` oder `methode()` geschrieben.

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Umwandeln eines Strings in Groß-/Kleinbuchstaben
#
# - `string.lower()` wandelt einen String in Kleinbuchstaben um
# - `string.upper()` wandelt einen String in Großbuchstaben um

# %% lang="de"

# %% lang="de"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Die `lower()` und `upper()` Methoden wandeln Strings so um, dass sie ausgedruckt
# werden können. Für schreibungsunabhängige Vergleiche ist die `casefold()` Methode
# die korrekte Wahl.

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Shout
#
# Schreiben Sie eine Funktion `shout(text)`, die `text` in Großbuchstaben,
# gefolgt von drei Ausrufezeichen auf dem Bildschirm ausgibt.


# %%

# %% [markdown] lang="de"
# Testen Sie die Funktion mit Argument `"Hallo"`

# %% lang="de"
