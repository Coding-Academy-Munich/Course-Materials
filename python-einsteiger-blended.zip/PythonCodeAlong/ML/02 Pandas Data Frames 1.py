# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Pandas Data Frames 1</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Pandas Data Frames 1.py</div> -->

# %% [markdown] lang="de"
# # Data Frames
#
# DataFrames sind die am häufigsten verwendete Datenstruktur in Pandas. Sie
# erlauben uns einfaches Lesen, Verarbeiten und Speichern von tabellenbasierten
# Daten.
#
# Konzeptionell besteht ein Datenrahmen aus mehreren Serieninstanzen, die sich
# einen gemeinsamen Index teilen.

# %% tags=["keep"]
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

# %% tags=["keep"]
PANDAS_DIR_FROM_ENV = os.getenv("PANDAS_DIR_PATH")
if PANDAS_DIR_FROM_ENV:
    pandas_dir_path = Path(PANDAS_DIR_FROM_ENV)
else:
    pandas_dir_path = Path("data/pandas").absolute()
print(f"Pandas data: {pandas_dir_path}")


# %%

# %% [markdown] lang="de"
# ## Erzeugen von Data Frames

# %% [markdown] lang="de"
# ### Aus einem NumPy Array

# %% tags=["keep"]
def create_data_frame():
    rng = np.random.default_rng(42)
    array = rng.normal(size=(5, 4), scale=5.0)
    index = ["A", "B", "C", "D", "E"]
    columns = ["w", "x", "y", "z"]
    return pd.DataFrame(array, index=index, columns=columns)


# %% tags=["keep"]
df = create_data_frame()
df

# %%

# %% [markdown] lang="de"
# ### Aus einer CSV Datei

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ### Aus einer Excel Datei

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
#
# ### Andere Formate:
#
# - `pd.read_clipboard`
# - `pd.read_html`
# - `pd.read_json`
# - `pd.read_pickle`
# - `pd.read_sql` (verwendet SQLAlchemy um auf die Datenbank zuzugreifen)
# - ...

# %% [markdown] lang="de"
# # Plotten von Data Frames

# %% tags=["keep"]
df_csv["Col 0"].hist(bins=15)

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
df_csv.hist(bins=20, figsize=(12, 8))

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
df_csv.plot(kind="scatter", x="Col 1", y="Col 2")
plt.show()

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
df_csv.plot(kind="scatter", x="Col 1", y="Col 2", c="Col 3", cmap="hot")
plt.show()

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
df_csv.plot(
    kind="scatter", x="Col 1", y="Col 2", c="Col 3", s=df_csv["Col 4"], cmap="hot"
)
plt.show()

# %% [markdown] lang="de"
# ### Indizes und Operationen

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ### Erzeugen, Umbenennen und Löschen von Spalten

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Auswahl

# %%

# %%

# %%


# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Bedingte Auswahl

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
#
# # Information über Data Frames

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Der Index eines Data Frames

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Wine Data Frame
#
# In der Datei `pandas_dir_path / "wines.csv` sind Daten über verschiedene Weinsorten
# gespeichert.
#
# - Laden Sie die Datei in einen Pandas Data Frame.
# - Wie viele Zeilen und Spalten hat der Data Frame?
# - Analysieren Sie, welche Spalten der Data Frame hat und welchen Typ sie haben.
# - Was sind Minima, Maxima, Mittelwert und Quantillen der numerischen Spalten?


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Plotten Sie Histogramme der `alcohol` und `total_phenols` Spalten.
# - Plotten Sie einen Scatterplot der `total_phenols` gegen `nonflavanoid_phenols`
#   Werte.
# - Plotten Sie einen Scatterplot der `total_phenols` gegen `nonflavanoid_phenols`
#   Werte, bei dem Sie den Punkten eine unterschiedliche Farbe je nach Wert von
#   `target` zuordnen und die Marker mit der Größe des `proline`-Attributs / 75
#   darstellen.

# %%

# %%

# %%

# %%
