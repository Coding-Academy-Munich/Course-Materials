# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Pandas Data Frames 1</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Pandas Data Frames 1.py</div> -->

# %% [markdown] lang="de"
# # Data Frames
#
# DataFrames sind die am häufigsten verwendete Datenstruktur in Pandas. Sie
# erlauben uns einfaches Lesen, Verarbeiten und Speichern von tabellenbasierten
# Daten.
#
# Konzeptionell besteht ein Datenrahmen aus mehreren Serieninstanzen, die sich
# einen gemeinsamen Index teilen.

# %% tags=["keep"]
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

# %% tags=["keep"]
PANDAS_DIR_PATH = os.getenv("PANDAS_DIR_PATH")
if PANDAS_DIR_PATH:
    pandas_dir_path = Path(PANDAS_DIR_PATH)
else:
    pandas_dir_path = Path("data/pandas").absolute()
print(f"Pandas data: {pandas_dir_path}")


# %%

# %% [markdown] lang="de"
# ## Erzeugen von Data Frames

# %% [markdown] lang="de"
# ### Aus einem NumPy Array

# %% tags=["keep"]
def create_data_frame():
    rng = np.random.default_rng(42)
    array = rng.normal(size=(5, 4), scale=5.0)
    index = ["A", "B", "C", "D", "E"]
    columns = ["w", "x", "y", "z"]
    return pd.DataFrame(array, index=index, columns=columns)


# %% tags=["keep"]
df = create_data_frame()
df

# %%

# %% [markdown] lang="de"
# ### Aus einer CSV Datei

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ### Aus einer Excel Datei

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
#
# ### Andere Formate:
#
# - `pd.read_clipboard`
# - `pd.read_html`
# - `pd.read_json`
# - `pd.read_pickle`
# - `pd.read_sql` (verwendet SQLAlchemy um auf die Datenbank zuzugreifen)
# - ...

# %% [markdown] lang="de"
# # Plotten von Data Frames

# %% tags=["keep"]
df_csv["Col 0"].hist(bins=15)

# %% tags=["keep"]
df_csv.hist(bins=20, figsize=(12, 8))

# %% tags=["keep"]
df_csv.plot(kind="scatter", x="Col 1", y="Col 2")
plt.show()

# %% tags=["keep"]
df_csv.plot(kind="scatter", x="Col 1", y="Col 2", c="Col 3", cmap="hot")

# %% [markdown] lang="de"
# ### Indizes und Operationen

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ### Erzeugen, Umbenennen und Löschen von Spalten

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Auswahl

# %%

# %%

# %%


# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Bedingte Auswahl

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
#
# # Information über Data Frames

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Der Index eines Data Frames

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% tags=["keep"]
