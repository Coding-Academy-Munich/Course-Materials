# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Parametersuche für Lucky 7</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">13 Parametersuche für Lucky 7.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_700_ml_basics/topic_180_lucky7_parameter_search.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Hyperparameter-Tuning durch Suche

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
import pickle

import matplotlib.pyplot as plt  # noqa
import numpy as np  # noqa

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
try:
    from python_courses.envconfig import EnvConfig
except ModuleNotFoundError:
    from envconfig import EnvConfig  # noqa

# %% tags=["keep"]
config = EnvConfig()
# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
with open(config.processed_mnist_pkl_path, "rb") as file:
    mnist_data = pickle.load(file)

# %% tags=["keep"]
x_train = mnist_data["x_train"]
x_test = mnist_data["x_test"]
y_train = mnist_data["y_train"]
y_test = mnist_data["y_test"]
# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
lucky7_train = y_train == 7
lucky7_test = y_test == 7
# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
from sklearn.metrics import classification_report

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay, classification_report


# %% tags=["keep"]
def plot_confusion_matrices(clf, x_train, x_test, y_train, y_test, normalize=None):
    fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(16, 9))
    fig.tight_layout()
    fig.suptitle(f"Confusion Matrices (Normalize={normalize})")
    ConfusionMatrixDisplay.from_predictions(
        y_test,
        clf.predict(x_test),
        normalize=normalize,
        ax=ax1,
        colorbar=False,
        values_format=".3f" if normalize else None,
    )
    ax1.set_title("Test Data")
    ConfusionMatrixDisplay.from_predictions(
        y_train,
        clf.predict(x_train),
        normalize=normalize,
        ax=ax2,
        colorbar=False,
        values_format=".3f" if normalize else None,
    )
    ax2.set_title("Training Data")
    plt.show()
# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Systematische Parametersuche mit Grid Search

# %% tags=["keep"]
param_grid_gs = {
    "bootstrap": [False],
    "class_weight": ["balanced"],
    "max_features": [64, 256],
    "max_leaf_nodes": [250, 500],
    "min_samples_leaf": [2, 4, 8],
    "min_samples_split": [12, 16],
    "n_estimators": [100],
}

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
from sklearn.ensemble import RandomForestClassifier

# %% tags=["keep"]
gs_rf = RandomForestClassifier(n_jobs=24)

# %%

# %%

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
GRID_SEARCH_SAMPLES = 12_000

# %%

# %%

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
print(classification_report(lucky7_test, gs_pred))

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
plot_confusion_matrices(gs_clf, x_train, x_test, lucky7_train, lucky7_test)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Stochastische Suche mit Randomized Search

# %% tags=["keep"]
param_grid = {
    "bootstrap": [True, False],
    "class_weight": [None, "balanced"],
    "max_features": [64, 256],
    "max_leaf_nodes": [None, 250, 500, 1000],
    "min_samples_leaf": [1, 4, 8, 16],
    "min_samples_split": [2, 4, 8, 12],
    "n_estimators": [50, 100],
}


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def num_parameter_combinations(parameters: dict):
    result = 1
    for values in parameters.values():
        result *= len(values)
    return result


# %% tags=["keep"]
num_parameter_combinations(param_grid)

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
rs_rf = RandomForestClassifier(random_state=42, n_jobs=24)

# %%

# %%

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
RANDOM_SEARCH_SAMPLES = 12_000

# %%

# %%

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
print(classification_report(lucky7_test, rs_pred))

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
plot_confusion_matrices(rs_clf, x_train, x_test, lucky7_train, lucky7_test)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Vergleich der besten gefundenen Lösungen

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Schrittweise Halbierung des Suchraums

# %% tags=["keep"]
param_grid_hs = {
    "bootstrap": [True, False],
    "class_weight": [None, "balanced"],
    "max_features": [128, 256],
    "max_leaf_nodes": [None, 250, 500],
    "min_samples_leaf": [1, 4],
    "min_samples_split": [2, 8, 16, 32],
    "n_estimators": [100],
}

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
from sklearn.experimental import enable_halving_search_cv  # noqa
from sklearn.model_selection import HalvingGridSearchCV  # noqa

# %% tags=["keep"]
hs_rf = RandomForestClassifier(random_state=42, n_jobs=24)

# %%

# %%

# %%

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
print(classification_report(lucky7_test, hs_pred))

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
plot_confusion_matrices(hs_clf, x_train, x_test, lucky7_train, lucky7_test)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
