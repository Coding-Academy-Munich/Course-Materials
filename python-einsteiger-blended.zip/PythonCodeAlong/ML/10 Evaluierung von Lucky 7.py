# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Evaluierung von Lucky 7</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">10 Evaluierung von Lucky 7.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Evaluierung der Glückszahl 7

# %% tags=["keep"]
import pickle

import matplotlib.pyplot as plt
import numpy as np

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
try:
    from python_courses.envconfig import EnvConfig
except ModuleNotFoundError:
    from envconfig import EnvConfig  # noqa

# %% tags=["keep"]
config = EnvConfig()

# %% tags=["keep"]
with open(config.processed_mnist_pkl_path, "rb") as mnist_file:
    mnist_data = pickle.load(mnist_file)

# %% tags=["keep"]
x_train = mnist_data["x_train"]
x_test = mnist_data["x_test"]
y_train = mnist_data["y_train"]
y_test = mnist_data["y_test"]

# %% tags=["keep"]
lucky7_train = y_train == 7
lucky7_test = y_test == 7

# %% tags=["keep"]
from sklearn.linear_model import SGDClassifier  # noqa: E402

# %% tags=["keep"]
sgd_clf = SGDClassifier(random_state=42)

# %% tags=["keep"]
sgd_clf.fit(x_train, lucky7_train)

# %% tags=["keep"]
lucky7_predict = sgd_clf.predict(x_test)

# %% tags=["keep"]
from sklearn.metrics import (  # noqa: E402
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    confusion_matrix,
    ConfusionMatrixDisplay,
    classification_report,
)


# %%

# %%

# %%

# %%

# %%

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def print_scores(y_true, y_pred):
    print(f"Accuracy:          {accuracy_score(y_true, y_pred):.3f}")
    print(f"Balanced accuracy: {balanced_accuracy_score(y_true, y_pred):.3f}")
    print(f"Precision:         {precision_score(y_true, y_pred):.3f}")
    print(f"Recall:            {recall_score(y_true, y_pred):.3f}")
    print(f"F1:                {f1_score(y_true, y_pred):.3f}")

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
