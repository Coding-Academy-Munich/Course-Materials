# %%
import logging
import platform
from multiprocessing import cpu_count
from pathlib import Path

from pydantic.env_settings import BaseSettings
from appdirs import user_data_dir, user_cache_dir

# %%
COURSES_SUBDIR = "coding_academy/python_courses/"


# %%
class Config(BaseSettings):
    # Paths
    base_dir_path = Path(user_data_dir()) / COURSES_SUBDIR
    data_dir_path = base_dir_path / "data/"
    model_dir_path = Path(data_dir_path / "models/")
    cache_dir_path = Path(user_cache_dir()) / COURSES_SUBDIR
    sklearn_cache_dir_path = cache_dir_path / "sklearn/"
    pickle_dir_path = cache_dir_path / "pickles/"
    mnist_pkl_path = pickle_dir_path / "mnist.pkl"
    fashion_mnist_pkl_path = pickle_dir_path / "fashion-mnist.pkl"
    processed_mnist_pkl_path = pickle_dir_path / "mnist-processed.pkl"
    processed_fashion_mnist_pkl_path = pickle_dir_path / "fashion-mnist-processed.pkl"

    # Logging
    logfile: Path = base_dir_path / "default.log"
    loglevel: int = logging.DEBUG

    # Multiprocessing
    max_processes: int = 32 if platform.system() == "Windows" else cpu_count()

    def __init__(self):
        super().__init__()
        for dir_path in [
            self.base_dir_path,
            self.data_dir_path,
            self.cache_dir_path,
            self.model_dir_path,
        ]:
            dir_path.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(level=self.loglevel, filename=self.logfile)

    class Config:
        env_prefix = "PYTHON_COURSES_"
        fields = {
            "base_dir_path": {
                "env": "BASE_DIR",
            },
            "data_dir_path": {
                "env": "DATA_DIR",
            },
            "model_dir_path": {
                "env": "MODEL_DIR",
            },
            "logfile": {
                "env": "LOGFILE",
            },
            "loglevel": {
                "env": "LOGLEVEL",
            },
            "max_processes": {
                "env": "MAX_PROCESSES",
            },
        }


# %%
