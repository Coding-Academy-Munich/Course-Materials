# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Pandas Data Frames 1</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Pandas Data Frames 1.py</div> -->

# %% [markdown] lang="de"
# # Data Frames
#
# DataFrames sind die am häufigsten verwendete Datenstruktur in Pandas. Sie
# erlauben uns einfaches Lesen, Verarbeiten und Speichern von tabellenbasierten
# Daten.
#
# Konzeptionell besteht ein Datenrahmen aus mehreren Serieninstanzen, die sich
# einen gemeinsamen Index teilen.

# %% tags=["keep"]
from pathlib import Path
import numpy as np
import pandas as pd

# %% tags=["keep"]
if "pandas_dir_path" not in globals():
    pandas_dir_path = Path("data/pandas")
else:
    # To silence warnings from PyCharm
    pandas_dir_path = globals()["pandas_dir_path"]

# %%
assert pandas_dir_path.exists()


# %% [markdown] lang="de"
# ## Erzeugen von Data Frames


# %% [markdown] lang="de"
# ### Aus einem NumPy Array

# %% tags=["keep"]
def create_data_frame():
    rng = np.random.default_rng(42)
    array = rng.normal(size=(5, 4), scale=5.0)
    index = "A B C D E".split()
    columns = "w x y z".split()
    return pd.DataFrame(array, index=index, columns=columns)


# %% tags=["keep"]
df = create_data_frame()
df

# %%
type(df)

# %% [markdown] lang="de"
# ### Aus einer CSV Datei

# %%
df_csv = pd.read_csv(pandas_dir_path / "example_data.csv")

# %%
df_csv

# %%
df_csv = pd.read_csv(pandas_dir_path / "example_data.csv", index_col=0)

# %%
df_csv

# %% [markdown] lang="de"
# ### Aus einer Excel Datei

# %%
df_excel = pd.read_excel(pandas_dir_path / "excel_data.xlsx", index_col=0)

# %%
df_excel

# %%
df_excel2 = pd.read_excel(pandas_dir_path / "excel_other_sheet.xlsx", index_col=0)

# %%
df_excel2

# %%
df_excel2 = pd.read_excel(pandas_dir_path / "excel_other_sheet.xlsx", index_col=0,
    sheet_name="Another Sheet", header=0, skiprows=[1], )

# %%
df_excel2.head()

# %% [markdown] lang="de"
#
# ### Andere Formate:
#
# - `pd.read_clipboard`
# - `pd.read_html`
# - `pd.read_json`
# - `pd.read_pickle`
# - `pd.read_sql` (verwendet SQLAlchemy um auf die Datenbank zuzugreifen)
# - ...

# %% [markdown] lang="de"
# # Plotten von Data Frames

# %% tags=["keep"]
df_csv["Col 0"].hist(bins=15)

# %% tags=["keep"]
df_csv.hist(bins=20, figsize=(12, 8))

# %% tags=["keep"]
df_csv.plot(kind="scatter", x="Col 1", y="Col 2")

# %% tags=["keep"]
df_csv.plot(kind="scatter", x="Col 1", y="Col 2", c="Col 3", cmap="hot")

# %% [markdown] lang="de"
# ### Indizes und Operationen

# %%
df_csv.head()

# %%
df_csv.tail()

# %%
df = create_data_frame()
df["w"]

# %%
type(df["w"])

# %%
# Use only interactively
df.w

# %%
df[["w", "y"]]

# %%
df.index

# %%
df.index.is_monotonic_increasing

# %%
df.size

# %%
df.ndim

# %%
df.shape

# %% [markdown] lang="de"
# ### Erzeugen, Umbenennen und Löschen von Spalten

# %%
df = create_data_frame()
df["Sum of w and y"] = df["w"] + df["y"]

# %%
df

# %%
df.rename(columns={"Sum of w and y": "w + y"})

# %%
df

# %%
df.rename(columns={"Sum of w and y": "w + y"}, index={"E": "Z"}, inplace=True)

# %%
df

# %%
type(df["y"])

# %%
del df["y"]

# %%
df

# %%
df.drop("A")

# %%
df

# %%
df.drop("B", inplace=True)

# %%
df

# %%
df.drop("z", axis=1)

# %%
df

# %%
df.drop("z", axis=1, inplace=True)

# %%
df

# %% [markdown] lang="de"
# ## Auswahl

# %%
df = create_data_frame()
df

# %%
df["w"]

# %%
# Error!
# df['A']


# %%
df.loc["B"]

# %%
type(df.loc["B"])

# %%
df

# %%
df.iloc[1]

# %%
df.loc[["A", "C"]]

# %%
df.loc[["A", "C"], ["x", "y"]]

# %%
df.loc["B", "z"]

# %%
df.iloc[[1, 2], [0, 3]]

# %%
df.iloc[0, 0]

# %% [markdown] lang="de"
# ## Bedingte Auswahl

# %%
df = create_data_frame()
df

# %%
df > 0  # noqa

# %%
df[df > 0]

# %%
df["w"] > 0  # noqa

# %%
df[df["w"] > 0]

# %%
df[df["w"] > 0][["x", "y"]]

# %%
df[(df["w"] > 0) & (df["x"] < 0)]

# %% [markdown] lang="de"
#
# # Information über Data Frames

# %%
df = create_data_frame()
df["txt"] = "a b c d e".split()
df.iloc[1, 1] = np.nan
df

# %%
df.describe()

# %%
df.info()

# %%
df.dtypes

# %% [markdown] lang="de"
# ## Der Index eines Data Frames

# %%
df = create_data_frame()
df["txt"] = "a b c d e".split()
df

# %%
df.reset_index()

# %%
df

# %%
df.reset_index(inplace=True)

# %%
df

# %%
df.rename(columns={"index": "old_index"}, inplace=True)

# %%
df

# %%
df.set_index("txt")

# %%
df

# %%
df.set_index("txt", inplace=True)
df

# %%
df.set_index("old_index", inplace=True)
df

# %%
df.info()

# %%
df.index

# %%
df.index.name = None

# %%
df

# %% tags=["keep"]
