# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Mengen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">13 Mengen.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Mengen

# %%
numbers = {3, 5, 4, 9, 4, 1, 5, 4, 3}
numbers

# %%
type(numbers)

# %%
numbers.add(3)

# %%
numbers

# %%
numbers.union({42})

# %%
numbers

# %%
numbers | {42}

# %%
numbers

# %%
numbers & {2, 3, 4}

# %%
numbers - {2, 3, 4}

# %%
numbers.add(5)

# %%
numbers

# %%
numbers.remove(5)

# %%
numbers

# %%
# numbers.remove(5)

# %%
numbers.discard(5)

# %%
numbers

# %%
3 in numbers

# %%
2 not in numbers

# %%
{2, 3} <= {1, 2, 3, 4}

# %%
{2, 5} <= {1, 2}

# %%
type({})  # Empty dictionary!

# %%
set()

# %%
type(set())

# %% tags=["keep"]
philosophy = (
    "Half a bee , philosophically , must ipso facto half not be . "
    "But can it be an entire bee , if half of it is not a bee , "
    "due to some ancient injury ."
)
philosophy

# %%
words = philosophy.lower().split()
words[10:20]

# %%
len(words)

# %%
word_set = set(words)

# %%
len(word_set)

# %%
word_set - {".", ","}

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Mini-Workshop
#
# Schreiben Sie eine Funktion `count_unique_words(text: str)`, die die Anzahle der in
# einem Text vorkommenden Wörter (ohne Wiederholungen und Satzzeichen) zählt. Testen Sie
# die Funktion mit dem in `dickens` gespeicherten String.
#
# ```python
# >>> count_unique_words(dickens)
# 8
# >>>
# ```


# %%
def count_unique_words(text: str):
    word_set = set(text.lower().split()) - {",", "."}
    return len(word_set)


# %% tags=["keep"]
dickens = "It was the best of times , it was the worst of times"

# %% tags=["keep"]
assert count_unique_words(dickens) == 7

# %% tags=["keep"]
assert count_unique_words(philosophy) == 22

# %%
