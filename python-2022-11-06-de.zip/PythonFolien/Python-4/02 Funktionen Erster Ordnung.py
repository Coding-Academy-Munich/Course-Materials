# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Funktionen Erster Ordnung</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Funktionen Erster Ordnung.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Funktionen
#
# In Python sind Funktionen Objekte erster Ordnung, d.h., sie können von
# Variablen referenziert, als Argumente an Funktionen übergeben werden, etc.
#
# Funktionen haben den Typ `Callable`.

# %%
def my_fun(x, y):
    result = x + y
    print(f"my_fun({x}, {y}) -> {result}")
    return result


# %%
from typing import Callable

# %%
isinstance(my_fun, Callable)

# %%
isinstance(pow, Callable)

# %%
isinstance(list, Callable)


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def call_with_two_args(fun):
    print(f"Calling function {fun.__name__!r}")
    result = fun(2, 3)
    print(f"Result is {result}")
    return result


# %%
call_with_two_args(my_fun)

# %%
import operator

call_with_two_args(operator.add)

# %%
call_with_two_args(operator.lt)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop "Filtern von Elementen"
#
# Schreiben Sie eine Funktion
# `return_truthy_elements(a_list: list, fun: Callable) -> list`,
# die eine Liste mit allen Elementen `x` von `a_list` zurückgibt, für die
# `fun(x)` einen wahren Wert liefert.


# %% tags=["keep"]
example_values = [1, 2, 3, 9, 10]


# %% tags=["keep"]
def greater_than_2(n):
    return n > 2


# %% tags=["keep"]
def less_than_10(n):
    return n < 10


# %% tags=["keep"]
from typing import Callable


# %%
def return_truthy_elements(a_list: list, fun: Callable):
    return [x for x in a_list if fun(x)]


# %%
assert return_truthy_elements(example_values, greater_than_2) == [3, 9, 10]

# %%
assert return_truthy_elements(example_values, less_than_10) == [1, 2, 3, 9]

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# # Konstruktor-Funktionen und Methoden

# %%
from dataclasses import dataclass


@dataclass
class Point:
    x: float = 0.0
    y: float = 0.0

    def move(self, dx=0.0, dy=0.0):
        self.x += dx
        self.y += dy


# %%
print(Point)
isinstance(Point, Callable)

# %%
p = Point(1, 2)
print(p)

# %%
print(p.move)
isinstance(p.move, Callable)

# %%
call_with_two_args(p.move)

# %%
print(p)

# %%
p2 = Point(0, 0)
print("p2 =", p2)
print("p  =", p)
call_with_two_args(p2.move)
print("p2 =", p2)
print("p  =", p)


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop "Filtern von Elementen"
#
# Schreiben Sie eine Funktion `my_max(values: list, key: Callable)`, die das Element
# aus `values` zurückgibt, für das `key(value)` den größten Wert zurückgibt. Falls
# mehrere Elemente mit gleichem Wert existieren soll das erste davon zurückgegeben
# werden. Werfen Sie eine `ValueError()` wenn `list` leer ist.
#
# (Verwenden Sie zur Implementierung nicht die Funktion `max()`.)


# %%
def my_max(values: list, key: Callable):
    if list:
        result = values[0]
        result_key = key(result)
        for value in values[1:]:
            value_key = key(value)
            if value_key > result_key:
                result, result_key = value, value_key
        return result
    else:
        raise ValueError("Empty list")


# %% tags=["keep"]
from operator import neg

int_values = [1, 2, 5, 2, 4]
string_values = ["foo", "bar", "quux", "x"]

# %% tags=["keep"]
assert my_max(int_values, lambda x: x) == 5

# %% tags=["keep"]
assert my_max(int_values, neg) == 5

# %% tags=["keep"]
assert my_max(string_values, len) == "quux"

# %% tags=["keep"]
assert my_max(string_values, lambda x: x) == "x"

# %%
assert my_max(string_values, lambda x: x[::-1]) == "quux"
