# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>While-Schleifen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">12 While-Schleifen.py</div> -->

# %% [markdown] lang="de" tags=["private"]
#
# Benötigt user input!

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
#  # While-Schleifen
#
#  Manchmal wollen wir einen Teil eines Programms immer wieder ausführen:
#
#  - Zahlenraten bis die richtige Zahl gefunden wurde
#  - Physik-Simulation bis das Ergebnis genau genug ist
#  - Verarbeitung von Benutzereingaben in interaktiven Programmen
#
#  Wenn wir die Anzahl der Wiederholungen nicht von vornherein wissen,
#  verwenden wir dafür in der Regel eine While-Schleife.

# %% lang="de"
durchlauf = 0
while durchlauf < 3:
    print(f"Durchlauf {durchlauf}")
    durchlauf += 1  # <==


# %% lang="de" tags=["keep"]
def führe_ein_experiment_aus(versuch_nr):
    """Führt ein Experiment aus
    Gibt True zurück wenn das Experiment erfolgreich war, andernfalls False.
    """
    print(f"Versuch Nr. {versuch_nr} gestartet...", end="")
    from random import random

    if random() > 0.8:
        print("Erfolg!")
        return True
    else:
        print("Fehlschlag.")
        return False


# %% lang="de" tags=["keep"]
versuch_nr = 0

while not führe_ein_experiment_aus(versuch_nr):
    versuch_nr += 1

print("Wir haben einen erfolgreichen Versuch ausgeführt.")

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
#  ## Beenden von Schleifen
#
# Manchmal ist es leichter, die Abbruchbedingung einer Schleife im Rumpf zu
# bestimmen, statt am Anfang. Mit der Anweisung `break` kann man eine
# Schleife vorzeitig beenden:

# %% lang="de" tags=["keep"]
i = 1
while i < 10:
    print(i)
    if i % 3 == 0:
        break
    i += 1
print("Nach der Schleife:", i)


# %%
def annoy_user():
    while True:
        text = input("Say hi! ")
        if text.lower() == "hi":
            break
        else:
            print("You chose", text)


# %%
# annoy_user()

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Ratespiele
#
# Die folgenden einfachen "Spiele" erlauben dem Spieler unbegrenzt viele
# Eingaben. Daher ist es sinnvoll, sie mit einer While-Schleife zu
# implementieren.
#
# ### Raten eines Wortes
#
# Implementieren Sie eine Funktion `rate_wort(lösung)`, die den Benutzer so
# lange nach einem Wort fragt, bis das eingegebene Wort der Lösung entspricht.

# %% lang="de"
def rate_wort(lösung):
    geratenes_wort = input("Bitte geben Sie ein Wort ein: ")
    while geratenes_wort != lösung:
        geratenes_wort = input("Bitte versuchen Sie es nochmal: ")
    print("Genau!")


# %% lang="de"
# rate_wort("Haus")

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Zahlenraten
#
# Implementieren Sie eine Funktion `rate_zahl(lösung)`, die den Benutzer so
# lange nach einer Zahl fragt, bis er die Lösung erraten hat. Nach jeder
# Eingabe soll dem Benutzer angezeigt werden, ob die eingegebene Zahl zu
# groß, zu klein oder richtig ist.

# %% lang="de"
def rate_zahl(lösung):
    geratene_zahl = input("Bitte geben Sie eine Zahl ein: ")
    while int(geratene_zahl) != lösung:
        if int(geratene_zahl) < lösung:
            print(f"{geratene_zahl} ist zu klein.")
        else:
            print(f"{geratene_zahl} ist zu groß.")
        geratene_zahl = input("Bitte versuchen Sie es noch einmal: ")
    print("Sie haben gewonnen!")


# %% lang="de"
# rate_zahl(23)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Wie müssen Sie Ihre Lösung modifizieren, damit der Spieler durch Eingabe
# einer leeren Zeichenkette das Spiel abbrechen kann?

# %%
def rate_zahl_1(lösung):
    geratene_zahl = input("Bitte geben Sie eine Zahl ein: ")
    while geratene_zahl and int(geratene_zahl) != lösung:
        if int(geratene_zahl) < lösung:
            print(f"{geratene_zahl} ist zu klein.")
        else:
            print(f"{geratene_zahl} ist zu groß.")
        geratene_zahl = input("Bitte versuchen Sie es noch einmal: ")
    if geratene_zahl:
        print("Sie haben gewonnen!")
    else:
        print("Aufgeben ist feige!")


# %%
# rate_zahl_1(23)

# %% [markdown] lang="de" tags=["subslide", "alt"] slideshow={"slide_type": "subslide"}
# Lösung unter Zuhilfenahme der Funktion `klassifiziere_zahl`

# %% lang="de"
def classify_number(guess, solution):
    if guess < solution:
        return False, "Your guess is too small! "
    elif guess > solution:
        return False, "Your guess is too large! "
    else:
        return True, "You won!"


# %% lang="de"
def guess_number_2(solution):
    guess = input("Please enter a guess: ")
    is_success, hint = classify_number(int(guess), solution)
    while not is_success:
        guess = input(hint)
        is_success, hint = classify_number(int(guess), solution)
    print("You won!")

# %% lang="de"
# rate_zahl_2(23)
