# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Grundlegende Datentypen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Grundlegende Datentypen.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Variablen und Datentypen
#
# Zahlen und Arithmetik:

# %%
17 + 4

# %%
1.5 + 7.4

# %%
1 + 2 * 3

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
type(1)

# %%
type(1.0)

# %%
type("1")

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
10000000000000000000000000000000000000000000000000 + 1

# %%
type(10000000000000000000000000000000000000000000000000)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Zeichenketten

# %%
"Hello, world!"

# %% lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# fmt: off
'Das ist ein Text'
# fmt: on

# %%
str(1 + 2)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
"1" + "2"

# %% lang="de"
"""Ein Text,
der über mehrere Zeilen geht."""

# %% lang="de"
"Benachbarte " "Stringliterale " "werden zusammengefügt"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Anzeige von Werten mit der `print()` Funktion
#
# Um mehrere Werte anzuzeigen kann man die `print()`-Funktion verwenden:
#
# `print(...)` gibt den in Klammern eingeschlossenen Text auf dem Bildschirm
# aus.

# %%
print(123)

# %%
print("Hello, world!")

# %%
print("Der Wert von 1 + 1 ist", 1 + 1, ".")

# %%
print("Der Wert von 1 + 1 ist", 1 + 1, ".", sep="")

# %%
print("a", end=", ")
print("b", end=", ")
print("c")

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Variablen

# %%
answer = 42

# %%
my_value = answer + 2

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Variablen
#
# <img src="img/variables-01.svg" style="float:right;margin:auto;width:50%"/>
#
# Eine *Variable* ist
# - ein <span style="color:red;">"Verweis"</span> auf ein "Objekt"
# - der einen <span style="color:red;">Namen</span> hat.
#
# <span style="color:blue;">Ein Objekt</span> kann von
# <span style="color:blue;">mehreren Variablen</span><br/>
# referenziert werden!

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Typen

# %%
type(123)

# %%
type("Foo")

# %%
answer = 42
print(type(answer))
answer = "Hallo!"
print(type(answer))

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Vordefinierte Funktionen

# %%
print("Hello, world!")

# %%
int("123")

# %%
int(3.8)

# %%
round(4.4)

# %%
round(4.6)

# %% tags=["keep"]
print(round(0.5), round(1.5), round(2.5), round(3.5))


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mini-Workshop: Vordefinierte Funktionen
#
# In diesem Workshop sollen Sie einige Aufgaben mit vordefinierten Funktionen lösen.
# Manche der Funktionen wurden noch nicht besprochen. Verwenden Sie die [Tabelle der
# vordefinierten
# Funktionen](https://docs.python.org/3/library/functions.html#built-in-functions)
# um geeignete Kandidaten zu finden.

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Wandeln Sie die Zahl `1.5` in einen String um.

# %%
str(1.5)

# %% [markdown] lang="de"
#
# Bestimmen Sie das Maximum der Zahlen 2.5 und 1.7 mit einer eingebauten Funktion.

# %%
max(2.5, 1.7)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Wandeln Sie den String "1.234" in eine Gleitkommazahl um und addieren Sie `2.345`
# dazu.

# %%
float("1.234") + 2.345
