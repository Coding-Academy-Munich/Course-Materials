# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Funktionen (Teil 3)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">07 Funktionen (Teil 3).py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Funktionen ohne Parameter
#
# - Eine Funktion kann auch ohne formale Parameter definiert werden.
# - Sowohl bei der Definition, als auch beim Aufruf müssen die Klammern
#   trotzdem angegeben werden.

# %% lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
def null():
    return 0


# %% lang="de"
null()


# %% lang="de"
# Fehler: 'Aufruf' ohne Klammern
null

# %% lang="de"
# Fehler: 'Aufruf' ohne Klammern
# null + 1

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# # Funktionen mit Seiteneffekten
#
# Funktionen können
#
# - Werte berechnen: `round(3.3)`
# - Seiteneffekte haben: `print("Hans")`

# %%
round(3.3)

# %%
print("Hans")

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Das gilt auch für benutzerdefinierte Funktionen:

# %%
def add1(x):
    return x + 1


# %%
add1(10)

# %%
def say_hi(name):
    print("Hi", name)


# %%
say_hi("John")

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Der Rückgabewert `None`
#
# - Der Rückgabewert der Funktion `print()` ist der spezielle Wert `None`.
# - Dieser Wert wird vom Notebook nicht *als Ergebnis* angezeigt.

# %%
say_hi("Hans")

# %%
x = say_hi("Hans")
x is None

# %%
print(None)


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - Funktionen können Seiteneffekte haben
#     - Z.B. durch Aufruf von `print`
# - Diese werden ausgeführt, wenn ein Funktionsaufruf ausgewertet wird
# - Auch Funktionen mit Seiteneffekten geben einen Wert zurück
#     - Oft ist das der spezielle Wert `None`
#     - Wenn eine Funktion `None` zurückgibt brauchen wir keine explizite
#       `return`-Anweisung

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def say_hello():
    print("Hello, world!")
    print("Today is a great day!")


# %%
say_hello()

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Aufruf mit benannten Argumenten
#
# Beim Aufruf einer Funktion können Argumente
# mit einem Parameternamen assoziiert werden, indem man sie in der Form
# `parameter=wert` schreibt.
#
# - Der Wert wird dann für den entsprechenden Parameter eingesetzt
# - Benannte Argumente müssen nach positionalen Argumenten kommen
# - Werden alle Argumente benannt, so wird der Aufruf unabhängig von der
#   Argumentreihenfolge

# %%
def say_hi(greeting, name="world", end="."):
    print(greeting + " " + name + end)


# %%
say_hi("Hello", end="!")
say_hi(name="Jill", greeting="Howdy")
# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Piraten (Teil 2)
#
# In einer früheren Aufgabe haben wir die Aufteilung der Beute für Ihre
# Piratencrew folgendermaßen berechnet:
#
# - Die Beute wird gleichmäßig auf alle Piraten verteilt. Dabei werden nur
#   ganze Golddublonen ausgezahlt.
# - Den Rest der Golddublonen erhält der Kapitän.


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Jetzt droht Ihre Piraten-Crew aber zu meutern, weil die Berechnung der
# Beuteaufteilung zu lange dauert.
#
# Schreiben Sie eine Funktion `drucke_aufteilung_der_beute(dublonen, piraten)`,
# die die Aufteilung berechnet und in folgendem Format ausgibt:
#
# ```
# Piraten: 8
# Golddublonen: 17
# Jeder Pirat erhält: 2 Golddublone(n)
# Kapitän erhält extra: 1 Golddublone(n)
# ```

# %% lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
def drucke_aufteilung_der_beute(dublonen, piraten):
    dublonen_pro_pirat = dublonen // piraten
    dublonen_kapitän = dublonen % piraten
    print("Piraten:", piraten)
    print("Golddublonen:", dublonen)
    print("Jeder Pirat erhält:", dublonen_pro_pirat, "Golddublone(n)")
    print("Kapitän erhält extra:", dublonen_kapitän, "Golddublone(n)")


# %% lang="de"
drucke_aufteilung_der_beute(17, 8)
