# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Iteratoren und Generatoren</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">11 Iteratoren und Generatoren.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Iteration über verschiedene Typen
#
# Wir haben gesehen, dass z.B. die `for`-Schleife in Python für verschiedene
# Typen verwendbar ist:

# %%
for x in [1, 2, 3]:
    print(x)

# %%
for x in "abc":
    print(x)

# %% [markdown] lang="de"
# Der Mechanismus mit dem Python das erreicht sind Iteratoren:

# %%
my_list = [1, 2, 3]

# %%
it = iter(my_list)
it

# %%
next(it)

# %%
next(it)

# %%
next(it)

# %%
# next(it)

# %%
for x in my_list:
    print(x)

# %%
for x in iter(my_list):
    print(x)

# %% [markdown] lang="de"
# Als Typ von iterierbaren Objekten wird oft `Iterable` verwendet:

# %%
from typing import Iterable

# %%
isinstance(my_list, Iterable)

# %%
isinstance(iter(my_list), Iterable)


# %%
class MyClass:
    def __iter__(self):
        return iter([1, 2, 3])


# %%
my_obj = MyClass()

# %%
isinstance(my_obj, Iterable)

# %%
for x in my_obj:
    print(x)

# %%
list_it = iter(my_list)
obj_it = iter(my_obj)

# %%
tuple(list_it)

# %%
tuple(list_it)

# %%
tuple(obj_it)

# %%
tuple(obj_it)

# %%
a, b, c = my_obj
print(f"a = {a}, b = {b}, c = {c}")

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Einige Typen können mehr als eine Art von Iterator liefern:

# %%
my_dict = dict(a=1, b=2, c=3)
my_dict

# %%
tuple(my_dict)

# %%
tuple(my_dict.keys())

# %%
tuple(my_dict.values())

# %%
tuple(my_dict.items())

# %%
tuple(range(3))

# %% [markdown] lang="de"
# ## Wie funktioniert die `for`-Schleife?

# %%
r = range(3)
r

# %%
for x in range(3):
    print(x, end=" ")

# %%
_r = range(3)
_temp_iter = iter(_r)
while True:
    try:
        x = next(_temp_iter)
    except StopIteration:
        break
    print(x, end=" ")

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Generatoren
#
# - Es ist nicht effizient eine Liste zu konstruieren, wenn wir sie nur zum
#   Iterieren über ihre Elemente verwenden wollen
# - Python bietet die Möglichkeit Generatoren zu definieren, die iterierbar
#   sind, aber nicht den Overhead einer Liste haben
# - Die einfachste Form ist mit Generator Expressions:


# %%
squares_list = [n * n for n in range(10)]

# %%
for i in squares_list:
    print(i)

# %%
gen = (n * n for n in range(10))
gen

# %%
for i in gen:
    print(i, end=" ")

# %%
for i in gen:
    print(i, end=" ")

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Es ist auch möglich komplexere Generator-Expressions zu schreiben:

# %%
for i, j, k in ((n, m, n * m) for n in range(2, 5) for m in range(n, 5)):
    print(f"{i}, {j}, {k}")

# %%
gen = (n * n for n in range(3))
repr(gen)

# %%
it = iter(gen)
repr(it)

# %%
next(it)

# %%
next(it)

# %%
next(it)

# %% [markdown] lang="de"
# `it` ist "erschöpft," man kann keine neuen Werte bekommen:

# %%
# next(it)

# %%
# next(it)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop "Generator-Expressions"
#
# - Berechnen Sie die Summe der ersten 100 Quadratzahlen unter Zuhilfenahme einer
#   Generator-Expression.
# - Berechnen Sie die Summe aller Zahlen zwischen 100 und 500, die durch 7 teilbar
#   sind unter Zuhilfenahme einer Generator-Expression.
# - Schreiben Sie eine Funktion
#   `all_powers(numbers: Iterable[int], powers: Iterable[int])`,
#   die eine Liste zurückgibt, deren Elemente Tupel sind, die alle Potenzen
#   aus `powers` von Elementen aus `numbers` enthalten
#


# %%
sum(x**2 for x in range(100))

# %%
sum(x for x in range(100, 501) if x % 7 == 0)


# %%
def all_powers(numbers: Iterable[int], powers: Iterable[int]):
    return [tuple(n**p for p in powers) for n in numbers]


# %% tags=["keep"]
assert all_powers(range(3), range(3)) == [(1, 0, 0), (1, 1, 1), (1, 2, 4)]

# %% tags=["keep"]
assert all_powers([10, 11, 12], [2, 3]) == [(100, 1000), (121, 1331), (144, 1728)]
