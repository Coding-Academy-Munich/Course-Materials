# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Assertions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Assertions.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Assertions
#
# Das Assert-Statement ist nur eine kompakte Schreibweise, um eine bestimmte Art von
# Fehler (einen `AssertionError`) auszulösen, wenn eine Bedingung falsch ist:

# %%
my_var = 1

# %%
assert my_var == 1

# %%
if my_var != 1:
    raise AssertionError()

# %%
assert my_var == 2

# %%
if my_var != 2:
    raise AssertionError()
