# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Pandas Series</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Pandas Series.py</div> -->

# %% [markdown] lang="de"
#
# # Pandas Typ `Series`
#
# Eine Pandas `Series` Instanz stellt eine Folge von Werten dar, ähnlich wie
# eine Python-Liste. Die Elemente einer Serie können über ihren numerischen
# Index abgerufen werden, aber zusätzlich kann eine Serie einen semantisch
# sinnvollen Index haben (z. B. für Zeitreihen).
#
# Intern wird eine Pandas-Serie durch ein Numpy-Array unterstützt, daher sind
# die meisten der Numpy-Operationen auch auf Serien anwendbar sind.
#
# Darüber hinaus ist es einfach (und billig), Serien nach Numpy zu konvertieren.

# %% tags=["keep"]
import numpy as np
import pandas as pd

# %% [markdown] lang="de"
# ## Erzeugung
#
# ### Aus Listen

# %%


# %%

# %% [markdown] lang="de"
# ### Aus Listen mit Index

# %%

# %% [markdown] lang="de"
# ### Aus Range oder Iterable

# %%

# %%

# %%

# %% [markdown] lang="de"
# ### Aus Dictionary

# %%

# %% [markdown] lang="de"
# ## Indizes und Operationen

# %% tags=["keep"]
food1 = pd.Series({"Ice Cream": 2.49, "Cake": 4.99, "Fudge": 7.99})
food2 = pd.Series({"Cake": 4.99, "Ice Cream": 3.99, "Pie": 3.49, "Cheese": 1.99})


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%

# %%


# %%


# %%


# %%


# %%


# %%


# %%

# %% [markdown] lang="de"
# ### Mehrfach vorkommende Index-Werte

# %%


# %%


# %%


# %%


# %%


# %%


# %% tags=["keep"]
type(all_food["Pie"])


# %%

# %% [markdown] lang="de"
# ### Sortierte und unsortierte Indizes

# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %% tags=["keep"]
# all_food['Cake':'Fudge']


# %%

# %% [markdown] lang="de"
#
# **Wichtig:** Der ober Wert der Slice, `"Fudge"` ist im Resultat enthalten!

# %% [markdown] lang="de"
# ## Fehlende Werte

# %%


# %%


# %%


# %%

# %% tags=["keep"]
