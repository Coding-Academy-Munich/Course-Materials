# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Kontrollstrukturen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">10 Kontrollstrukturen.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# # `if`-Anweisungen
#
# - Wir wollen ein Programm schreiben, das bestimmt ob eine Zahl eine Glückszahl
#   ist oder nicht:
#     - 7 ist eine Glückszahl
#     - Alle anderen Zahlen sind es nicht.
# - Wir benötigen dazu die `if`-Anweisung:

# %% tags=["subslide"] lang="de" slideshow={"slide_type": "subslide"}

# %% lang="de"

# %% lang="de"

# %% lang="de" tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def ist_glückszahl_1(zahl):
    print("Ist", zahl, "eine Glückszahl?")

    if zahl == 7:
        print("Ja!")
    else:
        print("Leider nein.")

    print("Wir wünschen Ihnen alles Gute.")


# %% lang="de" tags=["keep"]
ist_glückszahl_1(1)

# %% lang="de" tags=["keep"]
ist_glückszahl_1(7)


# %% lang="de" tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def ist_glückszahl_2(zahl):
    if zahl == 7:
        print(zahl, "ist eine Glückszahl!")
        print("Sie haben sicher einen super Tag!")
    else:
        print(zahl, "ist leider keine Glückszahl.")
        print("Vielleicht sollten Sie heute lieber im Bett bleiben.")
        print("Wir wünschen Ihnen trotzdem alles Gute.")


# %% lang="de" tags=["keep"]
ist_glückszahl_2(1)

# %% lang="de" tags=["keep"]
ist_glückszahl_2(7)

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Struktur einer `if`-Anweisung (unvollständig):
#
# ```python
# if <Bedingung>:
#     Rumpf, der ausgeführt wird, wenn <Bedingung> wahr ist
# else:
#     Rumpf, der ausgeführt wird, wenn <Bedingung> falsch ist
# ```
# - Nur das `if` und der erste Rumpf sind notwendig
# - Falls ein `else` vorhanden ist, so darf der entsprechende Rumpf nicht leer sein
#

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Volljährig

# %% [markdown] lang="de"
#
# Schreiben Sie eine Funktion `drucke_volljährig(alter)`, die `Volljährig`
# auf dem Bildschirm ausgibt, wenn `alter >= 18` ist und `Minderjährig` sonst.

# %% lang="de"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Testen Sie `drucke_volljährig(alter)` mit den Werten 17 und 18.

# %% lang="de"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Gerade Zahl


# %% [markdown] lang="de"
#
# Schreiben Sie eine Funktion `ist_gerade(zahl)`, die `True` zurückgibt,
# falls `zahl` gerade ist und `False`, falls `zahl` ungerade ist.

# %% lang="de"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Schreiben Sie Assertions, die testen ob `ist_gerade()` für die Argumente 0, 1
# und 8 das korrekte Ergebnis liefert.

# %% lang="de"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Schreiben Sie eine Funktion `drucke_ist_gerade(zahl)`, die
#
# - `{zahl} ist gerade.` auf dem Bildschirm ausgibt, falls `zahl` gerade ist und
# - `{zahl} ist ungerade.` auf dem Bildschirm ausgibt, falls `zahl` nicht
#   gerade ist.
#
# Verwenden Sie dabei dei Funktion `ist_gerade()` um zu überprüfen, ob `zahl`
# gerade ist.

# %% lang="de"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Testen Sie `drucke_ist_gerade(zahl)` mit den Werten 0, 1 und 8.

# %% lang="de"

# %%
# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Verkürzte Ausgabe


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Schreiben Sie eine Funktion `fits_in_line(text: str, line_length: int = 72)`,
# die `True` oder `False` zurückgibt, je nachdem ob `text` in einer Zeile der
# Länge `line_length` ausgegeben werden kann oder nicht:
# ```python
# >>> fits_in_line("Hallo")
# True
# >>> fits_in_line("Hallo", 3)
# False
# ```
#
# *Hinweis:* Sie können die Länge eines Strings mit der Funktion `len()` bestimmen:
# ```python
# >>> len("abcd")
# 4
# ```


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Schreiben Sie eine Funktion `print_line(text: str, line_length:int = 72)`,
# die
# * `text` auf dem Bildschirm ausgibt, falls das in einer Zeile der Länge
#   `line_length` möglich ist
# * `...` ausgibt, falls das nicht möglich ist.
#
# ```python
# >>> print_line("Hallo")
# Hallo
# >>> print_line("Hallo", 3)
# ...
# >>>
# ```

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%
