# %% tags=["keep"]
from enum import IntEnum

# %% tags=["keep"]
class EmployeeType(IntEnum):
    REGULAR = 0
    HOURED = 1
    COMMISSIONED = 2
