# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>User-defined Collections</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">13 User-defined Collections.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_200_object_orientation/topic_210_defining_collections.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# It is possible to define a custom type whose instances behave like lists.
# To simplify the implementation we delegate the handling of the elements to a list
# that is stored as an attribute. This kind of composition is found very frequently
# in object-oriented programming.

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%


# %% tags=["keep"]
