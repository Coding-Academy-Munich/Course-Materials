# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Class Methods and Factories</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">14 Class Methods and Factories.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_200_object_orientation/topic_220_a3_class_methods_and_factories.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Class methods and factories
#
# A factory is a function (or class) used to build object instances. Class
# methods are a powerful feature of Python that is useful for implementing
# factories.
#
# Class methods are methods typically called on a class (as opposed to an
# object). In contrast to static methods (which receive no information about the
# class they are called on) they are passed a class object as argument that can
# be used to perform operations that depend on the class (such as creating
# instances).

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# If the constructor arguments of a subclass are compatible with the superclass,
# the class methods of the superclass can directly be used as factories for the
# subclass.

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Attributes of classes
#
# Most attributes are defined at the instance level, i.e.,
# each object has its own values for the attributes. But sometimes it
# makes sense to define attributes on the class level as well:

# %%

# %%

# %%

# %%

# %%

# %%


# %% [markdown] lang="en"
# ### Inheritance

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
