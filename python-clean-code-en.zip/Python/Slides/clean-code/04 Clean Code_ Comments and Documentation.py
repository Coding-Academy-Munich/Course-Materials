# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Clean Code: Comments and Documentation</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Clean Code_ Comments and Documentation.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_230_clean_code/topic_150_a3_comments_and_docs.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Clean Code: Comments and Documentation

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Docstrings
#
# From [PEP-257](https://peps.python.org/pep-0257/):
#
# A docstring is a string literal that occurs as the first statement in a
# module, function, class, or method definition. Such a docstring becomes the
# `__doc__` special attribute of that object.
#
# All modules should normally have docstrings, and all functions and classes
# exported by a module should also have docstrings. Public methods (including
# the `__init__` constructor) should also have docstrings. A package may be
# documented in the module docstring of the `__init__.py` file in the package
# directory.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Docstring conventions
#
# - One-line docstrings
#   - Use triple quotes
#   - No blank line before or after
#   - A phrase ending in a period
#   - Written as a command: "Do this", "Return that value"
#   - Is not the function's signature (can be obtained by introspection)
#   - More information in
#     [PEP-257](https://peps.python.org/pep-0257/#one-line-docstrings)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Docstring conventions
#
# - Multi-line docstrings
#   - Summary line just like a one-line docstring
#   - Summary line is followed by a blank line
#   - Then there is a more elaborate description, possibly including doctests
#   - The docstring is followed by a blank line
#   - More information in
#     [PEP-257](https://peps.python.org/pep-0257/#multi-line-docstrings)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Comments
#
# - Comments compensate for our failure to express ourselves in code
# - If possible, express yourself in code, not comments!
#   - Whenever you want to write a comment, check that you cannot do it in code
#   - In particular, write assertions or doctests if possible
#   - Use explanatory variables

# %% tags=["keep"]
def add(x, y):
    """Compute the sum of two numbers.

    >>> add(1, 2)
    3
    >>> add(0, -2)
    -2
    """
    return x + y


# %% tags=["keep"]
days_of_work = 4

# %% tags=["keep"]
# Multiply the seconds in a day times the days of work.
duration_in_seconds = 60 * 60 * 24 * days_of_work

# %% tags=["keep"]
SECONDS_PER_DAY = 60 * 60 * 24
duration_in_seconds = SECONDS_PER_DAY * days_of_work


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## How comments fail
#
# - Comments are difficult to maintain
# - Therefore, they often lie
# - They don’t get changed when code gets updated
# - They don’t get moved when code gets moved

# %%
# ```python
# # Check to see if the employee is eligible for full benefits
# if (employee.flags & HOURLY_FLAG) and (employee.age > 65):
#     ...
# ```
#
# versus
#
# ```
# if employee.is_eligible_for_full_benefits():
#     ...
# ```

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## PEP-8 Guidelines for Comments
#
# Follow [PEP-8](https://peps.python.org/pep-0008/#comments) guidelines for
# comments:
#
# - Keep comments up-to-date when the code changes
# - Comments should be complete sentences.
#   - First word is capitalized, unless it is an identifier
#   - Identifiers should never be altered
#   - Use two spaces after a sentence-ending period in multi-sentence comments
# - Ensure that comments are clear and easily understandable
# - Python coders from non-English speaking countries: please write your
#   comments in English, unless you are 120% sure that the code will never be
#   read by people who don’t speak your language.


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Good Comments
#
# Comments are good if they
#
# - are legally required
# - explain concepts that cannot be expressed in code
# - explain the intent of the code
# - explain code that you cannot clean up (e.g., a published interface)
# - document published interfaces (e.g., doxygen)
# - are `TODO`` comments (if used sparingly)
# - are used for amplification ("This is very important, because...")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Bad Comments
#
# - Unclear comments (mumbling)
#
# Suppose that the following comment is in fact correct. What does it tell us?

# %% tags=["keep"]
try:
    with open("my-app.cfg", mode="r", encoding="utf-8"):
        ...
except FileNotFoundError:
    # Somebody else has already loaded the defaults.
    pass


# %% [markdown] lang="en"
#
# - Redundant comments (takes longer to read than the code without being clearer)

# %% tags=["keep"]
def read_and_apply_configuration(file):
    ...


# %% tags=["keep"]
# Read the configuration from file `my-app.cfg`. The file has to be readable and
# in UTF-8 encoding. If the file cannot be found we simply ignore the attempt.
# If the file is indeed found, we read it and apply the configuration to the
# system.
try:
    with open("my-app.cfg", mode="r", encoding="utf-8") as file:
        read_and_apply_configuration(file)
except FileNotFoundError:
    pass


# %% [markdown] lang="en"
#
# - Misleading comments

# %% tags=["keep"]
# Return a new list that is the concatenation of the elements in `list_1` and
# `list_2`.
def concatenate_lists(list_1, list_2):
    if not list_1:
        return list_2
    elif not list_2:
        return list_1
    else:
        return list_1 + list_2


# %% tags=["keep"]
assert concatenate_lists([1, 2], [3, 4]) == [1, 2, 3, 4]

# %% [markdown] lang="en"
#
# Based on the comment you wouldn't expect the following behavior:

# %% tags=["keep"]
x = [1, 2]
assert concatenate_lists(x, []) is x
assert concatenate_lists([], x) is x

# %% [markdown] lang="en"
#
# - Mandated comments (by coding guidelines, not law)
# - Journal comments (history of the file)


# %% tags=["keep"]
# file: widget.py
#
# Changes made to the file:
#
# 2022-08-10: Added a frobnicator as proposed by Jane
# 2022-08-11: Twiddled the frobnicator's parameters
# 2022-08-12: Further tweaks to the frobnicator settings
# 2022-08-13: Added flux compensation to the frobnicator
# 2022-08-14: Improved flux compensation
# 2022-09-03: Revisited flux compensation after discussion with Joe
#
class Frobnicator:
    pass


# %% [markdown] lang="en"
#
# - Noise comments


# %% tags=["keep"]
class FluxCompensator:
    # The `__init__()` method of the flux compensator.
    def __init__(self) -> None:
        ...


# %% tags=["keep"]
# Hourly wage in US$
HOURLY_WAGE_IN_USD = 80


# %% [markdown] lang="en"
#
# - Position Markers


# %% tags=["keep"]
class MyVeryLargeClass:
    ####################################################
    # Initialization Methods
    ####################################################
    def init(self):
        ...

    def init_in_another_way(self):
        ...

    ####################################################
    # Computations
    ####################################################
    def compute_this(self):
        ...

    def compute_that(self):
        ...

    ####################################################
    # State Updates
    ####################################################
    def set_some_state(self, x):
        ...


# %% [markdown] lang="en"
#
# - Attributions and bylines

# %% tags=["keep"]
# Added by Jack <jack@example.org> on 2018-03-12
def some_function(x, y):
    return x + y


# %% [markdown] lang="en"
#
# - Commented-out code
#   - Has a tendency to never get deleted
#   - Unclear why it is there: was it meant to be deleted or commented back in?
#   - Rely on the source control system and delete the code

# %% tags=["keep"]
# def some_function(x, y):
#     return x + y

# %% tags=["keep"]
def some_other_function(x, y):
    # z = x + y
    # return z
    return 123


# %% [markdown] lang="en"
#
# - HTML-Comments
#
# In Python, markup in comments is either written in Markdown or in
# reStructuredCode (RST):

# %% tags=["keep"]
# <p><strong>Important:</strong></p>
# <ul>
#   <li>
#     Don&#39;t use <code>frobnicator_1</code> to tweak
#     <code>flux_compensator_2</code> because they are not
#     coherent!
#   </li>
#   <li>
#     Make sure that <code>fuzzbox_2</code> is turned to
#     at least 11 before plugging in the guitar.
#   </li>
# </ul>


# %% tags=["keep"]
# **Important:**
#
# - Don't use `frobnicator_1` to tweak `flux_compensator_2` because they are not
#   coherent!
# - Make sure that `fuzzbox_2` is turned to at least 11 before plugging in the
#   guitar.

# %% [markdown] lang="en"
#
# - Non-local information

# %% tags=["keep"]
# This is set to its correct value by `frob_foo()` in file `frobnicator.py`.
foo = 123

# %% [markdown] lang="en"
#
# - Too much information

# %% tags=["keep"]

# Implement protocol handling according to ABC Standard 212-3.
#
# This was first proposed by Steve in a meeting in 2013, but at the time we had
# no compatible implementation of the support libraries available. We therefore
# shelved the discussion until Tina brought the topic up in the famous all-hands
# meeting of October 2019. There were some initial problems, but we finally
# succeeded in getting a running implementation working in 2021. This contains a
# bug that is still present in the current code base that causes the system to
# crash when talking to a client that implements variant /4 of the protocol.
# Finally, in early 2022 we also adapted this implementation for the XYZ device
# series.

# %% [markdown] lang="en"
#
# - Unobvious connection to the code

# %% tags=["keep"]
# Adjust for target endianness and buffer size
foo = max((foo + 7) * 2, 256)
