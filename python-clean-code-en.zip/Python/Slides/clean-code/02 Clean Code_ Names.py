# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Clean Code: Names</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Clean Code_ Names.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_230_clean_code/topic_130_a3_names.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Clean Code: Names
#
# Never underestimate the power of names!

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Names are a powerful tool for communication
# - They are everywhere in the program
# - They tie code to domain concepts

# %% tags=["keep"]
def foo(a: float, b: float) -> float:
    if b > 40.0:
        raise ValueError("Not allowed!")
    return 40.0 * a + 60.0 * b


# %%
foo(40.0, 3.5)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
REGULAR_PAY_PER_HOUR = 40.0
OVERTIME_PAY_PER_HOUR = 60.0
MAX_ALLOWED_OVERTIME = 40.0


# %%
class TooMuchOvertimeError(ValueError):
    pass


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def compute_total_salary(regular_hours_worked: float,
                         overtime_hours_worked: float) -> float:
    if overtime_hours_worked > MAX_ALLOWED_OVERTIME:
        raise TooMuchOvertimeError(
            f"Not allowed to work {overtime_hours_worked:.1f} hours overtime!")
    regular_pay = regular_hours_worked * REGULAR_PAY_PER_HOUR
    overtime_pay = overtime_hours_worked * OVERTIME_PAY_PER_HOUR
    return regular_pay + overtime_pay


# %%
compute_total_salary(40.0, 3.5)

# %%
# compute_total_salary(20.0, 50.0)

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
from dataclasses import field, dataclass


@dataclass
class BadNames:
    the_list: list = field(default_factory=list)

    def get_them(self):
        list1 = []
        for x in self.the_list:
            if x[0] == 1:
                list1.append(x)
        return list1


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
from enum import IntEnum


class Status(IntEnum):
    FLAGGED = 1
    UNFLAGGED = 2


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
@dataclass
class Cell:
    index: int
    status: Status = Status.UNFLAGGED
    bomb_count: int = 0


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
Board = list[Cell]


def make_board(size=64) -> Board:
    return [Cell(index) for index in range(size)]


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
@dataclass
class MineSweeper:
    board: Board = field(default_factory=make_board)

    def get_flagged_cells(self):
        """Return all flagged cells.

        >>> game = MineSweeper()
        >>> game.board[2].status = Status.FLAGGED
        >>> game.get_flagged_cells()
        [Cell(index=2, status=<Status.FLAGGED: 1>, bomb_count=0)]
        """
        return [cell for cell in self.board if cell.status == Status.FLAGGED]


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# To run doctests in a notebook you can use the following statements:


# %% tags=["keep"]
import doctest

# %% tags=["keep"]
doctest.testmod()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Doctests can be run with
#
# ```shell
# $ python -m doctest my_module.py
# ```
# or
#
# ```shell
# $ pytest --doctest-modules my_module.py
# ```

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## How to find good names?
#
# - Select for expressivity, not convenience
# - Use names that say what they mean and mean what they say
#   - Otherwise, maintenance becomes much harder...
#   - ... and most of the costs of software come from maintenance


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## What is a good name?
#
# - Answers
#   - Why does this exist?
#   - What does it do?
#   - How is it used?
# - Is intention-revealing (communicates)
# - (Is generally not easy to find)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## What is a bad name?
#
# - Needs a comment
# - Can only be understood by looking at the code
# - Provides disinformation
# - Does not conform to naming rules

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Clean Code naming rules
#
# Good names
#
# - are self-explanatory
# - are intention-revealing
# - are pronounceable and searchable
# - describe problem, not implementation
# - avoid disinformation and make meaningful distinction
# - avoid encodings (Hungarian notation)
# - use the correct part of speech
# - use scope-length rules

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Python naming rules
#
# - Names follow the conventions of
#   [PEP-8](https://peps.python.org/pep-0008/#naming-conventions)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Self-explanatory names

# %% tags=["keep"]
# Elapsed time in days
d = 0

# %%
elapsed_time_in_days = 0

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Intention-revealing names
#
# Reflect intention, behavior, reason for existence

# %% tags=["keep"]
my_list = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

# %% tags=["keep"]
dpm_lst = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

# %% tags=["alt"]
days_per_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Pronounceable and searchable names

# %% tags=["keep"]
hw_crsr_pxy = [0, 0]

# %%
hardware_cursor_position = [0, 0]


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Describe problem, not implementation
#
# Avoid names that refer to implementation details:
# - They don’t reveal why the code was written the way it is written
# - But communicating intentions is your highest priority!


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
def add_elements(lst):
    return sum(lst)


# %% tags=["keep"]
add_elements(days_per_month)  # Seems reasonable


# %%
def compute_yearly_salary(monthly_salaries):
    return sum(monthly_salaries)


# %%
compute_yearly_salary(days_per_month)  # WHAT?!?

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Avoiding disinformation and making meaningful distinctions
#
# - Names mean something
# - Disinformation:
#   - The name's meaning implies something different than its program code:

# %% tags=["keep"]
verify_configuration = False

# %% tags=["keep"]
if verify_configuration:
    print("Deleting configuration files...")

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
from typing import NamedTuple


# %% tags=["keep"]
class Pair(NamedTuple):
    first: int
    second: int
    third: int


# %%
class Triple(NamedTuple):
    first: int
    second: int
    third: int


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Rules to avoid disinformation
#
# - Avoid platform names sco, aix, nt
#   - Often feature checks are better
# - Don't include a type in a variable name if the variable is not of that type
#   - Mostly: Don't include a type in a variable name at all


# %% tags=["keep"]
vector_of_cards: int = 0

# %%
num_cards = 0

# %%
card_deck: list = [...]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Rules to avoid disinformation
#
# - Be careful with names that differ only slightly


# %% tags=["keep"]
is_melee_defence_available = True
is_melee_defense_available = False

# %% tags=["keep"]
print(is_melee_defence_available == is_melee_defense_available)  # Oops...

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Rules to avoid disinformation
#
# - Use names that mean something

# %% tags=["keep"]
foobar = 0
bar = 1

# %%
number_of_visitors = 0
days_till_release = 1

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Rules to avoid disinformation
#
# - Be consistent when naming

# %% tags=["keep"]
number_of_objects = 10
num_buyers = 12
n_transactions = 2

# %%
num_objects = 10
num_buyers = 12
num_transactions = 2

# %%
n_objects = 10
n_buyers = 12
n_transactions = 2

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Meaningful distinctions
#
# - Use names that express the meaning of concepts as clearly as possible

# %% tags=["keep"]
a1 = "Fluffy"
a2 = "Garfield"

# %%
my_dog = "Fluffy"
jons_cat = "Garfield"

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
INCLUDE_NONE = 0
INCLUDE_FIRST = 1
INCLUDE_SECOND = 2
INCLUDE_BOTH = 3

# %% tags=["keep"]
INCLUDE_NO_DATE = 0
INCLUDE_START_DATE = 1
INCLUDE_END_DATE = 2
INCLUDE_START_AND_END_DATE = 3


# %%
class DatesToInclude(IntEnum):
    NONE = 0
    START = 1
    END = 2
    START_AND_END = 3


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Meaningful distinctions
#
# - Use the same name for the same concept

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
from pathlib import Path

# %% tags=["keep"]
my_path = Path.home()
your_dir = Path.home()
file_loc = Path.home()

# %% tags=["keep"]
my_path = Path.home()
your_path = Path.home()
file_path = Path.home()

# %% tags=["keep"]
my_dir = Path.home()
your_dir = Path.home()
file_dir = Path.home()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Meaningful distinctions
#
# - Use clearly different names for different concepts

# %% tags=["keep"]
MY_EFFICIENT_STRING_PROCESSING_HANDLE = 1
MY_EFFICIENT_STRING_PROCESSING_HANDLER = 2

# %% tags=["keep"]
EFFICIENT_STRING_PROCESSING_FLAG = 1
STRING_PROCESSOR_INDEX = 2

# %%
# But:
tasks = ["do this", "do that"]
for task in tasks:
    print(task)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Mini workshop: Names
#
# The following program uses very bad names. Change the names so that they
# follow the PEP-8 conventions and the rules for good names.


# %% tags=["keep"]
from dataclasses import dataclass, field


# %% tags=["keep"]
# Class representing Line Items:
@dataclass
class LI:
    # number of items
    X: int
    # description of the items
    ChrLst: str
    # price per item
    Y: float

    # compute the total price
    def foo(self):
        return self.X * self.Y


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
# Class representing an Order
@dataclass
class LIManager:
    # a list of line items
    LIVec: list[LI] = field(default_factory=list)

    # compute the total price
    def my_result(self):
        return sum(li.foo() for li in self.LIVec)


# %% tags=["keep"]
# Prepare an order
my_order = LIManager([LI(2, "tea", 0.99), LI(3, "coffee", 0.89)])
print(my_order.my_result())


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
@dataclass
class LineItem:
    num_items: int
    description: str
    price_per_item: float

    def total_price(self):
        return self.num_items * self.price_per_item


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
@dataclass
class Order:
    line_items: list[LineItem] = field(default_factory=list)

    def total_price(self):
        return sum(li.total_price() for li in self.line_items)


# %%
# Prepare an order
my_order = Order([LineItem(2, "tea", 0.99), LineItem(3, "coffee", 0.89)])
print(my_order.total_price())

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Avoid encodings
#
# Avoid Hungarian notation:

# %% tags=["keep"]
i_days = 12
i_month = 3


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Avoid encodings
#
# Avoid member prefixes:


# %% tags=["keep"]
@dataclass
class MyClass:
    m_days: int
    m_months: int


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Avoid encodings
#
# Avoid C/I prefixes: CClass, IInterface


# %% tags=["keep"]
@dataclass
class CMyClass:
    days: int
    months: int


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Use the correct part of speech
#
# - Classes and variables: nouns or noun phrases
# - Functions: verb or verb phrases
# - Enums: often adjectives
# - Boolean variables and functions: often predicates: `is_...`, `has_...`

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
@dataclass
class GoToTheServer:
    def connection(self):
        ...

    def server_availability(self) -> bool:
        return True


# %%
class ServerConnection:
    def connect(self):
        ...

    def is_server_available(self) -> bool:
        return True


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Possibly
#
# Avoid noisy words, such as Manager, Processor, Data, Info

# %% tags=["keep"]
class ObjectManager:
    pass


# %% tags=["keep"]
class ObjectController:
    pass


# %% tags=["keep"]
class DataController:
    pass


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Python-Specific
#
# Avoid getters and setters for accessing attributes:


# %% tags=["keep"]
class MyBox:
    def __init__(self, x) -> None:
        self._x = x

    def get_x(self):
        return self._x

    def set_x(self, new_value):
        self._x = new_value


# %% tags=["keep"]
my_box = MyBox(1)
print(my_box.get_x())
my_box.set_x(200)
print(my_box.get_x())


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
class YourBox:
    def __init__(self, x) -> None:
        self.x = x


# %% tags=["keep"]
your_box = YourBox(1)
print(your_box.x)
your_box.x = 200
print(your_box.x)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Properties can be used to preserve the existing syntax for controlled or
# computed access to attributes:

# %% tags=["keep"]
class YourControlledBox:
    def __init__(self, x) -> None:
        self.x = x

    @property
    def x(self):
        return self._x + 1

    @x.setter
    def x(self, new_value):
        if new_value < 100:
            self._x = new_value + 100
        else:
            self._x = new_value - 100


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
your_box = YourControlledBox(1)
print(your_box.x)
your_box.x = 200
print(your_box.x)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Scope-length rules
#
# - Variables:
#   - Long scope = long name
#   - Short scope = short name
# - Classes and Methods
#   - Long scope = short name
#   - Short scope = long name
#
# **Or:** Use long names for long scopes


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
class FixedSizeOrderedCollectionIndexedByInts:
    pass


# %%
class Array:
    pass
