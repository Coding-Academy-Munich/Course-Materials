# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Clean Code: Functions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Clean Code_ Functions.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_230_clean_code/topic_140_a3_functions.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Clean Code: Functions
#
# Package meaningful operations as carefully named functions
#
# - More readable
# - Easier to test
# - More likely to be reused
# - Less likely to contain errors

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## The first rule about functions
#
# - Functions should be small
# - Even smaller than that!
# - No more than 4 lines!

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## More relaxed rules
#
# (From the C++ Core Guidelines)
#
# - Functions should fit on a screen
# - Break large functions up into smaller cohesive and named functions
# - One-to-five-lines functions should be considered normal


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Do one thing
#
# - Functions should do one thing
# - They should do it well
# - They should do it only

# %%
def compute_save_and_print_results(a: int, b: int, results: list[int]):
    new_result = a + b  # Complex computation...
    results.append(new_result)
    for result in results:
        print(result)
    return new_result


# %%
my_results = [12, 43]
new_result = compute_save_and_print_results(2, 4, my_results)
print(my_results)


# %%
def compute_result(a: int, b: int) -> int:
    return a + b


# %%
def save_result(new_result: int, results: list[int]):
    results.append(new_result)


# %%
def print_results(results: list[int]):
    for result in results:
        print(result)


# %%
# Better but still sketchy (see later for further refinement):
def process_new_sensor_data(a: int, b: int, results: list[int]):
    new_result = compute_result(a, b)
    save_result(new_result, results)
    print_results(results)


# %%
your_results = [12, 43]
compute_save_and_print_results(2, 4, your_results)
print(your_results)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Abstraction levels
#
# Everything the function does in its body should be one (and only one) level of
# abstraction below the function itself.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## "To" paragraphs: Checking levels of abstraction
#
# To render_page_with_setups_and_teardowns
#
# We check to see whether the page is a test page and
#
# if so, we include the setups and teardowns.
#
# In either case we render the page in HTML


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## The Step-Down Rule
#
# - We want code to read like a top-down narrative
# - Every function should be followed by those one level of abstraction below it

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini workshop: Do one thing
#
# The function `handle_money_stuff()` does more than one thing.
#
# Split it into several functions so that each does one thing only. Ensure that
# - each function does its job well and is at a single level of abstraction,
# - all names are appropriate, and
# - the code is easy to understand.
#
# *Hint:* Start by renaming the variables according to the comments to simplify
# the rest of the work.

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Names of the weekdays
lst_dns = ["Mon", "Tue", "Wed", "Thu", "Fri"]


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The function `handle_money_stuff()` has the following parameters:
#
# - the day of the week (`i_dow`),
# - the salary per day (`f_spd`),
# - the name of the employee (`str_n`) and
# - a list of the salaries paid so far (`lst_slrs`).
#
# The new salary is appended to the list `lst_slrs`.
#
# The function returns the tax to be paid.

# %% tags=["keep"]
def handle_money_stuff(i_dow: int, f_spd: float, str_n: str, lst_slrs: list):
    # Get the day of week from the list of days.
    # We count Sunday as 1, Monday as 2, etc. but the work week starts on Monday.
    str_dow = lst_dns[i_dow - 1]
    # Compute the salary so far based on the day
    f_ssf = (i_dow - 1) * f_spd
    # The tax
    f_t = 0.0
    if f_ssf > 500.0 and f_ssf <= 1000.0:
        f_t = f_ssf * 0.05
    elif f_ssf > 1000.0 and f_ssf <= 2000.0:
        f_t = f_ssf * 0.1
    else:
        f_t = f_ssf * 0.15
    # Update salary based on the tax to pay
    f_ssf = f_ssf - f_t
    # Add the salary to the list of all salaries paid
    lst_slrs.append(f_ssf)
    print(f"{str_n} worked till {str_dow} and earned ${f_ssf} this week.")
    print(f"Their taxes were ${f_t}.")
    return f_t


# %% tags=["keep"]
_salaries = [2345, 1234]
_result = handle_money_stuff(4, 200, "Joe", _salaries)
print(_result)

# %% tags=["keep"]
assert _salaries == [2345, 1234, 570]
assert _result == 30


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
day_of_week_names = ["Mon", "Tue", "Wed", "Thu", "Fri"]


# %%
def compute_salary_and_taxes_v1(
    day_of_week_index: int, salary_per_day: float, employee_name: str, salaries: list
):
    day_of_week = day_of_week_names[day_of_week_index - 1]
    days_worked_this_week = day_of_week_index - 1
    salary_so_far = days_worked_this_week * salary_per_day
    tax = 0.0
    if salary_so_far > 500.0 and salary_so_far <= 1000.0:
        tax = salary_so_far * 0.05
    elif salary_so_far > 1000.0 and salary_so_far <= 2000.0:
        tax = salary_so_far * 0.1
    else:
        tax = salary_so_far * 0.15
    salary_so_far = salary_so_far - tax
    salaries.append(salary_so_far)
    print(
        f"{employee_name} worked till {day_of_week} and earned "
        f"${salary_so_far} this week."
    )
    print(f"Their taxes were ${tax}.")
    return tax


# %% tags=["keep"]
_salaries = [2345, 1234]
_result = compute_salary_and_taxes_v1(4, 200, "Joe", _salaries)
print(_result)

# %% tags=["keep"]
assert _salaries == [2345, 1234, 570]
assert _result == 30


# %%
def compute_salary_and_taxes_v2(
    day_of_week_index: int, salary_per_day: float, employee_name: str, salaries: list
):
    base_salary = compute_base_salary(day_of_week_index, salary_per_day)
    net_salary, tax = compute_net_salary_and_tax(base_salary)
    store_net_salary(net_salary, salaries)
    print_employee_info(day_of_week_index, employee_name, net_salary, tax)
    return tax


# %%
def compute_base_salary(day_of_week_index: int, salary_per_day: float):
    days_worked_this_week = day_of_week_index - 1
    return days_worked_this_week * salary_per_day


# %%
def compute_net_salary_and_tax(base_salary: float):
    tax = compute_tax(base_salary)
    net_salary = base_salary - tax
    return net_salary, tax


# %%
def compute_tax(base_salary: float):
    if base_salary > 500.0 and base_salary <= 1000.0:
        return base_salary * 0.05
    elif base_salary > 1000.0 and base_salary <= 2000.0:
        return base_salary * 0.1
    else:
        return base_salary * 0.15


# %%
def store_net_salary(net_salary, salaries):
    salaries.append(net_salary)


# %%
def print_employee_info(day_of_week_index: int, name: str, salary: float, tax: float):
    day_of_week = get_day_of_week_from_index(day_of_week_index)
    print(f"{name} worked till {day_of_week} and earned ${salary} this week.")
    print(f"Their taxes were ${tax}.")


# %%
def get_day_of_week_from_index(index: int) -> str:
    return day_of_week_names[index - 1]


# %% tags=["keep"]
_salaries = [2345, 1234]
_result = compute_salary_and_taxes_v2(4, 200, "Joe", _salaries)
print(_result)

# %% tags=["keep"]
assert _salaries == [2345, 1234, 570]
assert _result == 30


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Switches and abstraction
#
# Switch statements often perform operations on the same level of abstraction
# (for “subtypes” instead of the original type).
#
# “Subtypes” are often distinguished by type tags

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
from enum import IntEnum
from dataclasses import dataclass


# %% tags=["keep"]
class EmployeeType(IntEnum):
    COMMISSIONED = 0
    HOURLY = 1
    SALARIED = 2


# %% tags=["keep"]
@dataclass
class Money:
    amount_in_euros: float

    def __add__(self, rhs):
        return Money(self.amount_in_euros + rhs.amount_in_euros)


# %% tags=["keep"]
print(Money(100.0) + Money(50.0))


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
@dataclass
class EmployeeV1:
    type: EmployeeType


# %% tags=["keep"]
def calculate_commissioned_pay(e: EmployeeV1):
    return Money(100.0)


# %% tags=["keep"]
def calculate_hourly_pay(e: EmployeeV1):
    return Money(120.0)


# %% tags=["keep"]
def calculate_salaried_pay(e: EmployeeV1):
    return Money(80.0)


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def calculate_pay(e: EmployeeV1):
    if e.type == EmployeeType.COMMISSIONED:
        return calculate_commissioned_pay(e)
    elif e.type == EmployeeType.HOURLY:
        return calculate_hourly_pay(e)
    elif e.type == EmployeeType.SALARIED:
        return calculate_salaried_pay(e)
    else:
        raise ValueError("No valid employee type.")


# %% tags=["keep"]
e1 = EmployeeV1(type=EmployeeType.HOURLY)
e2 = EmployeeV1(EmployeeType.SALARIED)

# %% tags=["keep"]
print(calculate_pay(e1))
print(calculate_pay(e2))


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Replace switch with polymorphism
#
# It is often better to replace switches with “real” subtyping and polymorphism:


# %% tags=["keep"]
from abc import ABC, abstractmethod


# %% tags=["keep"]
class Employee(ABC):
    @abstractmethod
    def calculate_pay(self):
        ...


# %% tags=["keep"]
@dataclass
class CommissionedEmployee(Employee):
    def calculate_pay(self):
        return Money(100.0)


# %% tags=["keep"]
@dataclass
class HourlyEmployee(Employee):
    def calculate_pay(self):
        return Money(120.0)


# %% tags=["keep"]
@dataclass
class SalariedEmployee(Employee):
    def calculate_pay(self):
        return Money(80.0)


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def create_employee(employee_type: EmployeeType):
    if employee_type == EmployeeType.COMMISSIONED:
        return CommissionedEmployee()
    elif employee_type == EmployeeType.HOURLY:
        return HourlyEmployee()
    elif employee_type == EmployeeType.SALARIED:
        return SalariedEmployee()
    else:
        raise ValueError("Not a valid employee type.")


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
e1 = create_employee(EmployeeType.HOURLY)
e2 = create_employee(EmployeeType.SALARIED)


# %% tags=["keep"]
print(e1.calculate_pay())
print(e2.calculate_pay())


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
class EmployeeFactory:
    def create_employee(self, employee_type: EmployeeType):
        if employee_type == EmployeeType.COMMISSIONED:
            return CommissionedEmployee()
        elif employee_type == EmployeeType.HOURLY:
            return HourlyEmployee()
        elif employee_type == EmployeeType.SALARIED:
            return SalariedEmployee()
        else:
            raise ValueError("Not a valid employee type.")


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
factory = EmployeeFactory()
e1 = factory.create_employee(EmployeeType.HOURLY)
e2 = factory.create_employee(EmployeeType.SALARIED)


# %% tags=["keep"]
print(e1.calculate_pay())
print(e2.calculate_pay())

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini workshop: Replacing switch statements
#
# Restructure the following code so that a "switch statement" is used only when
# creating of the objects:

# %% tags=["keep"]
from dataclasses import dataclass
from abc import ABC


# %% tags=["keep"]
COMPUTER_TYPE_PC = 0
COMPUTER_TYPE_MAC = 1
COMPUTER_TYPE_CHROMEBOOK = 2


# %% tags=["keep"]
@dataclass
class ComputerV1:
    computer_type: int


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
def compile_code(computer: ComputerV1):
    if computer.computer_type == COMPUTER_TYPE_PC:
        print("Compiling code for PC.")
    elif computer.computer_type == COMPUTER_TYPE_MAC:
        print("Compiling code for Mac.")
    elif computer.computer_type == COMPUTER_TYPE_CHROMEBOOK:
        print("Compiling code for Chromebook.")
    else:
        raise ValueError(f"Don't know how to compile code for {computer}.")


# %% tags=["keep"]
my_pc = ComputerV1(COMPUTER_TYPE_PC)
my_mac = ComputerV1(COMPUTER_TYPE_MAC)
my_chromebook = ComputerV1(COMPUTER_TYPE_CHROMEBOOK)

# %% tags=["keep"]
compile_code(my_pc)
compile_code(my_mac)
compile_code(my_chromebook)


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
@dataclass
class Computer:
    @abstractmethod
    def compile_code(self):
        ...


# %%
@dataclass
class PC(Computer):
    def compile_code(self):
        print("Compiling code for PC.")


# %%
@dataclass
class Mac(Computer):
    def compile_code(self):
        print("Compiling code for Mac.")


# %%
@dataclass
class Chromebook(Computer):
    def compile_code(self):
        print("Compiling code for Chromebook.")


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def create_computer(type_: int):
    if type_ == COMPUTER_TYPE_PC:
        return PC()
    elif type_ == COMPUTER_TYPE_MAC:
        return Mac()
    elif type_ == COMPUTER_TYPE_CHROMEBOOK:
        return Chromebook()
    else:
        raise ValueError(f"Don't know how to create computer of type {type_}.")


# %%
my_pc = create_computer(COMPUTER_TYPE_PC)
my_mac = create_computer(COMPUTER_TYPE_MAC)
my_chromebook = create_computer(COMPUTER_TYPE_CHROMEBOOK)
print([my_pc, my_mac, my_chromebook])

# %%
my_pc.compile_code()
my_mac.compile_code()
my_chromebook.compile_code()


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## More rules for functions
#
# - Use descriptive names
# - Use few (or no) arguments
# - Don’t use Boolean arguments (flag arguments)
# - Avoid hidden side effects


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Hidden Side-Effects

# %% [markdown]
#
# ```java
# bool checkPassword(std::string userName, std::string password) {
#     User& user = UserGateway.findByName(userName);
#     if (user != User.NULL) {
#         std::string codedPhrase = user.getPhraseEncodedByPassword();
#         std::string phrase = cryptographer.decrypt(codedPhrase, password);
#         if (phrase == "Valid Password") {
#             session.initialize();
#             return true;
#         }
#     }
#     return false;
# }
# ```

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Avoid output arguments
#
# Python has no "real" output arguments. But modification of objects often has
# similar consequences:


# %% tags=["keep"]
class HitResultV1:
    pass


# %% tags=["keep"]
class PlayerV1:
    def check_collision(self, obstacles, hit_result):
        # Complicated computation...
        hit_result.collision_occurred = True


# %% tags=["keep"]
player = PlayerV1()
hit_result = HitResultV1()
player.check_collision([], hit_result)
if hit_result.collision_occurred:
    print("Detected collision!")


# %%
from dataclasses import dataclass


# %%
@dataclass
class HitResult:
    collision_occurred: bool = False


# %%
class Player:
    def check_collision(self, obstacles):
        # Complicated computation...
        return HitResult(True)


# %% tags=["keep"]
player = Player()
hit_result = player.check_collision([])
if hit_result.collision_occurred:
    print("Detected collision!")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Command-Query Separation

# %% tags=["keep"]
default_value = -1


# %% tags=["keep"]
def bad_has_default_value() -> bool:
    global default_value
    if default_value >= 0:
        return True
    else:
        default_value = 123
        return False


# %%
print(default_value)
print(bad_has_default_value())
print(default_value)


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def has_default_value() -> bool:
    return default_value >= 0


# %%
def set_default_value() -> None:
    global default_value
    default_value = 123


# %%
default_value = -1
print(default_value)
print(has_default_value())
print(default_value)
set_default_value()
print(default_value)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Error Reporting
#
# Use exceptions for error reporting.
#
# (See `module_170_exceptions`.)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## DRY: Don't Repeat Yourself
#
# - Try to eliminate duplicated code
#   - It bloats the code
#   - It requires multiple modifications for every change
# - But: often duplicated code is interspersed with other code
# - Take into account the scope in which you keep code DRY!
