# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>What is Clean Code?</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 What is Clean Code.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_230_clean_code/topic_110_a3_intro.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # What is Clean Code?
#
# Opinions of experts:

# %% [markdown] tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Grady Booch (OODA)
#
# - Clean code is simple and direct.
# - Clean code reads like well-written prose.
# - Clean code never obscures the designer’s intent but rather is full of crisp
#   abstractions and straightforward lines of control.

# %% [markdown] tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Bjarne Stroustrup (C++)
#
# - I like my code to be elegant and efficient.
# - The logic should be straightforward to make it hard for bugs to hide, the
#   dependencies minimal to ease maintenance, error handling complete according
#   to an articulated strategy, and performance close to optimal so as not to
#   tempt people to make the code messy with unprincipled optimizations.
# - Clean code does one thing well.

# %% [markdown] tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Ward Cunningham (Wiki)
#
# - You know you are reading clean code, when every routine that you read is
#   pretty much what you expected.
# - You can call it beautiful code when the code also makes it look like the
#   language was made for the problem.

# %% [markdown] tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Michael Feathers (Legacy Code Book)
#
# - Clean code always looks like it was written by someone who cares.

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Goal
#
# A code base that is fun to work with.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## How do we get there?
#
# In many small steps!

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## The ## Boy Scout Rule (for Code)
#
# Always leave your code better than you found it.
#
# (Robert C. Martin)
