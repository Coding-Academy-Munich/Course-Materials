# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>SOLID: Dependency Inversion Principle</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 SOLID_ Dependency Inversion Principle.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_280_solid/topic_160_a3_solid_dip.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # SOLID: Dependency Inversion Principle
# - The core functionality of a system does not depend on its environment
#   - **Concrete artifacts depend on abstractions** (not vice versa)
#   - **Unstable artifacts depend on stable artifacts** (not vice versa)
#   - **Outer layers** of the architecture **depend on inner layers** (not vice
#     versa)
#   - Classes/Modules depend on abstractions (e.g., interfaces) not on other
#     classes/modules
# - Dependency inversion achieves this by introducing interfaces that “reverse
#   the dependencies”

# %% [markdown] tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# <img src="img/dip-01.png"
#      style="display:block;margin:auto;width:95%"/>

# %% [markdown] tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# <img src="img/dip-02.png"
#      style="display:block;margin:auto;width:95%"/>

# %% [markdown] tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# <img src="img/dip-03.png"
#      style="display:block;margin:auto;width:95%"/>

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Example

# %% tags=["keep"]
from dataclasses import dataclass
from augurdb import AugurDatabase

# %% tags=["keep"]
@dataclass
class BadEmployee:
    id: int
    name: str
    database: AugurDatabase

    def save(self):
        self.database.start_transaction()
        self.database.store_field(id, "name", self.name)
        self.database.commit_transaction()


# %% tags=["keep"]
db = AugurDatabase()
be = BadEmployee(123, "Joe", db)

# %% tags=["keep"]
be.save()

# %%
from abc import ABC, abstractmethod

# %%
# module employee
class DatabaseInterface(ABC):
    @abstractmethod
    def save(self, e: "BetterEmployee"):
        ...


# %%
# module employee
@dataclass
class BetterEmployee:
    id: int
    name: str
    database: DatabaseInterface

    def save(self):
        self.database.save(self)


# %%
# module db
@dataclass
class AugurDatabaseInterface(DatabaseInterface):
    database: AugurDatabase = AugurDatabase()

    def save(self, e: "BetterEmployee"):
        self.database.start_transaction()
        self.database.store_field(id, "name", e.name)
        self.database.commit_transaction()
