# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>SOLID: Introduction</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 SOLID_ Introduction.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_280_solid/topic_110_a3_solid_intro.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # SOLID: Introduction
#
# A collection of five guidelines collected by Robert C. Martin (Uncle Bob)
# - Single Responsibility Principle (SRP)
# - Open/Closed Principle (OCP)
# - Liskov Substitution Principle (LSP)
# - Interface Segregation Principle (ISP)
# - Dependency Inversion Principle (DIP)
