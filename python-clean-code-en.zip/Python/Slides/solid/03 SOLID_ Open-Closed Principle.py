# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>SOLID: Open-Closed Principle</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 SOLID_ Open-Closed Principle.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_280_solid/topic_130_a3_solid_ocp.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # SOLID: Open-Closed Principle
#
# Classes should be
#
# - Open for extension
# - Closed for Modification


# %% tags=["keep"]
from enum import IntEnum
from dataclasses import dataclass

# %% tags=["keep"]
class MovieKindV0(IntEnum):
    REGULAR = 1
    CHILDREN = 2


# %% tags=["keep"]
@dataclass
class MovieV0:
    title: str
    kind: MovieKindV0 = MovieKindV0.REGULAR

    def compute_price(self):
        if self.kind == MovieKindV0.REGULAR:
            return 4.99
        elif self.kind == MovieKindV0.CHILDREN:
            return 5.99

    def print_info(self):
        print(f"{self.title} costs {self.compute_price()}")


# %% tags=["keep"]
m1 = MovieV0("Casablanca")
m2 = MovieV0("Shrek", MovieKindV0.CHILDREN)

# %% tags=["keep"]
m1.print_info()
m2.print_info()

# %% tags=["keep"]
class MovieKindV1(IntEnum):
    REGULAR = 1
    CHILDREN = 2
    NEW_RELEASE = 3


# %% tags=["keep"]
@dataclass
class MovieV1:
    title: str
    kind: MovieKindV1 = MovieKindV1.REGULAR

    def compute_price(self):
        if self.kind == MovieKindV1.REGULAR:
            return 4.99
        elif self.kind == MovieKindV1.CHILDREN:
            return 5.99
        elif self.kind == MovieKindV1.NEW_RELEASE:
            return 6.99

    def print_info(self):
        print(f"{self.title} costs {self.compute_price()}")


# %% tags=["keep"]
m1 = MovieV1("Casablanca")
m2 = MovieV1("Shrek", MovieKindV1.CHILDREN)
m3 = MovieV1("Brand New", MovieKindV1.NEW_RELEASE)

# %% tags=["keep"]
m1.print_info()
m2.print_info()
m3.print_info()

# %%
from abc import ABC, abstractmethod

# %%
@dataclass
class Movie(ABC):
    title: str
    kind: MovieKindV1 = MovieKindV1.REGULAR

    @abstractmethod
    def compute_price(self):
        ...

    def print_info(self):
        print(f"{self.title} costs {self.compute_price()}")


# %%
class RegularMovie(Movie):
    def compute_price(self):
        return 4.99


# %%
class ChildrenMovie(Movie):
    def compute_price(self):
        return 5.99


# %%
class NewReleaseMovie(Movie):
    def compute_price(self):
        return 6.99


# %%
m1 = RegularMovie("Casablanca")
m2 = ChildrenMovie("Shrek")
m3 = NewReleaseMovie("Brand New")

# %%
m1.print_info()
m2.print_info()
m3.print_info()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Workshop: Employee OCP
#
# When discussing the  SRP, we refactored the `Employee` class to remove the SRP
# violations. Improve the example further by also removing the OCP violations as
# well. Start with the class `EmployeeV1`:

# %%
from dataclasses import dataclass
from augurdb import AugurDatabase
from project import Project
from abc import ABC, abstractmethod

# %%
@dataclass
class Employment(ABC):
    @abstractmethod
    def calculate_pay(self) -> float:
        ...

    @abstractmethod
    def report_hours(self) -> int:
        ...


# %%
@dataclass
class RegularEmployment(Employment):
    salary: float
    overtime: int

    def calculate_pay(self) -> float:
        return self.salary + 60.0 * self.overtime

    def report_hours(self) -> int:
        return 40 + self.overtime


# %%
@dataclass
class CommissionedEmployment(Employment):
    project: "Project"

    def calculate_pay(self) -> float:
        return self.project.assets * 0.1

    def report_hours(self) -> int:
        return 40


# %%
@dataclass()
class HouredEmployment(Employment):
    billable_hours: int

    def calculate_pay(self) -> float:
        return 50.0 * self.billable_hours

    def report_hours(self) -> int:
        return self.billable_hours


# %%
class ReportPrinter:
    def print_report(self, employee: "EmployeeSrp") -> None:
        print(f"{employee.name} worked {employee.report_hours()} hours.")


# %%
@dataclass
class EmployeeDao:
    database: AugurDatabase

    def save_employee(self, employee: "EmployeeSrp") -> None:
        self.database.start_transaction()
        self.database.store_field(employee.id, "name", employee.name)
        self.database.store_field(employee.id, "employment", employee.employment)
        self.database.commit_transaction()


# %%
@dataclass
class EmployeeSrp:
    id: int
    name: str
    employment: Employment
    report_printer: ReportPrinter
    dao: EmployeeDao

    def calculate_pay(self):
        return self.employment.calculate_pay()

    def report_hours(self):
        return self.employment.report_hours()

    def print_report(self):
        return self.report_printer.print_report(self)

    def save_employee(self):
        return self.dao.save_employee(self)


# %%
# %%
from project import Project
from employee_srp import (
    CommissionedEmployment,
    EmployeeDao,
    EmployeeSrp,
    HouredEmployment,
    RegularEmployment,
    ReportPrinter,
)
from augurdb import AugurDatabase
from pprint import pprint


# %%
p1 = Project(name="Project 1", assets=10_000.0)
p2: Project = Project(name="Project 2", assets=12_000.0)

# %%
db = AugurDatabase()

# %%
default_report_printer = ReportPrinter()
default_employee_dao = EmployeeDao(db)

# %%
e1 = EmployeeSrp(
    id=123,
    name="Joe Random",
    employment=RegularEmployment(
        salary=1000.0,
        overtime=5,
    ),
    report_printer=default_report_printer,
    dao=default_employee_dao,
)

# %%
e2 = EmployeeSrp(
    id=124,
    name="Jane Ransom",
    employment=HouredEmployment(billable_hours=43),
    report_printer=default_report_printer,
    dao=default_employee_dao,
)

# %%
e3 = EmployeeSrp(
    id=125,
    name="Jill Chance",
    employment=CommissionedEmployment(project=p2),
    report_printer=default_report_printer,
    dao=default_employee_dao,
)

# %%
employees = [e1, e2, e3]

# %%
for e in employees:
    print("=" * 35)
    print(f"{e.name} has a salary of {e.calculate_pay():.2f}")
    e.print_report()
    e.save_employee()
print("=" * 35)

# %%
pprint(db.records)

# %%
