# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>SOLID: Instance Segregation Principle</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 SOLID_ Instance Segregation Principle.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_280_solid/topic_150_a3_solid_isp.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # SOLID: Instance Segregation Principle
#
# - No client of a class C should depend on methods it doesn’t use
# - If that is not the case
#   - Divide the interface of C into multiple independent interfaces
#   - Replace C in each client with the interfaces actually used by the client
