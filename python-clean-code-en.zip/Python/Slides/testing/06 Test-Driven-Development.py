# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Test-Driven-Development</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Test-Driven-Development.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_240_unit_testing/topic_170_test_driven_development.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Idea
#
# - Use tests to drive the design and feature development of the program
# - Each new test describes a feature increment of the program
# - (Good testable code is created as a by-product)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Problem
#
# How can tests drive the design of the program?

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Possible answers?
#
# - Tests use the functionality and therefore highlight clumsy interfaces
# - Tests enable refactoring


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Refactoring
#
# - Refactoring improves the design of the program in small steps
# - The correctness of these steps is verified by tests

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## So what???
#
# - Refactoring allows you to work with (nearly) constant velocity.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Test-Driven Development
#
# - The goal of TDD is not primarily to achieve high test coverage
#   - Typically, one does not write tests for methods that one is convinced cannot fail
# - The goal of TDD is to discover a good design through testing
#   - When writing the tests, one tries to design the interfaces of classes and
#     functions in such a way that it is easy to use
#   - Because all essential parts of the program are protected by tests,
#     one can permanently adapt the design to the current feature set through
#     refactoring

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## The TDD Cycle
# - Write a (minimal) test
#   - The test only tests one new (partial) feature: **Baby Steps**
#   - This test fails
# - Implement the minimal functionality to get the test to work
#   - You don't have to pay attention to clean code or good design
#   - But: **Solve Simply**
# - Improve the code
#   - Remove the dirty constructs introduced in the previous step
#   - Generalize the implementation if there is too much repetition
#   - **This step is not optional!!!**

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## The TDD cycle
#
# - <span style="color: red"><b>Red (failing test)</b></span>
# - <span style="color: green"><b>Green (all tests are green again)</b></span>
# - <span style="color: blue"><b>Clean/Refactor (the code is clean again)</b></span>

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Even better: TDD + preparation step
#
# - Refactor the code so that the change becomes easy
#   - This is often not that easy...
#   - If during the refactoring it becomes clear that tests are missing, they are added
# - Do the easy change with the TDD cycle
# - Repeat these steps over and over again

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Why Solve Simply?
# - A flexible, generic solution often increases the complexity of the system
# - It is only worthwhile if the flexibility is actually needed
# - Developers usually have a hard time predicting where flexibility/extensibility is
#   needed
# - A flexible, generic solution is often much more difficult to implement than
#   a simple solution for a more specific use case
# - The most obvious flexible, generic solution is often not the cleanest and
#   most maintainable code

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Assumptions of Solve Simply
# - It is possible to refactor code into a clean, maintainable state without changing
#   functionality
# - It is possible to extend code iteratively and make it more flexible when needed
# - It is easier to carry out the refactoring and iteration steps than to develop
#   the final solution right away
# - These assumptions are only fulfilled if a sufficient number of good unit tests
#   are available

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Baby steps
#
# - The system does not spend hours or days in a state in which it is not buildable,
#   testable or executable
# - This allows you to quickly get feedback from the code with every change
# - Frequent merging and CI becomes possible

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Guided Kata: Prime Factor Decomposition
#
# - An exercise in TDD that shows how tests can be used to lead to a simple
#   implementation of an algorithm
# - The important thing is the procedure: Tests should drive the design
# - Goal: Learn to work incrementally and iteratively!


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Guided Kata: Prime factorization
#
# Write a function
#
# ```python
# compute_prime_factors(n: int) -> list[int]
# ```
#
# that returns the prime factors of n in ascending order.
#
# Prime factors that occur more than once appear in the list more than once.
#
# You can use the program framework `examplesPrimesStarterKit`.

# %% [markdown] lang="en"
# ## Kata: FizzBuzz
#
# Write a function `fizz_buzz(n)` that prints the numbers from 1 to `n` but
#
# - replaces any number divisible by 3 with `fizz`
# - replaces every number divisible by 5 with `buzz`
# - replaces every number divisible by 3 and 5 with `FizzBuzz`
#
# For example, `fizz_buzz(31)` should produce the following output:
#
# ```
# 1
# 2
# Fizz
# 4
# Buzz
# Fizz
# 7
# 8
# Fizz
# Buzz
# 11
# Fizz
# 13
# 14
# FizzBuzz
# 16
# 17
# Fizz
# 19
# Buzz
# Fizz
# 22
# 23
# Fizz
# Buzz
# 26
# Fizz
# 28
# 29
# FizzBuzz
# 31
# ```

# %%
def fizz_buzz(n):
    for n in range(1, n + 1):
        if n % 15 == 0:
            print("FizzBuzz")
        elif n % 3 == 0:
            print("Fizz")
        elif n % 5 == 0:
            print("Buzz")
        else:
            print(n)


# %%
fizz_buzz(31)
