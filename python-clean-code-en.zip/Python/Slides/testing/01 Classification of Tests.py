# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Classification of Tests</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Classification of Tests.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_240_unit_testing/topic_130_a3_test_classification.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### By size of the system under test (SuT)
#
# - Unit tests:
#   - Test individual methods or classes,
#   - Typically isolated from the rest of the system
# - Component tests:
#   - Test individual components in isolation
# - Integration/system tests:
#   - Test the complete system.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### By objectives
# - Validation testing:
#   tries to ensure that the system fulfills its intended function correctly
# - Defect testing: tries to find errors (actually error states)
#   - rarely considered execution paths or use cases
#   - boundary conditions
# - The transitions between the two classes are fluid

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### By time
#
# - Development tests:
#   - The system is tested during the development phase
#   - Are generally carried out by the developers themselves
# - Release tests:
#   - A complete version of the system is tested before it is handed over to customers
#   - Often performed by a dedicated testing team
# - End-user testing:
#   - Users or potential users test the system, often in their own system environment.
#   - Acceptance testing is a form of end-user testing


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Related topics
#
# - Regression tests:
#   - Tests for bugs that have already been fixed.
#   - Should ensure that these errors cannot re-enter the system.
#   - Regression tests can be unit, component or integration system tests
# - Performance tests:
#   - Tests that check the behavior of the system under load
#     (load tests, stress tests, spike tests, ...)
# - Usability tests (usability tests):
#   - Tests that check , how well users get along with the system

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Test strategies
# - White Box vs. Black Box
# - Top Down vs. Bottom Up

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## White-Box Tests
#
# - Also called glass box or structural testing
# - Testers have access to the design and implementation of the system and can
#   - Read the design docs
#   - Inspect the code
#   to find potential bugs
# - When programmers write tests for their own code, they are always White -Box tests

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Black-Box Tests
# - Testers can check the system behavior (e.g. outputs) for inputs they choose
# - Testers have no access to system internals
# - (Classic) fuzzing is an automated form of black-box testing
# - Testers have access to the design documents but not the program code is sometimes
#   called gray box testing
