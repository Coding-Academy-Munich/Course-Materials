# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Strategies for Finding Tests</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Strategies for Finding Tests.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_240_unit_testing/topic_180_strategies_for_finding_tests.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Strategies for Finding Tests
#
# - Boundary value analysis (BVA)
# - Partitioning
# - State-based testing
# - Control flow-based testing
# - Guidelines
# - Knowledge of common errors
# - (Knowledge of common problems in tests (test smells))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Boundary Value Analysis
#
# - Many errors occur at the "edge" of the definition range of functions
#   or procedures
# - A good strategy for efficient testing is therefore to consider such edge values
#   - The last valid value(s)
#   - Values that are just outside the definition range
# - For example, if a function is defined for integer values between
#   0 and 5, it can be tested with inputs -1, 0, 5, 6

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Boundary Value Analysis
#
# ### Advantage:
# - One concentrates on empirically frequent sources of error
#
# ### Difficulties:
#
# - For many domains, it is not clear what "boundary values" are
#   - (However, alternative criteria can often be found, e.g., length of collection
#     arguments)
# - Values outside the definition domain can sometimes lead to undefined behavior
# - For functions with many parameters, there is a combinatorial explosion of boundary
#   values.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Rule for (extended) BVA: CORRECT
#
# - **Conformance:** Does the value correspond to an expected format?
# - **Ordering:** Are the possible values ordered or unordered?
# - **Range:** Does the value have a minimum and/or maximum value?
# - **Reference:** Does the code have external references that are not under its
#   control?
# - **Exist:** Does the value exist (is it non-null, contained in a given set, ...)
# - **Cardinality:** Are there enough values? Are there too many values?
# - **Time:** Are the values available at the required time? In the expected order?

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Partitioning
# - Arguments of functions, input/output of the program and states of classes
#   can often be partitioned into equivalence classes so that...
#   - The behavior for elements from the same equivalence class is similar
#     (e.g. takes the same control flow path)
#   - Elements from different classes show different behavior
#   - Example: The arguments of the sqrt function can be subdivided into
#       - Positive numbers and 0
#       - Negative numbers
#   - A finer subdivision would be additionally into square numbers and
#     non-quadrat numbers
# - Such an equivalence class is called partition (or domain)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Partitioning
#
# Find partitions for the tested element and test the following elements:
#
# - A value from the "center" of the partition
# - A value on or near each partition boundary
#
# Often partitions are found by BVA.
#
# Example: To test the square root function, write tests for:
#
# - `sqrt(0.0)`
# - `sqrt(2.0)`
# - `sqrt(-2.0)`

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## State-based testing
#
# If the behavior of an object can be described by a state diagram, testing can be
# guided by the states and transitions
# - A state-based test is described by a sequence of events that control
#   the state machine
# - The expected results are
#   - the states (if observable) and
#   - the activities or outputs caused by the input events
# - There are different methods to find faulty activities or outputs
#   and incorrect state transitions
#   (e.g. Transition Tour, Distinguishing Sequence).

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Control Flow Based Testing
# - The Control Flow Graph (CFG) of a program is a directed graph representing the
#   control structure of a program
#   - Nodes are Basic Blocks (linear sequences of statements)
#   - Edges represent possible program sequences
# - Case distinctions: Nodes with multiple successors
# - Loops in the program lead to loops in the CFG.


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def control_flow(x):
    if x == 0:
        print("x == 0")
        print("This is interesting.")
    else:
        print("x !== 0")
        print("The boring case.")
    print("Done.")


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The CFG allows you to define various measures of program "test coverage":
# - Statement Coverage: The percentage of program statements (nodes in the
#   CFG) that are covered by tests. A test suite has 100% statement
#   coverage if every program statement is covered by at least one test
# - Branch Coverage, Decision Coverage: The percentage of edges in the CFG
#   that are covered by tests. A test suite has 100% decision coverage if
#   every possible branch in the program is covered by a test, i.e., if every
#   edge in the CFG is traversed by a test
# - 100% decision coverage implies 100% instruction coverage, but not vice versa


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def control_flow_2(x):
    if x == 0:
        print("x == 0")
        print("This is interesting.")
    print("Done.")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Guidelines
# - Represent project or domain specific knowledge
# - Can be expanded if defects are found that were not captured by
#   previous testing

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Examples of guidelines
# - Write unit tests that trigger every possible error message
# - Test every function that uses a buffer with an input that
#   is larger than the maximum buffer size
# - Test cached functions multiple times with the same input and
#   make sure that the output does not change
# - Test every function with inputs, test any function that has a
#   collection as input parameter with the empty collection and with
#   one-element collections
# - Use collections of different sizes in tests
# - Make sure that elements from the beginning, middle and end of a
#   collection are accessed (if possible)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Some "Common Errors"
# - Incorrect Boolean conditions
#   - Consider partitions generated by conditions
#   - Consider boundary values of conditions
# - Non-terminating computations
#   - Forgotten/incomplete base cases in recursive functions (ex. Test for = 0 instead
#     of <= 0)
#   - Unforeseen increment/decrement of counter in for or while loops
# - Incorrect preconditions for code
#   - Write assertions in code that check preconditions
#   - Write tests that trigger these assertions
# - Incorrect invariants
#   - Write functions that test invariants if they rely on non-accessible state
#   - Write tests that use these functions.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Some "Common Errors"
# - Null pointers, uninitialized memory
#   - Generally hard to find by testing; use tools like Valgrind and
#     turn on compiler warnings if available
#   - Try to find partitions that leave values uninitialized
# - Unusual ranges
#   - Empty or one-element collections
#   - Very small values (e.g. 1.0e-300)
#   - Very large values or collections.e.g. 1.0e-300)
# - Off-by-one, fencepost errors
#   - Test that loops are not traversed too often or too rarely
#   - Use for-in (if possible)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Some "Common Errors"
# - Wrong operator precedence
#   - Check that formulas have the expected meaning
#   - Try to find partitions that ensure this
# - Unsuitable algorithms
#   - Bad runtime properties
#   - Over/underflow for certain inputs
# - Unsuitable representation of data
#   - Floating point numbers for monetary amounts
#   - Representation of values that can only consist of digits (e.g. bank codes,
#     account numbers, ISBN-numbers) by int values (leading zeros,
#     length of representation)
# - Too few values for productive use, e.g. 8-bit User-ID

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Some "Common Errors" in Numerical Calculations
# - Using inexact representations where an exact representation would be necessary
#   - e.g., floating point numbers for fractions
# - Using floating point numbers with too little precision
# - Using numerically unstable algorithms
# - Performing numerical calculations without regard to order of operations
#   - Can drastically increase numerical error.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Scope of unit tests
#
# Unit tests should cover the tested unit as completely as possible
# - Functions/methods
#   - Call with parameters from each (white-box) input partition
# - Classes/objects
#   - Test of all relevant operations
#   - At least one test for each state partition
#   - Tests for all possible state transitions
#   - Tests to ensure that inherited attributes and operations work as desired

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Example: Guard in a game
# - States:
#   - Patrolling
#   - Searching
#   - Fighting
#   - Dead
# - State transitions
#   - Patrolling ↔ Searching
#   - Patrolling ↔ Fighting ("→" only when attacked)
#   - Searching → Fighting
#   - (Any) → Dead

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Quality criteria for unit tests: FIRST
# - **Fast:**
#   - Each test requires at most a few milliseconds of runtime
# - **Isolated:**
#   - Each test tests a small amount of code and is isolated from the rest of the system
#   - Tests are isolated from each other, order of execution does not matter
# - **Repeatable:**
# -  The result of a test should always be identical
# -  Common issues: Time, Date, Threads, Random
# - **Self-Validating:**
#   - No external verification should be required (e.g., manual inspection of test
#     output)
# - **Timely:**
#   - Unit tests should be created along with the code they test

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Right-BICEP: What or how should be tested?
# - **Right:** Are the results/outputs of the program correct?
#   - "Happy-Path Tests"
#   - Validation Testing
# - **Boundary Conditions:** Are boundary values handled correctly?
# - **Inverse Relationships:** Does it make sense to test the inverse relationship?
#   (Example: square root)
# - **Cross-checking:** Can results be verified by "cross-checking"? (Example: slow but
#   simple algorithm)
# - **Forcing Error Conditions:** Can error conditions be forced?
#   - Unhappy-Path Tests"
#   - Defect Testing
# - **Performance Characteristics:** Is the performance of the implementation
#   sufficient?  Does the implementation scale?
