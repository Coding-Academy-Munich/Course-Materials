# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Introduction to Unit Testing</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Introduction to Unit Testing.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_240_unit_testing/topic_140_a3_unit_testing_intro.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## What is a unit test?
#
# - Test of a (partial) functionality
# - More precisely: test of a scenario for the execution of a partial functionality

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Functions
# - Methods
# - (Classes)
# - (Simple Components)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Properties of unit tests (V1)
# - Fine-grained
#   - e.g. testing a method call with certain parameters
# - No interaction between tests
#   - Isolated test cases
# - No interaction between the tested unit and the rest of the system
#   - External subsystems are often replaced by simple simulations (mocks)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Reasons for unit testing
# - Finding bugs early
# - Easier to locate bugs
# - "Safety net" for programmers
#   - Also act as regression tests
#   - Bugs are (hopefully) found before they affect the overall system
# - Support maintainability and extensibility of code
# - Facilitate refactoring, since many errors are found by unit testing
# - Ensure that extensions do not affect existing functionality
# - Serve as additional documentation
# - Cannot replace architecture diagrams etc

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Eigenschaften von guten Unit-Tests (V2)
#
# Unit tests should
# - be automated
# - be self-testing
# - test individual program elements in isolation
# - be executable successfully at any time
# - not require much time to run
# - be written for all system components
# - cover all important states of each tested element
#
# Später: detailliertere Richtlinien - FIRST, Right-BICEP, CORRECT
