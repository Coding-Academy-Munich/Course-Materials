# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Writing good Unit Tests</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Writing good Unit Tests.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_240_unit_testing/topic_160_writing_unit_tests.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## What is the form of a unit test?
# - Arrange
# - Act
# - Assert


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def test_the_extend_method_of_the_built_in_list_type():
    x = [1, 2, 3]  # arrange
    y = [10, 20]

    x.extend(y)  # act

    assert x == [1, 2, 3, 10, 20]  # assert


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## How do we find good tests?


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Try: Exhaustive testing
#
# - We write exhaustive tests, i.e. tests that cover all possible inputs of a program


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Exhaustive testing is not possible
# - Example: password input:
#   - Suppose passwords with a maximum of 20 characters are allowed,
#     80 input characters are allowed (upper and lower case letters, special characters)
#   - This results in $80^{20}$ = 115,292,150,460,684,697,600,000,000,000,000,000,000
#     possible inputs
#   - At 10ns for a test, it would take about $10^{24}$ years to test all inputs
#   - The universe is about $1.4 \times 10^{10}$ years old

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Effectiveness and efficiency of tests
#
# - Unit tests should be effective and efficient
#   - Effective: The tests should find as many bugs as possible
#   - Efficient: We want to find the largest number of bugs with the fewest number of
#     tests that are as simple as possible
# - Efficiency is important because Tests themselves are code that requires
#   maintenance and may contain bugs

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Strategies for finding (effective and efficient) tests
#
# - Boundary value analysis (BVA)
# - Partitioning
# - State-based testing
# - Control flow-based testing
# - Guidelines
# - Knowledge of common errors
# - (Knowledge of common problems in tests (test smells))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Rules of thumb for unit testing
#
# - Test functionality, not implementation
# - Use test doubles if (but only if) a dependency "launches a missile"
# - Prefer tests of values to tests of states
# - Prefer tests of states to tests of behavior
# - Test small units
# - (These rules assume that the code allows such tests)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Test functionality, not implementation
#
# Abstract implementation details as much as possible
# - Also at unit test level
# - Often different methods test each other
#     - This sometimes requires the introduction of additional methods
#     - These methods are often not only useful for testing
#     - Often "abstract state" of objects
#     - **Do not** simply make the concrete state public.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Test functionality, not implementation
#
# **Why?**
# - Functionality is easier to understand
# - Functionality is more stable than implementation
# - Functionality is closer to customer benefit

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
class Stack:
    def __init__(self):
        self._items = []

    def push(self, new_item):
        self._items.append(new_item)

    def pop(self):
        return self._items.pop()


# %% tags=["keep"]
my_stack = Stack()
my_stack.push(1)

# %% tags=["keep"]
assert my_stack._items == [1]  # noqa <- This might tell you something :)


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
class Stack:
    def __init__(self):
        self._items = []

    def __len__(self):
        return len(self._items)

    def push(self, new_item):
        self._items.append(new_item)

    def pop(self):
        return self._items.pop()


# %% tags=["keep"]
my_stack = Stack()
my_stack.push(5)

# %% tags=["keep"]
assert len(my_stack) == 1
assert my_stack.pop() == 5


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Test Doubles
# - Test Doubles: Stubs, Fakes, Spies, Mocks
# - Replace a dependency in the system with a simplified version
#   - e.g. replace a database query with a fixed value
# - Test Doubles are important for simplifying tests
# - But: too many or complex test doubles make tests confusing
#   - What is actually being tested by a test?

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Typical use of test doubles:
#
# - database access, file system access
# - time, random values
# - non-determinism
# - hidden state (`AdderSpy`)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Values > State > Behavior
#
# - More understandable
# - Easier to test
# - Often more stable compared to refactorings
#
# Exception: testing protocols

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Value

# %%
def add(x, y):
    return x + y


# %%
assert add(2, 3) == 5


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### State

# %%
class Adder:
    def __init__(self, x, y):
        self.result = x + y


# %%
my_adder = Adder(2, 3)
assert my_adder.result == 5


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Behavior

# %%
def call_add(add):
    _hidden_result = add(2, 3)
    # Presumably do something with _hidden_result...
    return "How do you test that add was called?"


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
class AdderSpy:
    def __init__(self):
        self.was_called = False
        self.result = None

    def __call__(self, x, y):
        self.was_called = True
        self.result = x + y
        return self.result


# %%
spy = AdderSpy()
assert not spy.was_called

# %%
assert spy(2, 3) == 5

# %%
assert spy.was_called
assert spy.result == 5

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
adder_spy = AdderSpy()
call_add(adder_spy)
assert adder_spy.was_called
assert adder_spy.result == 5

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Test small units (in unit tests)
# - Tests of small units
#   - better specify the behavior of the tested unit
#   - make it easier to locate errors
#   - are easier to maintain
# - Tests of larger units or the whole system are important:
#   - Integration tests
#   - System tests
#   - Acceptance tests

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## How do you write testable code?
# - No global or static data
# - Techniques from functional programming (iterables, higher-order functions, etc.)
# - Functional data structures (immutability)
# - Good object-oriented design
#   - High coherence
#   - Low coupling, management of dependencies
# - Etc.
#
# Tool: Test-Driven Development


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mini-workshop:
#
# Add appropriate unit tests to the shopping-list implementation in
# `examples/ShoppingListPytestSK`.
#
# (If you have already implemented the shopping list in a previous workshop, it is
# better to use your own implementation instead).
