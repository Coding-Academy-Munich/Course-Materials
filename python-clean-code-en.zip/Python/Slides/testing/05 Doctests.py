# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Doctests</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Doctests.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_240_unit_testing/topic_155_doctests.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Doctests
#
# - In docstrings tests can be integrated which are executed by Pytest (or Doctest).
# - To do this, a line of code is prefixed with `>>>`.
# - The output that the Python interpreter would display for this is specified in the
#   following lines without prefix:

# %% tags=["keep"]
def add(x, y):
    """Adds two numbers or concatenates two sequences.

    >>> add(2, 3)
    5
    >>> add([1], [2])
    [1, 2]
    >>> add(1, "a")
    Traceback (most recent call last):
    ...
    TypeError: unsupported operand type(s) for +: 'int' and 'str'
    """
    return x + y


# %% tags=["keep"]
import doctest

# %% tags=["keep"]
doctest.testmod()

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mini-workshop: Doctests
#
# Write doctests for the `negate()` and `my_abs()` functions in
# `examples/SimplePytestStarterKit`.
