# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Setuptools and installation</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Setuptools and installation.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_190_setuptools/topic_110_a5_setuptools_and_installation.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Setuptools: Distribution of Python packages
#
#  - Setuptools are the default tool to create installable Python packages.
#  - The word "Packages" is overloaded in the Python world:
#      - Collection of Python files as described in the lesson about modules and packages.
#      - Distribution of an installable version of a library ("wheel"), which can then be imported.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Example: Creating an application with a library
#
#  - Add `setup.cfg` and `pyproject.toml` files with information about packages and scripts to be installed
#  - Add some help files (`README.md`, `LICENSE`)
#  - Build the distribution with `python -m build` (Requires the PyPA `build` [package](https://github.com/pypa/build))
#  - Installation with `pip` and the generated wheel
#  - Install during development: `pip install -e .`

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Workshop
#
# - `Workshop_136_todo_list_v3`
# - Section "Packaging"
