# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Protocols</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">15 Protocols.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_200_object_orientation/topic_230_protocols.py</div> -->
#
#

# %% [markdown] lang="en"
# # Protocols
#
# With protocols Python supports structural subtyping, i.e., the derivation of
# subtype relationships from the structure of classes (in contrast to nominal subtyping
# where the relationships have to be declared via inheritance).

# %%
from typing import Protocol, runtime_checkable, SupportsInt


# %%
class MyNumber:
    def __int__(self):
        return 0


# %%
my_number = MyNumber()
int(my_number)

# %%
isinstance(MyNumber, SupportsInt)


# %%
@runtime_checkable
class SupportsCastSpell(Protocol):
    def cast_spell(self, name):
        ...


# %%
@runtime_checkable
class SupportsHit(Protocol):
    def hit(self, who, how):
        ...


# %%
class Mage:
    def __init__(self, name="The Mage"):
        self.name = name

    def cast_spell(self, spell):
        print(f"{self.name} casts a {spell} spell.")


# %%
class Fighter:
    @property
    def name(self):
        return "The Fighter"

    def hit(self, opponent, weapon):
        print(f"{self.name} attacks {opponent} with {weapon}.")


# %%
class Bard:
    def __init__(self, name="The Bard"):
        self.name = name


# %%
p1 = Mage()
p2 = Fighter()
p3 = Bard()

# %%
issubclass(Mage, SupportsCastSpell)

# %%
issubclass(Fighter, SupportsCastSpell)

# %%
isinstance(p1, SupportsCastSpell)

# %%
isinstance(p2, SupportsCastSpell)

# %%
isinstance(p3, SupportsCastSpell)

# %%
isinstance(p1, SupportsHit)

# %%
isinstance(p2, SupportsHit)

# %%
isinstance(p3, SupportsHit)


# %%
@runtime_checkable
class HasName(Protocol):
    @property
    def name(self):  # noqa
        ...


# %%
isinstance(p1, HasName)

# %%
isinstance(p2, HasName)

# %%
isinstance(p3, HasName)

# %% [markdown] lang="en"
# ## Workshop: Protocols
#
# Implement a runtime checkable protocol `SupportsConnect`,
# which describes instances of classes that have a method `connect(self, device)`.

# %%
from typing import Protocol, runtime_checkable


# %%
@runtime_checkable
class SupportsConnect(Protocol):
    def connect(self, device):
        ...


# %% [markdown] lang="en"
#
# Implement classes `Plugboard` and `PatchCord` that support the
# `SupportsConnect` protocol.

# %%
class Plugboard:
    def connect(self, device):  # noqa
        print("Connecting plugboard to device.")


# %%
assert issubclass(Plugboard, SupportsConnect)

# %%
assert isinstance(Plugboard(), SupportsConnect)


# %%
class PatchCord:
    def connect(self, device):  # noqa
        print("Connecting patch cord to device.")


# %%
assert issubclass(PatchCord, SupportsConnect)

# %%
assert isinstance(PatchCord(), SupportsConnect)


# %% [markdown] lang="en"
#
# - Does the following class comply with the `SupportsConnect` protocol?
# - Is it possible to determine this at runtime?

# %% tags=["keep"]
class SelfConnector:
    def connect(self):  # noqa
        print("Connecting to self!")


# %%
assert issubclass(SelfConnector, SupportsConnect)
