# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Class Methods and Factories</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">14 Class Methods and Factories.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_200_object_orientation/topic_220_a3_class_methods_and_factories.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Class methods and factories
#
# A factory is a function (or class) used to build object instances. Class
# methods are a powerful feature of Python that is useful for implementing
# factories.
#
# Class methods are methods typically called on a class (as opposed to an
# object). In contrast to static methods (which receive no information about the
# class they are called on) they are passed a class object as argument that can
# be used to perform operations that depend on the class (such as creating
# instances).

# %%
from dataclasses import dataclass

# %%
@dataclass
class Color:
    r: float = 0.0
    g: float = 0.0
    b: float = 0.0
    color_table = {
        "white": (1.0, 1.0, 1.0),
        "red": (1.0, 0.0, 0.0),
        "green": (0.0, 1.0, 0.0),
        "blue": (0.0, 0.0, 1.0),
    }

    @classmethod
    def from_string(cls, color):
        return cls(*cls.color_table.get(color, (0.0, 0.0, 0.0)))

    @classmethod
    def from_unsigned(cls, r, g, b):
        return cls(r / 255, g / 255, b / 255)


# %%
Color(0.5, 0.5, 0.5)

# %%
Color.from_string("red")

# %%
Color.from_unsigned(255, 0, 0)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# If the constructor arguments of a subclass are compatible with the superclass,
# the class methods of the superclass can directly be used as factories for the
# subclass.

# %%
@dataclass
class AlphaColor(Color):
    alpha: float = 1.0


# %%
AlphaColor(0.5, 0.5, 0.5)

# %%
AlphaColor.from_string("red")

# %%
AlphaColor.from_unsigned(255, 0, 0)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Attributes of classes
#
# Most attributes are defined at the instance level, i.e.,
# each object has its own values for the attributes. But sometimes it
# makes sense to define attributes on the class level as well:

# %%
class CountedAdder:
    # Attribut der Klasse, wird von allen Instanzen geteilt
    num_counters = 0

    def __init__(self, value):
        CountedAdder.num_counters += 1
        # Instanzvariable (-attribut): Jede Instanz hat eigene Werte dafür
        self.value = value

    def describe(self):
        print(
            f"One of {CountedAdder.num_counters} adders. "
            f"This one adds {self.value} to its argument."
        )

    def add(self, n):
        return self.value + n


# %%
print(CountedAdder.num_counters)
a1 = CountedAdder(10)
print(CountedAdder.num_counters)
a2 = CountedAdder(20)
print(CountedAdder.num_counters)

# %%
print(a1.add(1))
print(a2.add(2))

# %%
a1.describe()
a2.describe()

# %%
print(CountedAdder.num_counters)
print(a1.num_counters)
print(a2.num_counters)

# %%
print(CountedAdder.add)
print(a1.add)
print(a2.add)


# %% [markdown] lang="en"
# ### Inheritance

# %%
class LoggingAdder(CountedAdder):
    def add(self, n):
        print(f"Adding {self.value} to {n}")
        return self.value + n


# %%
a3 = LoggingAdder(30)
print(a3.add(3))
print(a3.num_counters)

# %%
a1.describe()
a2.describe()
a3.describe()

# %%
# Method Resolution Order:
LoggingAdder.mro()

# %%
print(CountedAdder.add)
print(a1.add)
print(a2.add)
print(LoggingAdder.add)
print(a3.add)

# %%
print(CountedAdder.add)
print(a1.add.__func__)
print(a2.add.__func__)
print(LoggingAdder.add)
print(a3.add.__func__)

# %%
a1.__dict__["value"] = 15

# %%
a1.add(0)

# %%
LoggingAdder.__dict__
