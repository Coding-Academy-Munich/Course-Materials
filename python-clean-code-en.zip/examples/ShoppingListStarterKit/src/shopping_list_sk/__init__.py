# Enable this once the classes are implemented to be able to do the following:
# >>> from shopping_list import ShoppingList
# instead of
# >>> from shopping_list.shopping_list import ShoppingList

# from .shopping_list import ShoppingListItem, ShoppingList
