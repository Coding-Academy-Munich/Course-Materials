# Implement the shopping list here.


def delete_me():
    """A demonstration that doctests are configured correctly.

    >>> 1 + 1
    3
    """
