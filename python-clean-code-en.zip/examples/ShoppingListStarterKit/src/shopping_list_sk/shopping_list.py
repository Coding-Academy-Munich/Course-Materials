# Implement the classes here...


def delete_me():
    """A demonstration that doctests are working.

    >>> 1 + 1
    2
    >>> delete_me()
    Delete this function.
    It is only here to demonstrate that doctests are configured.
    """
    print(
        "Delete this function.\n"
        "It is only here to demonstrate that doctests are configured."
    )
