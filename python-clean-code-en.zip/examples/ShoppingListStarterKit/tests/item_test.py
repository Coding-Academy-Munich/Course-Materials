# from shopping_list_sk.shopping_list import ShoppingListItem


def test_default_args():
    """Check whether the default value '1' is supplied as amount."""
    assert False, "Implement this test!"
