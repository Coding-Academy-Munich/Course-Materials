# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Protokolle</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">15 Protokolle.py</div> -->

# %% [markdown] lang="de"
# # Protokolle
#
# Durch Protokolle unterstützt Python strukturelles Subtyping, bei dem
# Subtyp-Beziehungen aus der Struktur der Klassen erschlossen werden (im Gegensatz zum
# nominalen Subtyping bei dem die Beziehungen explizit deklariert werden müssen).

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
#  ## Mini-Workshop
#
#  - Notebook `workshop_190_inheritance`
#  - Abschnitt "Protokolle"
#
