# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Single-Dispatch Funktionen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">16 Single-Dispatch Funktionen.py</div> -->

# %% [markdown] lang="de"
#
# ## Single Dispatch Funktionen
#
# Single Dispatch Funktionen erlauben die definition von "Methoden"
# außerhalb von Klassen, d.h., man kann Funktionen definieren,
# die polymorph in ihrem ersten Argument sind.
#
# Dieser Mechanismus erlaubt die flexible Erweiterung von bereits existierenden Klassen.

# %% tags=["keep"]
from functools import singledispatch
from typing import Protocol, runtime_checkable


# %% tags=["keep"]
class Mage:
    def __init__(self, name="The Mage"):
        self.name = name

    def cast_spell(self, spell):
        print(f"{self.name} casts a {spell} spell.")


# %% tags=["keep"]
class Fighter:
    @property
    def name(self):
        return "The Fighter"

    def hit(self, opponent, weapon):
        print(f"{self.name} attacks {opponent} with {weapon}.")


# %% tags=["keep"]
class Bard:
    def __init__(self, name="The Bard"):
        self.name = name


# %% tags=["keep"]
p1 = Mage()
p2 = Fighter()
p3 = Bard()


# %%%% tags=["keep"]
@runtime_checkable
class HasName(Protocol):
    @property
    def name(self) -> str:
        ...

# %%

# %%

# %%

# %%

# %%

# %%
