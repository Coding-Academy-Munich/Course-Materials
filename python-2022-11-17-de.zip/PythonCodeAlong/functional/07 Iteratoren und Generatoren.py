# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Iteratoren und Generatoren</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">07 Iteratoren und Generatoren.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Iteration über verschiedene Typen
#
# Wir haben gesehen, dass z.B. die `for`-Schleife in Python für verschiedene
# Typen verwendbar ist:

# %%

# %%

# %% [markdown] lang="de"
# Der Mechanismus mit dem Python das erreicht sind Iteratoren:

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# Als Typ von iterierbaren Objekten wird oft `Iterable` verwendet:

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Einige Typen können mehr als eine Art von Iterator liefern:

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Wie funktioniert die `for`-Schleife?

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Generatoren
#
# - Es ist nicht effizient eine Liste zu konstruieren, wenn wir sie nur zum
#   Iterieren über ihre Elemente verwenden wollen
# - Python bietet die Möglichkeit Generatoren zu definieren, die iterierbar
#   sind, aber nicht den Overhead einer Liste haben
# - Die einfachste Form ist mit Generator Expressions:


# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Es ist auch möglich komplexere Generator-Expressions zu schreiben:

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# `it` ist "erschöpft," man kann keine neuen Werte bekommen:

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop "Generator-Expressions"
#
# - Berechnen Sie die Summe der ersten 100 Quadratzahlen unter Zuhilfenahme einer
#   Generator-Expression.
# - Berechnen Sie die Summe aller Zahlen zwischen 100 und 500, die durch 7 teilbar
#   sind unter Zuhilfenahme einer Generator-Expression.
# - Schreiben Sie eine Funktion
#   `all_powers(numbers: Iterable[int], powers: Iterable[int])`,
#   die eine Liste zurückgibt, deren Elemente Tupel sind, die alle Potenzen
#   aus `powers` von Elementen aus `numbers` enthalten
#


# %%

# %%

# %%

# %% tags=["keep"]
assert all_powers(range(3), range(3)) == [(1, 0, 0), (1, 1, 1), (1, 2, 4)]

# %% tags=["keep"]
assert all_powers([10, 11, 12], [2, 3]) == [(100, 1000), (121, 1331), (144, 1728)]
