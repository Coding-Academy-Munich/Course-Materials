# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Einführung in die Funktionale Programmierung</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Einführung in die Funktionale Programmierung.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Einführung in die Funktionale Programmierung
#
# Traditionelle funktionale Programmierung ist durch folgende Merkmale
# charakterisiert:
#
# - First-class und higher-order Functions
# - Unveränderliche Datentypen (immutable Data Types)
# - Rekursion statt Iteration

# %%

# %%

# %%


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop "Fakultät"
#
# Schreiben Sie eine Funktion `fact(n: int)`, die das Produkt der Zahlen von 1 bis
# `n` berechnet.


# %%

# %% tags=["keep"]
assert fact(3) == 6

# %% tags=["keep"]
assert fact(10) == 3628800

# %% tags=["keep"]
assert fact(50) == 30414093201713378043612608166064768844377641568960512000000000000


# %%

# %%

# %%

# %% tags=["keep"]
class LispList:
    pass


# %% tags=["keep"]
class Nil(LispList):
    def __repr__(self):
        return "nil"


# %% tags=["keep"]
nil = Nil()


# %%

# %% tags=["keep"]
class Cons(LispList):
    def __init__(self, first, rest):
        self.first = first
        self.rest = rest

    def __repr__(self):
        return f"({self.first}{self.rest_to_str()})"

    def rest_to_str(self) -> str:
        if isinstance(self.rest, Nil):
            return ""
        elif isinstance(self.rest, Cons):
            return f" {self.rest.first}{self.rest.rest_to_str()}"
        else:
            return f" . {self.rest}"


# %% tags=["keep"]
nil

# %% tags=["keep"]
Cons(1, Nil())

# %% tags=["keep"]
Cons(1, Cons(2, Nil()))

# %% tags=["keep"]
Cons(1, Cons(2, Cons(3, Nil())))

# %% tags=["keep"]
Cons(1, 2)


# %% tags=["keep"]
def lisp_list(*args):
    def build_list(elements):
        if len(elements) > 0:
            return Cons(elements[0], build_list(elements[1:]))
        else:
            return Nil()

    return build_list(args)


# %% tags=["keep"]
lisp_list(1, 2, 3)

# %% tags=["keep"]
lisp_ints = lisp_list(*range(10))
lisp_ints

# %% tags=["keep"]
is_empty(nil)

# %% tags=["keep"]
is_empty(lisp_ints)

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Probleme mit Rekursion in Python

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Vorteile eines funktionalen Programmierstils
#
# - Kompositionalität
# - Modularität
# - Einfaches Testen und Debuggen
