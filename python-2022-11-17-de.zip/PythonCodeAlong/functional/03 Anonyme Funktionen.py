# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Anonyme Funktionen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Anonyme Funktionen.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Anonyme Funktionen
#
# Für kurze Funktionen, die nur an einer einzigen Stelle verwendet werden, ist
# es oft unpraktisch, eine benannte Funktionsdefinition bereitzustellen:

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
example_values = [1, 2, 3, 9, 10]


# %% tags=["keep"]
def greater_than_2(n):
    return n > 2


# %% tags=["keep"]
def less_than_10(n):
    return n < 10


# %% tags=["keep"]
from typing import Callable


# %% tags=["keep"]
def print_truthy_elements(a_list: list, fun: Callable):
    for x in a_list:
        if fun(x):
            print(x)

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Für diese Fälle bietet Python Lambda-Ausdrücke als syntaktisch einfachere
# Alternative:


# %%

# %%

# %%

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def call_with_two_args(fun):
    print(f"Calling function {fun.__name__!r}")
    result = fun(2, 3)
    print(f"Result is {result}")
    return result

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Viele Funktionen für Sequenzen funktionieren gut mit Lambdas:


# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Es ist jedoch oft "pythonischer", Comprehensions zu verwenden:


# %%

# %%
