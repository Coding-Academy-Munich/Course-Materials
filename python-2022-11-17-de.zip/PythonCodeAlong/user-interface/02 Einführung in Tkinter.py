# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Einführung in Tkinter</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Einführung in Tkinter.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Einführung in Tkinter
#
# Tkinter ist ein GUI-Toolkit, der in der Standard-Python Distribution enthalten
# ist. Die Entwicklungsumgebung IDLE verwendet Tkinter für die
# Benutzeroberfläche.
#
# Das folgende Beispiel zeigt ein einfaches Tkinter-Programm um die
# Grundlegenden Features zu erklären. Es ist kein Beispiel für guten
# Programmierstil!

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Wir wollen die folgende Anwendung programmieren:
#
# <img src="img/converter-01.png"
#      style="display:block;margin:auto;width:30%"/>

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
