# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Variables (Part 2)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Variables (Part 2).py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Variable names in Python
#
# - Begin with a letter or underscore `_`
#     - Umlauts also count as letters
# - Can contain digits, letters and underscores `_`
# - May contain many other Unicode characters
#     - But it's usually better to avoid them...
# - A distinction is made between upper and lower case
#     - `A` is a different variable than `a`

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
# 2fast4u = 2

# %% tags=["keep"]
ähnlichkeitsmaß = 0.1

# %% tags=["keep"]
_größenmaßstäbe_der_fußgängerübergänge = 0.3
_größenmaßstäbe_der_fußgängerübergänge

# %% tags=["keep"]
# me@foo = 1

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
α = 0.2
β = 0.7
γ = α**2 + 3 * β**2
print(γ)
αβγ = α * β * γ
print(αβγ)
Σ = 1 + 2 + 3
print(Σ)
# ∑ = 1 + 2 + 3 # Unzulässig!


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
variable_1 = 123
VARIABLE_1 = 234
Variable_1 = 345
variablE_1 = 456

# %% tags=["keep"]
print(variable_1)
print(VARIABLE_1)
print(Variable_1)
print(variablE_1)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Style
#
# - Variable names are written in lower case
#     - Except constant variables: `CONSTANT_VAR`
# - Components are separated by underscores `_`
#     - This style is called snake case
# - Variables that start and end with two underscores
#   typically have a special meaning (*dunders*):
#     - `__class__`, `__name__`
#     - Normal user-defined variables should not be dunders

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% [markdown] lang="en"
#
# **Don't do this, even though it's possible:**

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - Sometimes "private" variables are written with a leading underscore: `_my_var`
#   - This is relatively common (for global variables)
#   - There are more conventions for classes
# - Most Python projects follow the conventions in
#   [PEP 8](https://www.python.org/dev/peps/pep-0008/#naming-conventions)

# %%

# %%

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
_my_var = 1
print(_my_var)
_my_var = _my_var + 5
print(_my_var)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Assignment to multiple variables
#
# In Python, multiple variables can be defined (or assigned values) at the same time:

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Code Cleanup
#
# The following code contains violations of the syntax coding conventions of Python.
# Code with syntax errors is commented out.
# Fix it so that the code can be evaluated in Python and conforms to the
# variable naming guidelines.

# %% lang="en" tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
__number_of_participants__ = 10
# Prize money for first and second place
# 1stPlace = 500
# 2ndPlace = 250
TotalPrizeMoney = 1000
# ΣPrizes = 1stPlace + 2ndPlace

# %% lang="en"
