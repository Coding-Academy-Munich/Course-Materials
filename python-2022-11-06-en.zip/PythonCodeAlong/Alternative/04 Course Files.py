# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Course Files</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Course Files.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Unpacking the Course Files
#
# - It is important that you unpack the zip archive before working with the files
# - Your browser may be able to open files in the zip archive, but you will not be
#   able to work with them!
# - Make a note of the location where you saved your unzipped files.
# - You will need this location shortly to open the Jupyter Notebooks.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## The Structure of the Course
#
# - Readme and configuration files are in the root directory
# - There are also two folders for code-alongs and full slides
# - Within each of these folders, there are sub-folders for each of the 4 weeks of
#   the course
# - Within these sub-folders are Jupyter Notebooks with the file extension `ipynb`
