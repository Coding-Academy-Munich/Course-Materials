# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Control Structures (Part 2)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">11 Control Structures (Part 2).py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## One-sided `if`


# %% lang="en" tags=["keep"]
def one_sided_if(number):
    print("Before")
    if number == 7:
        print(number, "is a lucky number")
        print("Congratulations!")
    print("After")


# %% lang="en" tags=["keep"]
one_sided_if(1)

# %% lang="en" tags=["keep"]
one_sided_if(7)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Multiple branches
#
#  - We want to write a game in which the player has to guess a number between 1 and
#    100.
#  - After guessing, he gets the information whether his number is too high,
#    too low or correct.
#  - In a later iteration we want to give the player multiple tries.

# %% lang="en" tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
def classify_number(guess, solution):
    if guess < solution:
        print("Your guess is too small!")
    elif guess > solution:
        print("Your guess is too big!")
    else:
        print("You have won!")


# %% lang="en" tags=["keep"]
classify_number(10, 12)

# %% lang="en" tags=["keep"]
classify_number(14, 12)

# %% lang="en" tags=["keep"]
classify_number(12, 12)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Structure of an `if` statement (complete):
#
# ```python
# if {condition 1}:
#     # Body that is executed if {condition 1} is true
# elif {condition 2}:
#     # Body that is executed if {condition 2} is true
# ...
# else:
#     # Body that is executed if none of the conditions are true
# ```
# - Only the `if` and the first body are necessary
# - If there is an `elif` or an `else`, the corresponding body may
#   not be empty

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Mini-Workshop: Positive / Negative
#
# Write a function `print_is_positive(number)` that
#
# - prints `{number} is positive.` on the screen if `number > 0`,
# - prints `{number} is zero.` on the screen if `number == 0`,
# - Print `{number} is negative.` to the screen if `number < 0`.

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% [markdown] lang="en"
# Test `print_is_positive(number)` with the values -3, 0 and 2.

# %% lang="en"
