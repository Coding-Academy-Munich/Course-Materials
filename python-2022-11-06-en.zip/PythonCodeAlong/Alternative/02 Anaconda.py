# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Anaconda</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Anaconda.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Python Distributions
#
# - There are different ways to install the Python interpreter and other software
#   needed for developing programs
#
# - The standard installation can be found on the [Python website](https:www.python.org)
#
# - [Anaconda](https:www. anaconda.com) is an alternative that is particularly
#   widespread in the machine learning area because it contains many libraries required
#   for ML

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# # Installing Anaconda
#
# - Go to the [Anaconda Website](https://www.anaconda.com/) and follow the instructions

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# # Starting the Python interpreter
#
# - Open an Anaconda command prompt (I prefer the PowerShell prompt on Windows)
# - Type `python` into the window (after the `$`-sign)
# - You should see some information about the interpreter and then the prompt `>>>`
# - Type some Python code, e.g., `17 + 4` after the prompt and press the `Enter` key
# - Python replies with the answer `21` and a new prompt
# - Type `exit()` to leave the Python interpreter
#
# Congratulations! You are now ready to work with the Python interpreter!

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# # Some tips about the Python interpreter
#
# - Upper and lower case is important!
# - The brackets after `exit()` are important!
# - If you see three dots `...` instead of the `>>>` prompt, the interpreter is waiting
#   for the continuation of an incomplete input
# - You can use `Ctrl-C` to return to the prompt from most situations
# - There are many more convenient ways working with Python than the default
#   interpreter we just used
