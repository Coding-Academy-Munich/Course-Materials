# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Control Structures (part 3)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Control Structures (part 3).py</div> -->
#
#

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Better classification
#
# In a previous video we introduced the following number classification function:

# %% lang="en" tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
def classify_number(guess, solution):
    if guess < solution:
        print("Your guess is too small!")
    elif guess > solution:
        print("Your guess is too big!")
    else:
        print("You have won!")


# %% lang="en" tags=["keep"]
classify_number(10, 12)

# %% lang="en" tags=["keep"]
classify_number(14, 12)

# %% lang="en" tags=["keep"]
classify_number(12, 12)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
#  We now want to give the player a bit more information about how close they are to the
#  correct solution:
#
# - Tell the player if the guessed number is very far from the number they are
#   looking for
# - Output: "Your guess is much too small/too big!" if the difference
#   is greater than 10


# %% lang="en" tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def classify_number_2(guessed_number, solution):
    if guessed_number < solution - 10:
        print("Your guess is much too small!")
    elif guessed_number < solution:
        print("Your guess is too small!")
    elif guessed_number > solution + 10:
        print("Your guess is way too big!")
    elif guessed_number > solution:
        print("Your guess is too big!")
    else:
        print("You have won!")


# %% lang="en" tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
classify_number_2(1, 12)

# %% lang="en" tags=["keep"]
classify_number_2(10, 12)

# %% lang="en" tags=["keep"]
classify_number_2(14, 12)

# %% lang="en" tags=["keep"]
classify_number_2(24, 12)

# %% lang="en" tags=["keep"]
klassifiziere_zahl_2(12, 12)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# The order of the `if` and `elif` branches is important:

# %% lang="en" tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def classify_number_3(guessed_number, solution):
    if guessed_number < solution:
        print("Your guess is too small!")
    elif guessed_number < solution - 10:
        print("Your guess is much too small!")
    elif guessed_number > solution:
        print("Your guess is too big!")
    elif guessed_number > solution + 10:
        print("Your guess is way too big!")
    else:
        print("You have won!")


# %% lang="en" tags=["keep"]
classify_number_3(1, 12)

# %% lang="en" tags=["keep"]
classify_number_3(100, 12)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Return from an `if` statement
#
#  The branches of an `if` statement can contain `return` statements to
#  return a value from the enclosing function:

# %% lang="en"

# %% lang="en"

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Mini workshop: Signum
#
# Write a function `signum(number)` that
#
# - returns 1 if `number > 0`,
# - returns 0 if `number == 0`,
# - returns -1 if `number < 0`.

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Test the function for representative values.

# %% lang="en"

# %% lang="en"

# %% lang="en"
