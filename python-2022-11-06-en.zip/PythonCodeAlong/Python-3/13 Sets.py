# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Sets</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">13 Sets.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Sets

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% tags=["keep"]
philosophy = (
    "Half a bee , philosophically , must ipso facto half not be . "
    "But can it be an entire bee , if half of it is not a bee , "
    "due to some ancient injury ."
)
philosophy

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Mini workshop
#
# Write a function `count_unique_words(text: str)` that prints the number of unique
# words in `text` (i.e., without repetitions, without punctuation).
#
# ```python
# >>> count_unique_words(dickens)
# 7
# >>>
# ```

# %%

# %% tags=["keep"]
dickens = "It was the best of times , it was the worst of times"

# %% tags=["keep"]
assert count_unique_words(dickens) == 7

# %% tags=["keep"]
assert count_unique_words(philosophy) == 22

# %%
