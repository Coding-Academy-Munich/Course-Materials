# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Lists</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Lists.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Lists
#
# - We can now write programs that perform many kinds of calculations, but we don't
#   yet have a way to combine multiple objects.
# - If we want to create a shopping list, for example, we currently have to use
#   the following solution:

# %% lang="en" tags=["keep"]
product_1 = "oatmeal"
product_2 = "coffee beans"
product_3 = "orange marmalade"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# This approach has many problems:
#
# - We need to know exactly how many products we want to buy
# - There is no way to perform operations on all products, e.g. print all products
# - Python does not know that the products belong together
# - ...

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## The solution: lists

# %% lang="en"

# %% [markdown] lang="en"
# The type of lists is `list`.

# %% lang="en"

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Creating lists
#
# - Lists are created by enclosing their elements in square brackets.
# - The elements of a list can be any Python values.
# - A list can contain elements of different types.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# The elements of a list do not have to be literals, it can also
# contain values of variables or expressions:

# %% lang="en" tags=["keep"]
product_1 = "oatmeal"
product_2 = "coffee beans"
product_3 = "orange marmalade"

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Once a list has been created, it has no connection to the variables that were
# used in its construction:

# %% lang="en"

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Accessing list items

# %% tags=["keep"]
numbers = [2, 4, 6, 8]

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Other ways to create lists
#
# The addition operator `+` can be used to concatenate lists:

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# The multiplication operator `*` allows the elements of a list
# be repeated:

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# The `list()` function can be used to convert some other data types into lists.
#
# At the moment we only know lists and strings as possible argument types:

# %%

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Colors (Part 1)
#
# - Define a variable `primary_colors` containing a list of the strings
#  `"red"`, `"green"` and `"blue"`.
# - Define a variable `mixed_colors` containing a list of the strings
#  `"cyan"`, `"yellow"`, and `"magenta"`.

# %% lang="en"

# %% lang="en"


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Create a list `colors` containing the elements of `primary_colors`
# followed by the elements of `mixed_colors`.

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Create a list containing 15 times the number `1`.

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Create the list `["r", "g", "b"]` from the string `"rgb"`.

# %%
