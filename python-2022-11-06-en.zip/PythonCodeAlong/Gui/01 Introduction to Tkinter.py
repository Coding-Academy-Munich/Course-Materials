# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Introduction to Tkinter</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Introduction to Tkinter.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Introduction to Tkinter
#
# Tkinter is a GUI toolkit included in the standard Python distribution. The
# IDLE development environment uses Tkinter for its user interface.
#
# The following example shows a simple Tkinter program to explain its basic
# features. It is not an example for good programming style!

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We want to build the following application:
#
# <img src="img/converter-01.png"
#      style="display:block;margin:auto;width:30%"/>


# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
