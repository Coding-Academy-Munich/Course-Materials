# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>The Python Data Model</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 The Python Data Model.py</div> -->


# %% tags=["slide", "keep"] slideshow={"slide_type": "slide"}
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def move(self, dx=0.0, dy=0.0):
        self.x += dx
        self.y += dy


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
p = Point(2, 5)

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # The Python Data Model
#
# Dunder methods can be used to make user-defined data types act more like the
# built-in ones.


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# By defining the method `__repr__(self)`, the string returned by `repr` can be
# defined for custom classes: The call `repr(x)` checks if `x` has a method
# `__repr__` and calls it if it exists.

# %% tags=["subslide", "start"] slideshow={"slide_type": "subslide"}
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def move(self, dx=0, dy=0):
        self.x += dx
        self.y += dy


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Similarly, if a `__str__()` method is defined it will be used by the `str()`
# function. However, the function `str()` delegates to `__repr__()` if no
# `__str__` method is defined:

# %% tags=["keep"]
p = Point(2, 5)
print(repr(p))

# %% tags=["keep"]
print(str(p))


# %% tags=["subslide", "start"] slideshow={"slide_type": "subslide"}
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __repr__(self):
        return f"Point({self.x!r}, {self.y!r})"

    def move(self, dx=0, dy=0):
        self.x += dx
        self.y += dy


# %% tags=["keep"]
p = Point(2, 5)
print(repr(p))

# %% tags=["keep"]
print(str(p))


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Python offers many dunder methods: see the documentation of the
# [Python data model](https://docs.python.org/3/reference/datamodel.html).

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# By defining the `__eq__()` method, the behavior of tests with `==` can be customized:


# %% tags=["subslide", "start"] slideshow={"slide_type": "subslide"}
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __repr__(self):
        return f"Point({self.x!r}, {self.y!r})"

    def move(self, dx=0, dy=0):
        self.x += dx
        self.y += dy


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
p = Point(2, 5)

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# # Motor Vehicles (Part 3)
#
# In part 2 we defined the following class `MotorVehicle`:
#
# ```python
# >>> class MotorVehicle:
# ...    def __init__(self, manufacturer, license_plate):
# ...        self.manufacturer = manufacturer
# ...        self.license_plate = license_plate
# ...
# ...    def melde_um(self, neues_kennzeichen):
# ...        self.kennzeichen = neues_kennzeichen
# ```

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Enhance this class by implementing
# - a `__repr__()` method that returns a string representation of the vehicle in
#   a suitable form and
# - a `__eq__()` method that checks for value equality.
#
#  Repeat the above examples with the new class.


# %% lang="en" tags=["subslide", "start"] slideshow={"slide_type": "subslide"}
class MotorVehicle:
    def __init__(self, manufacturer, license_plate):
        self.manufacturer = manufacturer
        self.license_plate = license_plate

    def change_registration(self, new_license_plate):
        self.license_plate = new_license_plate


# %% lang="en" tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
bmw_en = MotorVehicle("BMW", "M-BW 123")
bmw_en

# %% lang="en" tags=["keep"]
bmw2_en = MotorVehicle("BMW", "M-BW 123")
bmw2_en

# %% lang="en" tags=["keep"]
assert bmw_en == bmw2_en

# %% lang="en" tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
vw_en = MotorVehicle("VW", "WOB-VW 246")
vw_en

# %% lang="en" tags=["keep"]
assert vw_en.license_plate == "WOB-VW 246"

# %% lang="en" tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
bmw_en.change_registration("F-B 21")
bmw_en

# %% lang="en" tags=["keep"]
assert bmw_en != bmw2_en
