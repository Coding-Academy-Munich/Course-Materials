# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Types vs. Instances</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Types vs_ Instances.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Types vs. Instances
#
# In Python, user-defined data types (classes) can be defined.
#
# To prepare for this, let's look at the difference between types and instances
# of types (objects) in [Python Tutor](https://tinyurl.com/yc8r5d45).

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
list_instance = list("abc")


# %% tags=["keep"]
def my_fun(arg: list):
    pass


# %% tags=["keep"]
my_fun(list_instance)

# %% tags=["keep"]
my_fun(list("xyz"))

# %% tags=["keep"]
my_fun(list)
