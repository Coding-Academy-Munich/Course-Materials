# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>First-order functions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 First-order functions.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Functions
#
# In Python functions are first class objects, i.e., they can be referenced by
# variables, passed as arguments to functions, etc.
#
# Functions have type `Callable`.

# %%

# %%

# %%

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "Filtering elements"
#
# Write a function `return_truthy_elements(a_list: list, fun: Callable) -> list`
# that returns a list of all elements `x` of `a_list` for which
# `fun(x)` returns a true value.

# %% tags=["keep"]
example_values = [1, 2, 3, 9, 10]


# %% tags=["keep"]
def greater_than_2(n):
    return n > 2


# %% tags=["keep"]
def less_than_10(n):
    return n < 10


# %% tags=["keep"]
from typing import Callable

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# # Constructor Functions and Methods

# %%

# %%

# %%

# %%

# %%

# %%

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "Filtering elements"
#
# Write a function `my_max(values: list, key: Callable)` that returns the element
# from `values` for which `key(value)` returns the largest value. If there are
# several elements with the same value, the first one should be returned. Throw a
# `ValueError()` if `list` is empty.
#
# (Do not use the `max()` function to implement.)

# %%

# %% tags=["keep"]
from operator import neg

int_values = [1, 2, 5, 2, 4]
string_values = ["foo", "bar", "quux", "x"]

# %% tags=["keep"]
assert my_max(int_values, lambda x: x) == 5

# %% tags=["keep"]
assert my_max(int_values, neg) == 5

# %% tags=["keep"]
assert my_max(string_values, len) == "quux"

# %% tags=["keep"]
assert my_max(string_values, lambda x: x) == "x"

# %%
