# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Structured Data and XML</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Structured Data and XML.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## The XML Package
#
# See the [Python documentation](https://docs.python.org/3/library/xml.etree.elementtree.html#module-xml.etree.ElementTree)

# %%

# %%

# %%

# %%

# %% tags=["keep"]
os.remove(xml_file.name)

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# ## LXML
#
# [LXML](https://lxml.de/index.html) is an alternative with (possibly) higher performance.

# %% tags=["keep"]
