# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Pandas Series</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Pandas Series.py</div> -->


# %% [markdown] lang="en"
#
# # Pandas Type `Series`
#
# A series represents a sequence of values, similar to a Python list. Elements
# of their series can be retrieved by their numerical index, but in addition a
# series can have a semantically meaningful index (e.g., for time series).
#
# Internally, a Pandas series is backed by a numpy array, therefore most of the
# numpy operations are applicable to series as well.
#
# In addition it is easy (and cheap) to convert series to numpy.

# %% tags=["keep"]
import numpy as np
import pandas as pd

# %% [markdown] lang="en"
# ## Creation
#
# ### From Lists

# %%


# %%

# %% [markdown] lang="en"
# ### From Lists with Index

# %%

# %% [markdown] lang="en"
# ### From Range or Other Iterable

# %%

# %%

# %%

# %% [markdown] lang="en"
# ### From Dictionary

# %%

# %% [markdown] lang="en"
# ## Indices and Operations

# %% tags=["keep"]
food1 = pd.Series({"Ice Cream": 2.49, "Cake": 4.99, "Fudge": 7.99})
food2 = pd.Series({"Cake": 4.99, "Ice Cream": 3.99, "Pie": 3.49, "Cheese": 1.99})


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%

# %%


# %%


# %%


# %%


# %%


# %%


# %%

# %% [markdown] lang="en"
# ### Multiple index values

# %%


# %%


# %%


# %%


# %%


# %%


# %% tags=["keep"]
type(all_food["Pie"])


# %%

# %% [markdown] lang="en"
# ### Sorted and unsorted Indices

# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %% tags=["keep"]
# all_food['Cake':'Fudge']


# %%

# %% [markdown] lang="en"
#
# **Important:** The upper value of the slice, `"Fudge"` is contained in the
# result!

# %% [markdown] lang="en"
# ## Missing Values

# %%


# %%


# %%


# %%

# %% tags=["keep"]
