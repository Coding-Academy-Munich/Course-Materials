# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Iterators and generators</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">11 Iterators and generators.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Iteration over different Types
#
# We have seen that the `for` loop in Python can be used on different types:

# %%

# %%

# %% [markdown] lang="en"
# The mechanism that Python uses to achieve this are iterators:

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# The type of iterable elements is often specified as `Iterable`:

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Some types can return more than one kind of iterator:

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# ## How does the `for` loop work?

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Generators
#
# - It is not efficient to construct a list if we only use it for
#   want to iterate over their elements
# - Python offers the possibility to define generators that can be iterated, but don't
#   have the overhead of a list
# - The simplest way to define them is with generator expressions:

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# It is also possible to write more complex generator expressions:

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# `it` is "exhausted," one cannot get new values:

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "Generator-Expressions"
#
# - Compute the sum of the first 100 square by using a generator expression.
# - Compute the sum of all numbers between 100 and 500 that are divisible by 7
#   using a generator expression.
# - Write a function
#   `all_powers(numbers: Iterable[int], powers: Iterable[int])` that
#   returns a list whose elements are tuples containing all powers from `powers` of
#   elements from `numbers`

# %%

# %%

# %%

# %% tags=["keep"]
assert all_powers(range(3), range(3)) == [(1, 0, 0), (1, 1, 1), (1, 2, 4)]

# %% tags=["keep"]
assert all_powers([10, 11, 12], [2, 3]) == [(100, 1000), (121, 1331), (144, 1728)]
