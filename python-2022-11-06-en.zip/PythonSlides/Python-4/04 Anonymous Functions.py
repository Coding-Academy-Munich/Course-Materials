# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Anonymous Functions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Anonymous Functions.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Anonymous functions
#
# For short functions that are only used in a single place it is often
# inconvenient to provide a named function definition:

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
example_values = [1, 2, 3, 9, 10]


# %% tags=["keep"]
def greater_than_2(n):
    return n > 2


# %% tags=["keep"]
def less_than_10(n):
    return n < 10


# %% tags=["keep"]
from typing import Callable


# %% tags=["keep"]
def print_truthy_elements(a_list: list, fun: Callable):
    for x in a_list:
        if fun(x):
            print(x)


# %%
print_truthy_elements(example_values, greater_than_2)

# %%
print_truthy_elements(example_values, less_than_10)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# For these cases Python offers lambda expressions as a syntactically simpler
# alternative:

# %%
print_truthy_elements(example_values, lambda n: n > 2)

# %%
print_truthy_elements(example_values, lambda n: n < 10)

# %%
print_truthy_elements(example_values, lambda n: n % 2 == 0)


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def call_with_two_args(fun):
    print(f"Calling function {fun.__name__!r}")
    result = fun(2, 3)
    print(f"Result is {result}")
    return result


# %%
call_with_two_args(lambda x, y: 2 * x + y**2)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Many functions for sequences work well with lambdas:

# %%
filter(lambda n: n > 2, example_values)

# %%
list(filter(lambda n: n > 2, example_values))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# However, it is often more "Pythonic" to use comprehensions:


# %%
[n for n in example_values if n > 2]

# %%
