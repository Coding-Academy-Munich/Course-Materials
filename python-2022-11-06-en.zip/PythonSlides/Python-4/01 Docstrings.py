# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Docstrings</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Docstrings.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Docstrings
#
# Any function in Python can be documented using a string literal as a
# first element in the body. Most often, a `"""` string is used for this:

# %% tags=["keep"]
def my_fun(x):
    """
    Zeigt dem Benutzer den Wert von x an

    Verwendung:
    >>> my_fun(123)
    """
    print("Das Argument x hat den Wert", x)


# %%
my_fun(123)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Conventions for docstrings can be found in
# [PEP 257](https://www.python.org/dev/peps/pep-0257/).

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# The docstring of a function can be output with `help()`:

# %%
help(my_fun)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# In Jupyter, a function's docstring can be displayed by preceeding or following it with a question mark:

# %%
# # ?my_fun


# %%
# # my_fun?


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Shift-Tab is often used instead:

# %%
my_fun

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# For functions with long docstrings, you can switch to the detailed display form by pressing `Shift-Tab` twice:

# %%
my_fun

# %%
print

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Signature
#
# The number, names, default values (and possibly types) of a function's arguments and its return type are called its *signature*.
#
# Among other things, Jupyter displays the signature of a function when you type `Shift-Tab`:

# %% tags=["keep"]
def say_hi(greeting, name="world", end="."):
    print(greeting + " " + name + end)


# %%
# Shift-Tab zum Anzeigen der Signatur:
say_hi


# %% tags=["keep"]
def add_ints(m: int, n: int) -> int:
    return m + n


# %%
# Shift-Tab zum Anzeigen der Signatur:
add_ints

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Types can be combined with default values:


# %%
def say_hello(greeting: str, name: str = "world", end: str = ".") -> None:
    print(greeting + " " + name + end)


# %%
# Shift-Tab zum Anzeigen der Signatur:
say_hello
