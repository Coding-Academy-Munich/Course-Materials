# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Conversion to Strings</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Conversion to Strings.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Conversion to strings
#
# Python offers two functions that can be used to convert any value into a string:
#
# - `repr` for a "program-like" representation (how the value could be generated in
#   the program)
# - `str` for "user-friendly" rendering

# %% tags=["keep"]
text = "Hallo\nWelt!"

# %%
print(str(text))

# %%
print(repr(text))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# For some data types, `str` and `repr` return the same string:

# %% tags=["keep"]
my_list = ["a", "b", "c"]

# %%
print(str(my_list))

# %%
print(repr(my_list))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The `print()` function applies `str()` to its arguments:

# %%
text = "My\nstring"

# %%
print(repr(text))

# %%
print(str(text))

# %%
print(text)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# In f-strings, values are converted to strings with `str()`.
# With the postfix `!r`, `repr()` can be used instead.

# %% tags=["keep"]
text = "Hi,\nthere!"

# %% tags=["keep"]
print(f"{text}")

# %% tags=["keep"]
print(f"{text!s}")

# %% tags=["keep"]
print(f"{text!r}")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Conversion to strings
#
# Which function was used to get the following output?

# %% [markdown]
# ```python
# >>> my_string = "Hello, world!"
# >>> print(???(my_string))
# Hello, world!
# ```

# %% tags=["keep"]
my_string = "Hello, world!"

# %%
print(str(my_string))

# %% [markdown]
# ```python
# >>> print(???(my_string))
# 'Hello, world!'
# ```

# %%
print(repr(my_string))
