# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Inheritance</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">12 Inheritance.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Inheritance
#
# We have implemented the following class:

# %% tags=["keep"]
import random


# %% tags=["keep"]
class Point:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    def __repr__(self):
        return f"Point({self.x:.1f}, {self.y:.1f})"

    def move(self, dx=0, dy=0):
        self.x += dx
        self.y += dy

    def randomize(self):
        self.x = random.gauss(2, 0.5)
        self.y = random.gauss(3, 0.5)


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
p = Point(1, 1)
p

# %% tags=["keep"]
p.move(2, 3)
p

# %% tags=["keep"]
p.randomize()
p


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# How can we introduce colored points without having to re-implement the
# entire functionality of `Point`?

# %%
class ColorPoint(Point):
    def __init__(self, x=0, y=0, color="black"):
        super().__init__(x, y)
        self.color = color

    def __repr__(self):
        return f"ColorPoint({self.x:.1f}, {self.y:.1f}, {self.color!r})"

    def randomize(self):
        super().randomize()
        self.color = random.choice(["black", "red", "green", "blue", "yellow", "white"])


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
cp = ColorPoint(2, 3)
# cp


# %% tags=["keep"]
assert cp.x == 2.0
assert cp.y == 3.0
assert cp.color == "black"

# %% tags=["keep"]
cp.color = "red"

# %% tags=["keep"]
assert cp.x == 2.0
assert cp.y == 3.0
assert cp.color == "red"

# %% tags=["keep"]
cp.move(2, 3)
# cp


# %% tags=["keep"]
assert cp.x == 4.0
assert cp.y == 6.0
assert cp.color == "red"

# %% tags=["keep"]
cp.randomize()
# cp

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Workshop: Employees
#
# In the following we will implement a class hierarchy for employees of a company:
#
# - Employees can be either workers or managers
# - Each employee of the company has a name, a personnel number and a
#   base salary
# - For each worker, the accumulated overtime and the hourly wage
#   are stored in attributes.
# - A worker's salary is calculated as 13/12 times the
#   base salary plus overtime pay
# - Each manager has an individual bonus
# - A manager's salary is calculated as 13/12 times the
#   base salary plus bonus
#
# Implement Python classes `Employee`, `Worker` and `Manager` with
# appropriate attributes and a method `salary()` that calculates the salary.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
from dataclasses import dataclass

from numpy import isin


# %%
@dataclass
class Mitarbeiter:
    name: str
    pers_nr: str
    grundgehalt: float

    @property
    def gehalt(self):
        return 13 / 12 * self.grundgehalt


# %%
@dataclass
class Arbeiter(Mitarbeiter):
    überstunden: float = 0.0
    stundensatz: float = 0.0

    @property
    def gehalt(self):
        return super().gehalt + self.überstunden * self.stundensatz


# %%
@dataclass
class Manager(Mitarbeiter):
    bonus: float

    @property
    def gehalt(self):
        return super().gehalt + self.bonus


# %% [markdown] lang="en"
#
# Create a worker named Hans, personnel number 123, a base salary of
# 36000.0 Euros, who worked 3.5 hours of overtime at 40.0 euros each.
# Print out the salary.

# %%
a = Arbeiter("Hans", "123", 36_000, 3.5, 40.0)
print(a.gehalt)
a

# %% [markdown] lang="en"
#
# Write assertions to test the functionality of the class `Worker`.

# %%
# Diese Assertions sind überflüssig! /  These assertions are superfluous!
assert a.name == "Hans"
assert a.pers_nr == "123"
assert a.grundgehalt == 36_000
assert a.überstunden == 3.5
assert a.stundensatz == 40.0

# Diese Assertion sollte vorhanden sein / This is the assertion that should be present
assert a.gehalt == 39_140.0

# %% [markdown] lang="en"
# Create a manager named Sepp, personnel number 666, who is a
# base salary of 60000.0 euros and a bonus of 30000.0 euros. Print out
# the salary.

# %%
m = Manager("Sepp", "666", 60_000.0, 30_000.0)
print(m.gehalt)
m

# %% [markdown] lang="en"
# Test the functionality of the class `Manager`.

# %%
assert m.gehalt == 95_000.0


# %% [markdown] lang="en" tags=["alt"]
# ## Solution without dataclasses:

# %% tags=["alt"]
class Mitarbeiter:
    def __init__(self, name, pers_nr, grundgehalt):
        self.name = name
        self.pers_nr = pers_nr
        self.grundgehalt = grundgehalt

    @property
    def gehalt(self):
        return 13 / 12 * self.grundgehalt


# %% tags=["alt"]
class Arbeiter(Mitarbeiter):
    def __init__(self, name, pers_nr, grundgehalt, überstunden, stundensatz):
        super().__init__(name, pers_nr, grundgehalt)
        self.überstunden = überstunden
        self.stundensatz = stundensatz

    def __repr__(self):
        return (
            f"Arbeiter({self.name!r}, {self.pers_nr!r}, {self.grundgehalt}, "
            f"{self.überstunden}, {self.stundensatz})"
        )

    @property
    def gehalt(self):
        return super().gehalt + self.überstunden * self.stundensatz


# %% tags=["alt"]
class Manager(Mitarbeiter):
    def __init__(self, name, pers_nr, grundgehalt, bonus):
        super().__init__(name, pers_nr, grundgehalt)
        self.bonus = bonus

    def __repr__(self):
        return (
            f"Manager({self.name!r}, {self.pers_nr!r}, {self.grundgehalt}, "
            f"{self.bonus})"
        )

    @property
    def gehalt(self):
        return super().gehalt + self.bonus


# %% tags=["alt"]
a = Arbeiter("Hans", 123, 36_000, 3, 40)
print(a.gehalt)
a

# %% tags=["alt"]
m = Manager("Sepp", 666, 60_000, 30_000)
print(m.gehalt)
m
