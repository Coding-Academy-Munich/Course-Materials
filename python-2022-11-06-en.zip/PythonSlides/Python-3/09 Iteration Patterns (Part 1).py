# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Iteration Patterns (Part 1)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 Iteration Patterns (Part 1).py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Iteration Patterns
#
# Iteration is often used in a relatively "schematic" way.
# In the following, we consider different "patterns" how iteration is used.

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Aggregation of list items

# %%
def summe(zahlen):
    ergebnis = 0
    for n in zahlen:
        ergebnis += n
    return ergebnis


# %%
summe([1, 2, 3])


# %% [markdown] lang="en"
# ## Mini-Workshop: Mean value of a list
#
# The mean of a list with $n$ elements $[x_0, \dots, x_{n-1}]$ is
# defined as
#
# $$\frac{x_0 + \dots + x_{n-1}}{n}$$
#
# Write a function `mean(number: list)` that calculates the mean of a list.

# %% lang="en"
def mean(numbers: list):
    if numbers:
        result = 0
        for number in numbers:
            result += number
        return result / len(numbers)
    return 0


# %% [markdown] lang="en"
# Test the function for appropriate arguments.

# %% lang="en"
assert mean([1, 2, 3]) == 2.0

# %% lang="en"
assert mean([]) == 0

# %% [markdown] lang="en"
#
# ### Bonus task
#
# The mean of the elements of a list $[x_0, \dots, x_{n-1}]$ can be calculated
# iteratively as follows:
#
# - The mean $m$ of the empty list is (by definition for this solution) 0
# - If we add the $n$-th element $x_n$, then the new mean is calculated as
#
# $$m \leftarrow m + \frac{x_n - m}{n+1}$$
#
# Write a function `iterative_average(numbers: list)` that calculates the mean of a
# list iteratively.


# %% lang="en"
def iterative_mean(numbers):
    result = 0
    for pos, value in enumerate(numbers, 1):
        result += (value - result) / pos
    return result


# %% lang="en"
assert iterative_mean([]) == 0.0

# %% lang="en"
assert iterative_mean([1]) == 1.0

# %% lang="en"
assert iterative_mean([1, 2, 3]) == 2.0

# %% lang="en"
assert iterative_mean(range(11)) == 5.0
