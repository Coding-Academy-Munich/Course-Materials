# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Assignment to Slices</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Assignment to Slices.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Assignment to slices
#
# You can assign values to slices:

# %%
liste = [1, 2, 3, 4]
liste[1:3]

# %%
liste[1:3] = ["a", "b", "c"]
liste

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
liste[2:2]

# %%
liste[2:2] = ["x"]
liste

# %%
liste[:] = [11, 22, 33]
liste

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Changing Priorities
#
# Given the following list of priorities:

# %% lang="en" tags=["keep"]
priorities = ["very low", "chill, man", "extremely high"]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Change the list `priorities` to the following list by assigning to a slice:
# ```python
# ['very low', 'low', 'medium', 'high', 'extremely high']
# ```

# %% lang="en" tags=["keep"]
priorities

# %% lang="en"
priorities[1:2]

# %% lang="en"
priorities[1:2] = ["low", "medium", "high"]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Use assignment to a slice to replace the contents of `priorities` with the
# numbers `5, 4, 3, 2, 1`.
#
# *Note:* Use a range for this.

# %% lang="en"
priorities[:] = range(5, 0, -1)
priorities
