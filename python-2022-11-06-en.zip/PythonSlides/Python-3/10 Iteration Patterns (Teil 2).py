# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Iteration Patterns (Teil 2)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">10 Iteration Patterns (Teil 2).py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Transformation of lists

# %%
result = []
for item in [1, 2, 3, 4]:
    result.append(item + 1)
result

# %%
result = []
for n in [1, 2, 3, 4]:
    result.append(f"Item {n}")
result

# %% [markdown] lang="en"
# ## Mini-Workshop: Square numbers
#
# Given the following list of numbers.

# %% lang="en" tags=["keep"]
numbers = [1, 7, 4, 87, 23]

# %% [markdown] lang="en"
# Create a new list containing the squares of the numbers in `numbers`.

# %% lang="en"
result = []
for n in numbers:
    result.append(n * n)
result


# %% [markdown] lang="en"
# Write a function `square(numbers)` that returns a new list with the
# squares the numbers in `numbers`.

# %% lang="en"
def square(numbers):
    result = []
    for n in numbers:
        result.append(n * n)
    return result


# %% lang="en"
assert square(numbers) == [1, 49, 16, 7569, 529]
