# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Dictionaries</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Dictionaries.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# # Dictionaries
#
# - Dictionaries are a data structure that maps keys to values
# - Many types are possible for keys:
#   - Integer values
#   - Strings
#   - Tuples
#   - ...
# - Modifiable objects, such as lists, cannot be used as keys
# - Values can be arbitrary Python objects
# - The entries in a dictionary are not arranged in any particular order
# - Entries can be added, deleted and modified.


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Empty dictionary:

# %%
{}

# %%
type({})

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Dictionary with string keys:

# %% tags=["keep"]
translations = {"snake": "Schlange", "bat": "Fledermaus", "horse": "Hose"}
translations

# %%
translations["snake"]

# %%
# translations["monkey"]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Access with default value

# %% tags=["keep"]
translations = {"snake": "Schlange", "bat": "Fledermaus", "horse": "Hose"}

# %%
translations.get("snake")

# %%
translations.get("monkey")

# %%
translations

# %%
translations.get("monkey", "<unbekannt>")

# %%
translations

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Modification of elements

# %% tags=["keep"]
translations = {"snake": "Schlange", "bat": "Fledermaus", "horse": "Hose"}
translations

# %%
translations["horse"] = "Pferd"

# %%
translations

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Update with default value

# %% tags=["keep"]
translations = {"snake": "Schlange", "bat": "Fledermaus", "horse": "Pferd"}
translations

# %%
translations.get("bird", "Vogel")

# %%
translations

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
translations = {"snake": "Schlange", "bat": "Fledermaus", "horse": "Pferd"}
translations

# %%
translations.setdefault("bird", "Vogel")

# %%
translations

# %%
translations.setdefault("bird", "<unbekannt>")

# %%
translations
# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mini workshop "inverse index"
#
# Write a function `first_index(a_list: list) -> dict` that returns a dictionary
# `d` for which:
#
# - The keys in `d` are all values occurring in `a_list`
# - For each element `elt` of `a_list`, the value of `d[elt]` is the first index
#   at which `elt` occurs in `a_list`
#
# ```python
# >>> first_index(["a", "b", "b"])
# {'a': 0, 'b': 1}
# ```
#
# *Hint:* A simple solution uses the `enumerate()` function.
#
# Ensure that your solution satisfies the given tests.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def first_index(a_list: list):
    result = {}
    for index, elt in enumerate(a_list):
        result.setdefault(elt, index)
    return result


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
example_values = ["a", "b", "c", "b", "a", "c", "a"]

# %% tags=["keep"]
ii = first_index(example_values)

# %% tags=["keep"]
assert ii["a"] == 0

# %% tags=["keep"]
assert ii["b"] == 1

# %% tags=["keep"]
assert ii["c"] == 2

# %% tags=["keep"]
assert ii.get("d") is None


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Write a function `inverse_index(a_list: list) -> dict` that returns a dictionary
# `d` for which:
#
# - The keys in `d` are all values occurring in `a_list`
# - For each value `elt` contained in `a_list`, the value of `d[elt]`
#   is the list with all indices at which `elt ` occurs in `a_list`
#
# ```python
# >>> inverse_index(["a", "b", "b"])
# {'a': [0], 'b': [1, 2]}
# ```

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def inverse_index(a_list: list):
    result = {}
    for index, elt in enumerate(a_list):
        indices = result.setdefault(elt, [])
        indices.append(index)
    return result


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
example_values = ["a", "b", "c", "b", "a", "c", "a"]

# %% tags=["keep"]
ii = inverse_index(example_values)

# %% tags=["keep"]
assert ii["a"] == [0, 4, 6]

# %% tags=["keep"]
assert ii["b"] == [1, 3]

# %% tags=["keep"]
assert ii["c"] == [2, 5]

# %% tags=["keep"]
assert ii.get("d") is None
# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Preparation for the upcoming workshop

# %% tags=["keep"]
advice = "Don't worry be happy"

# %% tags=["keep"]
words = advice.split()

# %% tags=["keep"]
" ".join(words)

# %% tags=["keep"]
smileys = {"worry": "\U0001f61f", "happy": "\U0001f600"}


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Mini workshop
#
# Write a function `replace_words(text: str, replacements: dict)` that replaces all
# words occurring as key in `dict` with their values in `dict`.
#
# ```python
# >>> replace_words(advice, smileys)
# "Don't 😟 be 😀"
# ```

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Hints
#
# - Split `text` into a list of individual words
#
# - Create an empty list called `new_words`
#
# - Iterate over `words`; add each word that does not appear in `replacements` to
# `new_words`; for every word that appears in `replacements`, add its value
#
# - Use the `join()` method to turn `new_words` into a single string


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def replace_words(text: str, replacements: dict):
    new_words = []
    for word in text.split():
        new_words.append(replacements.get(word, word))
    return " ".join(new_words)


# %% tags=["keep"]
assert replace_words(advice, smileys) == "Don't 😟 be 😀"

# %% tags=["keep"]
assert replace_words("happy happy", smileys) == "😀 😀"


# %% tags=["alt", "subslide"] slideshow={"slide_type": "subslide"}
def replace_words_2(text: str, replacements: dict):
    return " ".join(replacements.get(word, word) for word in text.split())


# %% tags=["alt"]
assert replace_words_2(advice, smileys) == "Don't 😟 be 😀"
assert replace_words_2("happy happy", smileys) == "😀 😀"
