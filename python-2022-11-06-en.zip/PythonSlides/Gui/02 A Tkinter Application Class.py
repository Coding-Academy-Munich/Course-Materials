# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>A Tkinter Application Class</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 A Tkinter Application Class.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # An Object-oriented Tkinter Application
#

# %% tags=["keep"]
from dataclasses import dataclass
import tkinter as tk
import tkinter.ttk as ttk

# %% tags=["keep"]
def convert_fahrenheit_to_celsius(fahrenheit):
    return (fahrenheit - 32) * 5 / 9


# %% tags=["keep"]
class FahrenheitToCelsiusConverter:
    def __init__(self):
        root = tk.Tk()
        root.title = "Convert Fahrenheit to Celsius"
        root.columnconfigure(1, weight=1)
        root.rowconfigure(1, weight=1)

        main_frame = ttk.Frame(root, padding="3 3 12 12")
        main_frame.grid(column=1, row=1, sticky="NSEW")

        fahrenheit_text = tk.StringVar()
        fahrenheit_entry = ttk.Entry(main_frame, width=6, textvariable=fahrenheit_text)
        fahrenheit_entry.grid(column=2, row=1, sticky="EW")
        fahrenheit_entry.focus()

        celsius_text = tk.StringVar(value="<none>")
        celsius_label = ttk.Label(main_frame, textvariable=celsius_text)
        celsius_label.grid(column=2, row=2, sticky="EW")

        convert_button = ttk.Button(
            main_frame,
            text="Convert",
            default="active",
            command=self.perform_conversion,
        )
        convert_button.grid(column=2, row=3, sticky="E")
        root.bind("<Return>", self.perform_conversion)

        ttk.Label(main_frame, text="Fahrenheit:").grid(column=1, row=1, sticky="E")
        ttk.Label(main_frame, text="Celsius:").grid(column=1, row=2, sticky="E")

        main_frame.columnconfigure(2, weight=1)
        main_frame.rowconfigure(0, weight=1)
        main_frame.rowconfigure(99, weight=1)

        for child in main_frame.winfo_children():
            child.grid_configure(padx=2, pady=1)

        self.root = root
        self._fahrenheit_text = fahrenheit_text
        self._celsius_text = celsius_text

    @property
    def fahrenheit_text(self):
        return self._fahrenheit_text.get()

    @fahrenheit_text.setter
    def fahrenheit_text(self, new_value):
        assert isinstance(
            new_value, str
        ), f"Cannot set fahrenheit_text to {type(new_value)!r}."
        self._fahrenheit_text.set(new_value)

    @property
    def celsius_text(self):
        return self._celsius_text.get()

    @celsius_text.setter
    def celsius_text(self, new_value):
        assert isinstance(
            new_value, str
        ), f"Cannot set celsius_text to {type(new_value)!r}."
        self._celsius_text.set(new_value)

    def perform_conversion(self, *args):
        try:
            celsius = convert_fahrenheit_to_celsius(float(self.fahrenheit_text))
            self.celsius_text = f"{celsius:.2f}"
        except:
            self.fahrenheit_text = ""
            self.celsius_text = "<none>"

    def run(self):
        self.root.mainloop()


# %%
app = FahrenheitToCelsiusConverter()

# %%
# app.run()

# %% [markdown] lang="en"
# ## Mini workshop: Conversion to miles with GUI
#
# The function `convert_km_to_miles(km)` converts from kilometers to miles:

# %% lang="en" tags=["keep"]
def convert_km_to_miles(km):
    return km * 0.621371


# %% [markdown] lang="en"
#
# Write a class `DistanceConverter` that provides a GUI that allows users to
# enter a distance in kilometers and see the equivalent distance in miles. If
# the input is is invalid, the text `no distance`" shall be displayed.

# %% tags=["keep"]
class DistanceConverter:
    def __init__(self):
        root = tk.Tk()
        root.title = "Convert Kilometers to Miles"
        root.columnconfigure(1, weight=1)
        root.rowconfigure(1, weight=1)

        main_frame = ttk.Frame(root, padding="3 3 12 12")
        main_frame.grid(column=1, row=1, sticky="NSEW")

        km_text = tk.StringVar()
        km_entry = ttk.Entry(main_frame, width=6, textvariable=km_text)
        km_entry.grid(column=2, row=1, sticky="EW")
        km_entry.focus()

        miles_text = tk.StringVar(value="<no distance>")
        miles_label = ttk.Label(main_frame, textvariable=miles_text)
        miles_label.grid(column=2, row=2, sticky="EW")

        convert_button = ttk.Button(
            main_frame,
            text="Convert",
            default="active",
            command=self.perform_conversion,
        )
        convert_button.grid(column=2, row=3, sticky="E")
        root.bind("<Return>", self.perform_conversion)

        ttk.Label(main_frame, text="Km:").grid(column=1, row=1, sticky="E")
        ttk.Label(main_frame, text="Miles:").grid(column=1, row=2, sticky="E")

        main_frame.columnconfigure(2, weight=1)
        main_frame.rowconfigure(0, weight=1)
        main_frame.rowconfigure(99, weight=1)

        for child in main_frame.winfo_children():
            child.grid_configure(padx=2, pady=1)

        self.root = root
        self._km_text = km_text
        self._miles_text = miles_text

    @property
    def km_text(self):
        return self._km_text.get()

    @km_text.setter
    def km_text(self, new_value):
        assert isinstance(new_value, str), f"Cannot set km_text to {type(new_value)!r}."
        self._km_text.set(new_value)

    @property
    def miles_text(self):
        return self._miles_text.get()

    @miles_text.setter
    def miles_text(self, new_value):
        assert isinstance(
            new_value, str
        ), f"Cannot set miles_text to {type(new_value)!r}."
        self._miles_text.set(new_value)

    def perform_conversion(self, *args):
        try:
            miles = convert_km_to_miles(float(self.km_text))
            self.miles_text = f"{miles:.2f}"
        except:
            self.km_text = ""
            self.miles_text = "<no distance>"

    def run(self):
        self.root.mainloop()


# %%
dc = DistanceConverter()

# %%
dc.run()
# %%
