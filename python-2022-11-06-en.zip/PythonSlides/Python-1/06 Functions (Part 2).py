# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Functions (Part 2)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Functions (Part 2).py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Visualization on Python Tutor
#
# Visualization on the
# [Python Tutor](https://pythontutor.com/render.html#code=def%20pythagoras%28a,%20b%29%3A%0A%20%20%20%20c%20%3D%20%28a**2%20%2B%20b**2%29%20**%200.5%0A%20%20%20%20return%20c%0A%0Aergebnis%20%3D%20pythagoras%283,%204%29&cumulative=false&curInstr=0&heapPrimitives=true&mode=display&origin=opt-frontend.js&py=3&rawInputLstJSON=%5B%5D&textReferences=false)
# web site.


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Back to fences
#
# - So far we have calculated the length of the third side of our property.
# - We still need a function that calculates the total length:


# %% lang="en" tags=["keep"]
def pythagoras(a, b):
    c = (a**2 + b**2) ** 0.5
    return c


# %% lang="en"
def total_length(x, y):
    z = pythagoras(x, y)
    length = x + y + z
    return length


# %%
länge_a = 10  # Beispielwert
länge_b = 40  # Beispielwert
print(gesamtlänge(länge_a, länge_b))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# With this we can simplify our problem:

# %%
length_a = 10  # Example value
length_b = 40  # Example value
print(total_length(length_a, length_b))


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Visualization on Python Tutor
#
# Visualization on the
# [Python Tutor](https://pythontutor.com/render.html#code=def%20pythagoras%28a,%20b%29%3A%0A%20%20%20%20c%20%3D%20%28a**2%20%2B%20b**2%29%20**%200.5%0A%20%20%20%20return%20c%0A%0Adef%20gesamtl%C3%A4nge%28x,%20y%29%3A%0A%20%20%20%20z%20%3D%20pythagoras%28x,%20y%29%0A%20%20%20%20l%C3%A4nge%20%3D%20x%20%2B%20y%20%2B%20z%0A%20%20%20%20return%20l%C3%A4nge%0A%20%20%20%20%0Al%C3%A4nge_a%20%3D%2010%0Al%C3%A4nge_b%20%3D%2040%0Aprint%28gesamtl%C3%A4nge%28l%C3%A4nge_a,%20l%C3%A4nge_b%29%29&cumulative=false&curInstr=0&heapPrimitives=true&mode=display&origin=opt-frontend.js&py=3&rawInputLstJSON=%5B%5D&textReferences=false)
# web site.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini workshop: Donations
#
# At a fundraiser, the television broadcaster ZRD promised to double every
# incoming donation. Regional broadcaster YB3 increases every donation received
# by 10 euros. (ZRD doubles before adding YB3's €10.)
#
# Write a Python function `effective_donation(donation)` that calculates the
# amount actually given to charity when a viewer donates $N$ euros.

# %% lang="en"
def effective_donation(donation):
    return 2 * donation + 10


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# What is the effective donation if a viewer donates 20 euros?

# %% lang="en"
effective_donation(20)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Display the effective donations for 10, 25, 50, 100 and 500 euros on the
# screen.
#
# *Note:* You can complete inputs with the `Tab` key. It is thus sufficient if
# you type
#
# `pri`-*Tab* `eff`-*Tab*
#
# before typing the arguments.

# %% lang="en"
print(effective_donation(10))
print(effective_donation(25))
print(effective_donation(50))
print(effective_donation(100))
print(effective_donation(500))
