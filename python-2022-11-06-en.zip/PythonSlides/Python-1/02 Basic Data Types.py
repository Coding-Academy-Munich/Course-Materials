# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Basic Data Types</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Basic Data Types.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Variables and data types
#
# Numbers and arithmetic:

# %%
17 + 4

# %%
1.5 + 7.4

# %%
1 + 2 * 3

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
type(1)

# %%
type(1.0)

# %%
type("1")

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
10000000000000000000000000000000000000000000000000 + 1

# %%
type(10000000000000000000000000000000000000000000000000)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Strings

# %%
"Hello, world!"

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# fmt: off
'This is a text'
# fmt: on

# %%
str(1 + 2)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
"1" + "2"

# %% lang="en"
"""Some text,
spanning multiple lines."""

# %% lang="en"
"Literal strings " "can be concatenated " "by juxtaposition"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Displaying values with the `print()` function
#
# To display multiple values you can use the `print()` function:
#
# `print(...)` prints the values between the trailing parens on the screen.

# %%
print(123)

# %%
print("Hello, world!")

# %%
print("Der Wert von 1 + 1 ist", 1 + 1, ".")

# %%
print("Der Wert von 1 + 1 ist", 1 + 1, ".", sep="")

# %%
print("a", end=", ")
print("b", end=", ")
print("c")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Variables

# %%
answer = 42

# %%
my_value = answer + 2

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Variables
#
# <img src="img/variables-01.svg" style="float:right;margin:auto;width:50%"/>
#
# A *variable* is
# - a <span style="color:red;">"reference"</span> to an "object"
# - which has a <span style="color:red;">name</span>.
#
# <span style="color:blue;">An object </span> can be referenced
# by<span style="color:blue;"> several variables </span>!

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Types

# %%
type(123)

# %%
type("Foo")

# %%
answer = 42
print(type(answer))
answer = "Hallo!"
print(type(answer))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Predefined functions

# %%
print("Hello, world!")

# %%
int("123")

# %%
int(3.8)

# %%
round(4.4)

# %%
round(4.6)

# %% tags=["keep"]
print(round(0.5), round(1.5), round(2.5), round(3.5))


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mini-workshop: Built-in Functions
#
# In this workshop your goal is to solve some tasks with predefined functions.
# Some of these functions have not yet been discussed. Use the [built-in-functions
# table](https://docs.python.org/3/library/functions.html#built-in-functions) to find
# suitable candidates.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Convert the number `1.5` into a string.

# %%
str(1.5)

# %% [markdown] lang="en"
#
# Find the maximum of the numbers 2.5 and 1.7 using a built-in function.

# %%
max(2.5, 1.7)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Convert the string "1.234" into a floating point number and add `2.345`.

# %%
float("1.234") + 2.345
