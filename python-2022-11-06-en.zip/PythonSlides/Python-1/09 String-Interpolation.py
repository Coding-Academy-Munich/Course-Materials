# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>String-Interpolation</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 String-Interpolation.py</div> -->


# %% lang="en"
name = "John"
number = 12
f"Hello {name}, the number is {number + 1}."

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # String interpolation: F-strings
#
# Python offers the possibility to insert values into strings:

# %% lang="en" tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
player_name = "John"
number_games = 10
number_wins = 2

output = f"Hello {player_name}!\nYou played {number_games} games and won {number_wins} times."
print(output)

# %% lang="en" tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
output = (
    f"Hello {player_name}!\n"
    f"You played {number_games} games "
    f"and won {number_wins} times."
)
print(output)

# %% lang="en" tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
output = f"""\
Hello {player_name}!
You played {number_games} games \
and won {number_wins} times.
"""
print(output)


# %% [markdown] lang="en"
#
# ## Mini workshop: Greeting
#
# Write a function `print_greeting(name)` that prints a personalized outputs a
# greeting, e.g.
# ```
# Hello John!
# Nice to welcome you again today.
# We wish you a lot of fun, John.
# ```
# Use string interpolation to achieve this.

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
def print_greeting(name):
    print(
        f"Hello {name}!\n"
        f"Nice to welcome you again today.\n"
        f"We wish you a lot of fun, {name}."
    )


# %% lang="en"
print_greeting("John")

# %%
