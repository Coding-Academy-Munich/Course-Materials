# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Assertions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Assertions.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Assertions
#
# Assertions are a great way to ensure that a property holds. If the checked
# property is true, the assertion does nothing.

# %%
assert 1 == 1

# %%
assert 1 != 2

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# If the tested property is not fulfilled, an error is triggered:

# %%
# assert 1 == 2


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Mini workshop
#
# Given the following statements:

# %% tags=["keep"]
my_int = 1
my_float = 1.0

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Write an assertion for each of the following properties that does not throw an
# exception and asserts either the property or its negation:
#
# - `my_int == 1`
# - `my_float == my_int`
# - `my_float == "1.0"`

# %%
assert my_int == 1
assert my_float == my_int
assert my_float != "1.0"
