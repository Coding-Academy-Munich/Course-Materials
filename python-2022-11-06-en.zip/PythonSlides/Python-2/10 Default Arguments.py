# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Default Arguments</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">10 Default Arguments.py</div> -->


# %% [markdown] lang="en" tags=["private"]
#
# Note: This requires the lesson on lists!

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Default arguments
#
# Function parameters can have a default value.
# - The default value is given with the syntax `parameter=value`
# - If the corresponding argument is not passed, the default value is used
# - If a parameter has a default value, all values to the right of it must also have one


# %%
def say_hi(greeting, name="world", end="."):
    print(greeting + " " + name + end)


# %%
say_hi("Hello")
say_hi("Hi", "Joe")
say_hi("What's up", "Jane", "?")


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Be careful with variable default arguments

# %%
def append_value(value, my_list=[]):
    my_list.append(value)
    return my_list


# %%
append_value(1)

# %%
append_value(2)


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# Solution: use `Null` as argument, create a new list in each call

# %%
def append_value(value, my_list=None):
    if my_list is None:
        my_list = []
    my_list.append(value)
    return my_list


# %%
append_value(1)

# %%
append_value(2)
