# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Arbitrary numbers of function arguments</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 Arbitrary numbers of function arguments.py</div> -->


# %% [markdown] tags=["private"]
# Requires lists and dicts

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Any number of function arguments:
#
# You can define functions that can take any number of arguments:

# %%
def my_add(*args):
    result = 0
    for i in args:
        result += i
    return result


# %%
my_add(1, 2, 3, 4, 5, 6)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# This can also be combined with other arguments:

# %%
def add_more_than_two(x, y, *more_args):
    result = x + y
    for i in more_args:
        result += i
    return result


# %%
add_more_than_two(1, 2, 3, 4, 5, 6)

# %%
add_more_than_two(1, 2)


# %%
# add_more_than_two(1)


# %% [markdown] lang="en"
# ## Mini workshop
#
# Write a function `print_lines(*args)` that can take any number of arguments and prints them all, one argument per line:
# ```
# >>> print_lines("hey", "you")
# hey
# you
# ```

# %%
def print_lines(*args):
    for arg in args:
        print(arg)


# %%
print_lines("hey", "you")


# %% [markdown] lang="en"
#
# *End of the workshop*

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Any number of named arguments:
#
# Likewise, a function can have any number of named arguments:

# %%
def my_keys(**kwargs):
    print("Keyword arguments:", kwargs)


# %%
my_keys(x=1, y=2)


# %% [markdown] lang="en"
# It is possible to combine these two features:

# %%
def takes_arbitrary_args(*args, **kwargs):
    print("Positional arguments:", args)
    print("Keyword arguments:    ", kwargs)


# %%
takes_arbitrary_args(1, "foo", a="alpha", b="beta")


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Mini workshop
#
# Write a function `print_named_lines(**kwargs)` that can take any number of
# Keyword arguments and prints them in the following form:
# ```python
# >>> print_named_lines(foo="My Foo", bar="My Bar", quux="My Quux")
# Key: foo -- value: My Foo
# Key: bar -- value: My Bar
# Key: quux -- value: My Quux
# ```

# %%
def print_named_lines(**kwargs):
    for k, v in kwargs.items():
        print("Key:", k, "-- value:", v)


# %% tags=["keep"]
print_named_lines(foo="My Foo", bar="My Bar", quux="My Quux")


# %% [markdown] lang="en"
#
# *End of the workshop*


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## "Splicing" of arguments
#
# - If you have a list `args`, you can pass its values as positional arguments
#   using the syntax `*args`.
# - If you have a dictionary `kwargs`, you can pass its key-value pairs as
#   named arguments with the syntax `**kwargs`:

# %%
def add(x, y):
    return x + y


# %%
my_list = [3, 4]

# %%
# add(my_list)

# %%
add(my_list[0], my_list[1])

# %%
add(*my_list)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
my_dict = {"a": "alpha", "b": "beta"}

# %%
takes_arbitrary_args(my_list, my_dict)

# %%
takes_arbitrary_args(*my_list, **my_dict)

# %%
takes_arbitrary_args(3, 4, a="alpha", b="beta")
