# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Universal Functions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Universal Functions.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Universal Functions
#
# [Universal functions](https://numpy.org/doc/stable/reference/ufuncs.html)
# are functions that can be executed on numpy arrays as well as
# other data types such as lists or scalars, and that operate element-wise on their
# arguments.

# %% tags=["keep"]
import numpy as np

# %% tags=["keep"]
l1 = [1.0, 2.0, 3.0, 4.0, 5.0]
l2 = [3.0, 2.0, 1.0, 4.0, 3.0]
v1 = np.array(l1)
v2 = np.array(l2)

# %%
np.add(v1, v2)

# %%
np.add(l1, l2)

# %%
np.add(l1, v2)

# %%
np.add(l1, 2)

# %%
np.multiply(l1, l2)

# %%
np.power(l1, v2)

# %%
np.sin(l1)
