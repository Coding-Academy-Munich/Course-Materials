# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Creating Numpy Arrays</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Creating Numpy Arrays.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Creating Numpy Arrays

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Creating arrays from lists


# %% tags=["keep"]
import numpy as np

# %%
vec = np.array([1, 2, 3, 4])

# %%
vec

# %%
vec.shape

# %% tags=["keep"]
mat = np.array([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]])

# %%
mat

# %%
mat.shape

# %% tags=["keep"]
tensor = np.array(
    [
        [[1, 2, 3, 5], [2, 3, 4, 5], [3, 4, 5, 6]],
        [[4, 5, 6, 7], [5, 6, 7, 8], [6, 7, 8, 9]],
    ]
)

# %%
tensor

# %%
tensor.shape

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Ranges and linear spaces

# %% tags=["keep"]
list(range(10))

# %%
np.array(range(10))

# %%
np.arange(10)

# %%
np.arange(10.0)

# %%
np.arange(0.0, 2.5, 0.5)

# %% [markdown] lang="en"
#
# 10 values, evenly distributed between 0.0 and 1.0:

# %%
np.arange(0.0, 1.1, 1 / 9)

# %%
np.linspace(0.0, 1.0, 10)

# %%
np.linspace(0.0, 1.0, 11)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Fixed Values

# %%
zs = np.zeros(3)
zs

# %%
zs.shape

# %%
np.zeros((3,))

# %%
np.zeros((2, 3))

# %%
np.zeros((2, 3, 4))

# %%
np.ones((2, 3))

# %%
np.empty((2, 4))

# %%
np.eye(3)

# %%
np.identity(3)

# %%
np.eye(2, 3)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Creating Arrays
#
# Create the following NumPy arrays:

# %% [markdown]
# ```python
# array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
# ```

# %%
np.arange(10)

# %% [markdown]
# ```python
# array([1. , 1.5, 2. , 2.5, 3. , 3.5, 4. , 4.5])
# ```

# %%
np.arange(1.0, 5.0, 0.5)

# %% [markdown]
# ```python
# array([0.  , 1.25, 2.5 , 3.75, 5.  ])
# ```

# %%
np.linspace(0, 5, 5)


# %% [markdown]
# ```python
# array([[[0., 0.],
#         [0., 0.]],
#
#        [[0., 0.],
#         [0., 0.]],
#
#        [[0., 0.],
#         [0., 0.]]])
# ```

# %%
np.zeros((3, 2, 2))
