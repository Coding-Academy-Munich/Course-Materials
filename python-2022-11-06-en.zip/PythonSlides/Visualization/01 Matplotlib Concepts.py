# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Matplotlib Concepts</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Matplotlib Concepts.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# Matplotlib concepts
#
# Matplotlib has two different interaction styles:
#
# - Automatic management of figures with pyplot
# - Object-oriented interface

# %% tags=["keep"]
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

# %% tags=["keep"]
xs = np.linspace(0.0, 10.0, 200)
ys1 = np.sin(xs)
ys2 = np.cos(xs / 2.0) * np.sin(xs * 1.5)

# %%
plt.figure(figsize=(8, 4))
plt.plot(xs, ys1, label="sin(x)")
plt.plot(xs, ys2, label="cos(x/2) $\cdot$ sin(1.5x)")
plt.xlabel("x axis")
plt.ylabel("y axis")
plt.title("PyPlot Plot")
plt.legend()
plt.show()

# %%
fig, ax = plt.subplots(figsize=(8, 4))
ax.plot(xs, ys1, label="sin(x)")
ax.plot(xs, ys2, label="cos(x/2) $\cdot$ sin(1.5x)")
ax.set_xlabel("x axis")
ax.set_ylabel("y axis")
ax.set_title("Object Oriented Plot")
ax.legend()
plt.show()

# %%
fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(16, 4))
fig.tight_layout()
ax1.plot(xs, ys1, label="sin(x)")
ax1.plot(xs, ys2, label="cos(x/2) $\cdot$ sin(1.5x)")
ax1.set_title("First plot")
ax1.legend()
ax2.plot(xs, xs, label="$x$")
ax2.plot(xs, xs**2, label="$x^2$")
ax2.set_title("Second plot")
ax2.legend()
plt.show()

# %% [markdown]
#
# <img src="img/numpy-anatomy.webp"
#      style="display:block;margin:auto;width:50%"/>
#
# [Image source](https://matplotlib.org/stable/tutorials/introductory/usage.html)

# %%
