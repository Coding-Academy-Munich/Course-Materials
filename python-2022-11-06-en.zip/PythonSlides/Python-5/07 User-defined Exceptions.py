# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>User-defined Exceptions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">07 User-defined Exceptions.py</div> -->
#
#

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Custom exception classes
#
# - It is possible to define own exception classes.
# - To do this, it is sufficient to inherit from `Exception` or a subclass
#   of `Exception`.


# %%
class MyValueError(ValueError):
    pass


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Handling subclasses of an exception
#
# - An `except` clause for a class `A` also handles all subclasses of `A`

# %% tags=["keep"]
print("Before try")
try:
    print("Before raise")
    # raise ValueError("ValueError")
    raise MyValueError("MyValueError")
    print("After raise")  # noqa
except ValueError as error:
    print(f"Caught: {error}")
print("After except")
