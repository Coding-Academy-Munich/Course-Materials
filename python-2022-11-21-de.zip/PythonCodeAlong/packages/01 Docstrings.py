# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Docstrings</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Docstrings.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_240_a3_docstrings.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Docstrings
#
# Jede Funktion in Python kann dokumentiert werden, indem ein String-Literal als
# erstes Element im Rumpf angegeben wird. Meistens wird dafür ein `"""`-String
# verwendet:

# %% tags=["keep"]
def my_fun(x):
    """
    Zeigt dem Benutzer den Wert von x an

    Verwendung:
    >>> my_fun(123)
    """
    print("Das Argument x hat den Wert", x)

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Konventionen für Docstrings finden sich in
# [PEP 257](https://www.python.org/dev/peps/pep-0257/).

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Der Docstring einer Funktion kann mit `help()` ausgegeben werden:

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# In Jupyter kann man den Docstring einer Funktion durch ein vorangestelltes
# oder nachgestelltes Fragezeichen anzeigen lassen:

# %%


# %%


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Oft verwendet man statt dessen Shift-Tab:

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Bei Funktionen mit langen Docstrings kann man durch zweimaliges Drücken von `Shift-Tab` auf die ausführliche Anzeigeform umschalten:

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Signatur
#
# Die Anzahl, Namen, Default-Werte (und evtl. Typen) einer Funktion sowie ihren Rückgabetyp nennt man
# ihre *Signatur*.
#
# Jupyter zeigt u.a. die Signatur einer Funktion an, wenn man `Shift-Tab`
# eingibt:

# %% tags=["keep"]
def say_hi(greeting, name="world", end="."):
    print(greeting + " " + name + end)


# %%

# %% tags=["keep"]
def add_ints(m: int, n: int) -> int:
    return m + n

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Typen können auch mit Default-Werten kombiniert werden:

# %%

# %%
