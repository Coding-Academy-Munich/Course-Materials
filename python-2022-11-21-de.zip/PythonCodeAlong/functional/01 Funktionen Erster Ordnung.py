# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Funktionen Erster Ordnung</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Funktionen Erster Ordnung.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_260_c3_first_order_functions.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Funktionen
#
# In Python sind Funktionen Objekte erster Ordnung, d.h., sie können von
# Variablen referenziert, als Argumente an Funktionen übergeben werden, etc.
#
# Funktionen haben den Typ `Callable`.

# %%

# %%

# %%

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop "Filtern von Elementen"
#
# Schreiben Sie eine Funktion
# `return_truthy_elements(a_list: list, fun: Callable) -> list`,
# die eine Liste mit allen Elementen `x` von `a_list` zurückgibt, für die
# `fun(x)` einen wahren Wert liefert.


# %% tags=["keep"]
example_values = [1, 2, 3, 9, 10]


# %% tags=["keep"]
def greater_than_2(n):
    return n > 2


# %% tags=["keep"]
def less_than_10(n):
    return n < 10


# %% tags=["keep"]
from typing import Callable

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# # Konstruktor-Funktionen und Methoden

# %%

# %%

# %%

# %%

# %%

# %%

# %%


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop "Filtern von Elementen"
#
# Schreiben Sie eine Funktion `my_max(values: list, key: Callable)`, die das Element
# aus `values` zurückgibt, für das `key(value)` den größten Wert zurückgibt. Falls
# mehrere Elemente mit gleichem Wert existieren soll das erste davon zurückgegeben
# werden. Werfen Sie eine `ValueError()` wenn `list` leer ist.
#
# (Verwenden Sie zur Implementierung nicht die Funktion `max()`.)


# %%

# %% tags=["keep"]
from operator import neg

int_values = [1, 2, 5, 2, 4]
string_values = ["foo", "bar", "quux", "x"]

# %% tags=["keep"]
assert my_max(int_values, lambda x: x) == 5

# %% tags=["keep"]
assert my_max(int_values, neg) == 5

# %% tags=["keep"]
assert my_max(string_values, len) == "quux"

# %% tags=["keep"]
assert my_max(string_values, lambda x: x) == "x"

# %%
