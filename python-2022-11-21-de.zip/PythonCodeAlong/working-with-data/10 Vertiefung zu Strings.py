# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Vertiefung zu Strings</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">10 Vertiefung zu Strings.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_120_data_types/topic_230_a3_more_strings.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# # Vergleich von Strings

# %% tags=["keep"]
"a" == "a"

# %% tags=["keep"]
"A" == "a"

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
"A" < "B"

# %% tags=["keep"]
"A" < "a"

# %% tags=["keep"]
"a" < "A"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Strings sind wie im Wörterbuch (lexikographisch) geordnet

# %% tags=["keep"]
"ab" < "abc"

# %% tags=["keep"]
"ab" < "ac"

# %% tags=["keep"]
"ab" != "ac"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Einschub: Sortieren von Listen/Iterables
#
# Mit der Funktion `sorted()` können iterables sortiert werden. Mit dem
# benannten Argument `key` kann eine Funktion angegeben werden, die bestimmt,
# wie die Sortierung erfolgt:

# %% tags=["keep"]
numbers = [3, 8, -7, 1, 0, 2, -3, 3]

# %%

# %%

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
strings = ["a", "ABC", "xy", "Asdfgh", "foo", "bar", "quux"]

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Vergleich von Unicode Strings
#
# Die eingebauten Vergleichsfunktionen sind nur für einfache (ASCII) Strings
# sinnvoll. Für Strings, die Unicode-Zeichen enthalten ist Sortieren/Vergleichen
# schwieriger.
#
# Das Standard Modul in Python ist `locale`; das auf die Locale-Settings des
# Betriebssystems zurückgreift:

# %%

# %% tags=["keep"]
my_strings = ["o", "oa", "oe", "ö", "oz", "sa", "s", "ß", "ss", "sz"]

# %%

# %%

# %% tags=["keep"]
locale.setlocale(locale.LC_COLLATE, "de_DE.UTF-8")

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Die Locale Settings sind global pro Prozess und deshalb hauptsächlich geeignet
# um mit dem Benutzer zu interagieren.
#
# Wenn man mit Strings in verschiedenen Sprachen umgehen muss empfiehlt sich die
# Verwendung von Bibliotheken wie `PyUCA` (in Python geschrieben und daher
# leichter zu installieren) oder `PyICU` (vollständigere Implementierung der
# Unicode Spezifikation, basierend auf einer C++ Bibliothek).


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# # Nochmal String Literale
#
# - String-Literale werden in einfache oder doppelte Anführungszeichen
#   eingeschlossen
#     - `"Hello, world!"`
#     - `'Hallo Welt!'`
#     - Welche Form man wählt, spielt keine Rolle, außer man will
#       Anführungszeichen im String haben
#     - `"Er sagt 'Huh?'"`
#     - `'Sie antwortet: "Genau."'`

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - String-Literale, können Unicode Zeichen enthalten:
#     - `"おはようございます"`
#     - `"😠🙃🙄"`

# %% tags=["keep"]
print("Er sagt 'Huh?'")
print('Sie antwortet: "Genau."')
print("おはようございます")
print("😠🙃🙄")

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - Sonderzeichen können mit *Escape-Notation* angegeben werden:
#     - `\n`, `\t`, `\\`, `\"`, `\'`, ...
#     - `\u`, `\U` für Unicode code points (16 bzw. 32 bit)
#     - `\N{...}` für Unicode

# %% tags=["keep"]
print("a\tbc\td\n123\t4\t5")

# %% tags=["keep"]
print('"Let\'s go crazy", she said')

# %% tags=["keep"]
print("C:\\Users\\John")

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
print("\u0394 \u03b1 \t\U000003b2 \U000003b3")
print("\U0001F62E \U0001f61a \U0001f630")

# %% tags=["keep"]
print("\N{GREEK CAPITAL LETTER DELTA} \N{GREEK SMALL LETTER ALPHA}")
print("\N{smiling face with open mouth and smiling eyes} \N{winking face}")

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - String Literale können auch in 3-fache Anführungszeichen eingeschlossen
#   werden
# - Diese Art von Literalen kann über mehrere Zeilen gehen

# %% tags=["keep"]
"""Das ist
ein String-Literal,
das über mehrere
Zeilen geht."""

# %% tags=["keep"]
print(
    """Mit Backslash am Ende der Zeile \
kann der Zeilenvorschub unterdrückt werden."""
)

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Konkatenation von Strings
#
# Mit `+` können Strings aneinandergehängt (konkateniert) werden:

# %% tags=["keep"]
"Ein" + " " + "String"
# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Nochmal Vergleich von Strings
#
# Um Strings mit Unicode-Zeichen zu vergleichen ist es zweckmäßig sie in
# Unicode-Normalform zu bringen.

# %% tags=["keep"]
s1 = "café"
s2 = "cafe\u0301"

# %%

# %% tags=["keep"]
import unicodedata

unicodedata.normalize("NFC", s1) == s1

# %%

# %%


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Finden in Strings
#
# Der `in` Operator funktioniert auch mit Strings als Argument. Um den Index
# eines Substrings in einem String zu finden kann man die `index()`-Methode
# verwenden.

# %%

# %%

# %%

# %%

# %%

# %%

# %%
