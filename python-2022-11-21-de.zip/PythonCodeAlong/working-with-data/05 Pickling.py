# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Pickling</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Pickling.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_310_working_with_data/topic_120_a3_pickling.py</div> -->

# %% [markdown] lang="de"
#
# ## Pickles
#
# Das `pickle` Modul bietet die Möglichkeit, Python Objekte einfach zu speichern
# und zu laden.

# %%

# %%


# %%


# %%

# %%

# %%

# %%

# %% tags=["keep"]
my_dict is restored_pickle

# %% tags=["keep"]
my_list.append(my_other_list)
my_other_list.append(my_list)

# %% tags=["keep"]
pprint(my_list)


# %% tags=["keep"]
pprint(my_dict)

# %% tags=["keep"]
my_pickle = pickle.dumps(my_dict)
restored_pickle = pickle.loads(my_pickle)

# %% tags=["keep"]
pprint(restored_pickle)

# %% tags=["keep"]
# Don't try this...
# my_dict == restored_pickle
