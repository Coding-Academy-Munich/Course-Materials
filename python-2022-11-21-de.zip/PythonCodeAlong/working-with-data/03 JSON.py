# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>JSON</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 JSON.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_310_working_with_data/topic_220_a4_json.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # JSON
#
# Python bietet ein eingebautes Paket `json` an, mit dem JSON-Daten in
# Python-Datenstrukturen übersetzt werden können.

# %% tags=["keep"]
import json
import os
from dataclasses import dataclass
from pprint import pprint
from tempfile import NamedTemporaryFile

# %% tags=["keep"]
json_data = """\
{"menu": {
  "id": "file",
  "value": "File",
  "menuitems": [
      {"value": "New", "onclick": "CreateNewDoc()"},
      {"value": "Open", "onclick": "OpenDoc()"},
      {"value": "Close", "onclick": "CloseDoc()"}
  ]
}}
"""


# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% tags=["keep"]
@dataclass
class Menu:
    id: str
    value: str
    items: list["MenuItem"]

    @staticmethod
    def from_dict(d):
        return Menu(
            d["id"], d["value"], [MenuItem.from_dict(m) for m in d["menuitems"]]
        )


# %% tags=["keep"]
@dataclass
class MenuItem:
    value: str
    onclick: str

    @staticmethod
    def from_dict(d):
        return MenuItem(d["value"], d["onclick"])

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
