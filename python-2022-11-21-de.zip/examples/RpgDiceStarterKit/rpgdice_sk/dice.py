class Dice:
    pass