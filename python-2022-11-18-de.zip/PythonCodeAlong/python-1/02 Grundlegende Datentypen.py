# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Grundlegende Datentypen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Grundlegende Datentypen.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_120_data_types/topic_110_c3_basic_data_types.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Variablen und Datentypen
#
# Zahlen und Arithmetik:

# %%

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Zeichenketten

# %%

# %% lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% lang="de"

# %% lang="de"

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Anzeige von Werten mit der `print()` Funktion
#
# Um mehrere Werte anzuzeigen kann man die `print()`-Funktion verwenden:
#
# `print(...)` gibt den in Klammern eingeschlossenen Text auf dem Bildschirm
# aus.

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Variablen

# %%

# %%

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Variablen
#
# <img src="img/variables-01.svg" style="float:right;margin:auto;width:50%"/>
#
# Eine *Variable* ist
# - ein <span style="color:red;">"Verweis"</span> auf ein "Objekt"
# - der einen <span style="color:red;">Namen</span> hat.
#
# <span style="color:blue;">Ein Objekt</span> kann von
# <span style="color:blue;">mehreren Variablen</span><br/>
# referenziert werden!

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Typen

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Vordefinierte Funktionen

# %%

# %%

# %%

# %%

# %%

# %% tags=["keep"]
print(round(0.5), round(1.5), round(2.5), round(3.5))


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mini-Workshop: Vordefinierte Funktionen
#
# In diesem Workshop sollen Sie einige Aufgaben mit vordefinierten Funktionen lösen.
# Manche der Funktionen wurden noch nicht besprochen. Verwenden Sie die [Tabelle der
# vordefinierten
# Funktionen](https://docs.python.org/3/library/functions.html#built-in-functions)
# um geeignete Kandidaten zu finden.

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Wandeln Sie die Zahl `1.5` in einen String um.

# %%

# %% [markdown] lang="de"
#
# Bestimmen Sie das Maximum der Zahlen 2.5 und 1.7 mit einer eingebauten Funktion.

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Wandeln Sie den String "1.234" in eine Gleitkommazahl um und addieren Sie `2.345`
# dazu.

# %%
