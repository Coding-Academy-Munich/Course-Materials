# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Boolesche Operatoren</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Boolesche Operatoren.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_140_control_flow/topic_112_b1_boolean_operators.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Operatoren auf Booleschen Werten
#

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Wann ist ein logischer Ausdruck wahr?
#
# | Operator | Operation                      | `True` wenn...                 |
# |:--------:|:-------------------------------|:-------------------------------|
# | and      | logisches "Und" (Konjunktion)  | beide Argumente `True`         |
# | or       | logisches "Oder" (Disjunktion) | mindestens ein Argument `True` |
# | not      | logisches "Nicht" (Negation)   | Argument `False`               |

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Verkettung von Vergleichen

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Mini-Workshop: Operatoren, Vergleiche
#
# Gegeben die folgenden Variablendefinitionen:

# %% tags=["keep"]
var1 = 3 ** (3 * 4)
var2 = 4**3**2
var3 = (3**3) ** 3
var4 = (2**3) ** 4

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Ist `var1` durch `var3` teilbar und gleichzeitig `var2` durch `var4` teilbar?

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Sind die Variablen `var1`, `var2`, `var3` und `var4` aufsteigend angeordnet,
# gilt also `var1` < `var2` und `var2` < `var3` und `var3` < `var4`?

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Sind die Variablen `var1`, `var2`, `var3` und `var4` absteigend angeordnet,
# gilt also `var1` > `var2` und `var2` > `var3` und `var3` > `var4`?

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Ist der Wert von `var1` zwischen `1_000` und `10_000`?

# %%
