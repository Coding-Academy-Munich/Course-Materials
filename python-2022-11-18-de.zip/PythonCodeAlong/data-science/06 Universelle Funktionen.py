# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Universelle Funktionen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Universelle Funktionen.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_600_numpy/topic_160_a5_np_universal_functions.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Universelle Funktionen
#
# [Universelle Funktionen](https://numpy.org/doc/stable/reference/ufuncs.html)
# sind Funktionen, die sowohl auf Numpy-Arrays als auch auf
# anderen Datentypen wie Listen oder Skalaren ausgeführt werden können und die
# elementweise auf ihren Argumenten operieren.

# %% tags=["keep"]
import numpy as np

# %% tags=["keep"]
l1 = [1.0, 2.0, 3.0, 4.0, 5.0]
l2 = [3.0, 2.0, 1.0, 4.0, 3.0]
v1 = np.array(l1)
v2 = np.array(l2)

# %%

# %%

# %%

# %%

# %%

# %%

# %%
