# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>NumPy Basics</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 NumPy Basics.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_600_numpy/topic_120_a5_np_basics.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Grundkonzepte von NumPy

# %% tags=["keep"]
import numpy as np

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Vektoren

# %% tags=["keep"]
v1 = np.array([3.0, 2.1, 4.2])
v2 = np.array([8.0, 8.9, 6.8])

# %%

# %%

# %%

# %%

# %% tags=["keep"]
v3 = np.array([1, 2, 3])

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Rechnen mit Vektoren
#
# ### Grundlegende Operationen

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Maximum und Minimum

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Aggregatfunktionen und Statistik

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Matrizen

# %% tags=["keep"]
m1 = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
m1

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Form von Matrizen und Transposition

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Indizieren von Matrizen

# %% tags=["keep"]
m1 = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
m1

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Rechnen mit Matrizen

# %% tags=["keep"]
m1 = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
m1

# %% tags=["keep"]
m2 = np.array([[1.0, 0.0], [0.0, 1.0], [2.0, 3.0]])
m2

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
