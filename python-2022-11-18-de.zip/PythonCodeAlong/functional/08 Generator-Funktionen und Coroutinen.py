# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Generator-Funktionen und Coroutinen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Generator-Funktionen und Coroutinen.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_370_e4_generator_functions.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Generator Funktionen
#
# Komplexere Fälle können von Generator Expressions nicht mehr abgedeckt werden.
#
# - Generator, der alle Zahlen erzeugt (ohne Obergrenze)
# - Generator, der ein Iterable modifiziert (z.B. mehrfach ausführt, eine fixe Anzahl
#   an Elementen nimmt)
#
# Für diese Fälle gibt es Generator-Funktionen

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Mit dem Schlüsselwort `yield` kann eine Funktion "mehrere Werte zurückgeben".
# Eine Funktion, die `yield` in ihrem Rumpf verwendet, wird Generatorfunktion
# genannt. Ein Aufruf einer Generatorfunktion wertet nicht den Rumpf der
# Funktion aus, sondern es wird ein *Generator* zurückgegeben, der mehrmals
# einen Wert zurückgeben kann:

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop
#
# Schreiben Sie eine Generatorfunktion `one_based_range(n)`, die `range(n)` für
# ein Argument simuliert, aber von 1 bis einschließlich `n` iteriert.

# %%

# %% tags=["keep"]
assert list(one_based_range(4)) == [1, 2, 3, 4]


# %% [markdown] lang="de"
#
# Schreiben Sie eine Generatorfunktion `inklusive_range()`, die die komplette
# Funktionalität von `range()` simuliert (d.h. die mit einem, zwei oder drei
# Argumenten aufgerufen werden kann), aber ihre obere Grenze einschließt und die
# Iteration von 1 beginnt, wenn keine untere Grenze angegeben wird.
#
# Stellen Sie sicher, dass Ihre Implementierung die vorgegebenen Testfälle
# erfüllt.

# %%

# %%

# %%

# %%

# %%

# %% tags=["keep"]
assert list(inclusive_range(3)) == [1, 2, 3]

# %% tags=["keep"]
assert list(inclusive_range(2, 4)) == [2, 3, 4]

# %% tags=["keep"]
assert list(inclusive_range(2, 2)) == [2]

# %% tags=["keep"]
assert list(inclusive_range(2, 1)) == []

# %% tags=["keep"]
assert list(inclusive_range(2, 6, 2)) == [2, 4, 6]

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Wir können Generatorfunktionen verwenden, um Funktionen zu schreiben, die
# Iteratoren verarbeiten. Beispielsweise nimmt die Generatorfunktion `take()`
# eine feste Anzahl von Werten von einem Iterator:

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Beachten Sie, dass die Funktion `drop()`, die die ersten `n` Elemente eines
# Iterators entfernt, keine Generatorfunktion, sondern eine reguläre Funktion
# ist:

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Mit Generatorfunktionen können wir auch komplexere Iterations-Operationen
# definieren:

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop "Generator"
#
# Schreiben Sie einen Generator `leaves(tree: Bintree)`, der alle Blätter eines
# Binärbaums zurückgibt (d.h., alle Knoten, die nicht Instanzen von `Bintree` sind).


# %% tags=["keep"]

from dataclasses import dataclass
from typing import Optional


# %% tags=["keep"]
@dataclass
class Bintree:
    value: object = None
    left: Optional["Bintree"] = None
    right: Optional["Bintree"] = None


# %%

# %% tags=["keep"]
tree1 = Bintree(1)
tree2 = Bintree(2, Bintree(1), Bintree(3))
tree3 = Bintree(
    1, Bintree(0), Bintree(3, Bintree(2), Bintree(5, Bintree(4), Bintree(6)))
)

# %% tags=["keep"]
assert tuple(leaves(tree1)) == (1,)

# %% tags=["keep"]
assert tuple(leaves(tree2)) == (1, 2, 3)

# %% tags=["keep"]
assert tuple(leaves(tree3)) == tuple(range(7))


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Coroutinen
#
# `yield` kann auch verwendet werden, um einen Wert an die Stelle zurückzugeben,
# an der es "aufgerufen" wird. In diesem Fall nennen wir den Generator auch eine
# *Coroutine*.
#
# Coroutinen sind nützliche Bausteine für Features wie z.B. kooperatives
# Multitasking oder Event-basierte Programmierung.
#
# Um eine Coroutine `c` zu starten, rufen wir die Methode `c.send(None)` auf.
# Zum Senden nachfolgender Werte verwenden wir `c.send(value)`.
#


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %%


# %%


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
