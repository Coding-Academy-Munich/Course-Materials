# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Häufig Verwendete Funktionen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Häufig Verwendete Funktionen.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_340_d4_functional_programming.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Häufig Verwendete Funktionen


# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop "Erlaubte Gruppen"
#
# Zu einer Veranstaltung sollen nur Gruppen zugelassen werden, wenn
# - entweder alle Teilnehmer mindestens 18 Jahre alt sind
# - oder mindestens ein Lehrer in der Gruppe ist
#
# Implementieren Sie eine Funktion `is_valid_group(group: list[Person])`,
# die das überprüft.


# %% tags=["keep"]
from dataclasses import dataclass


# %% tags=["keep"]
@dataclass
class Person:
    age: int
    profession: str = "unknown"


# %% tags=["keep"]
group1 = [Person(23), Person(42), Person(84, "doctor"), Person(29)]
group2 = [Person(12), Person(13), Person(53, "teacher"), Person(11)]
group3 = [Person(12), Person(32)]

# %%

# %% tags=["keep"]
assert is_valid_group(group1)

# %% tags=["keep"]
assert is_valid_group(group2)

# %% tags=["keep"]
assert not is_valid_group(group3)

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop "Sitzordnungen"
#
# Wie viele Möglichkeiten gibt es, bei einer Veranstaltung mit 4 Teilnehmern, die
# Teilnehmer auf die Plätze zu verteilen, wenn es 5 nummerierte Plätze gibt?
#
# Skaliert Ihre Implementierung für größere Veranstaltungen?

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
