# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>XML</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 XML.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_310_working_with_data/topic_230_a4_xml.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Das XML Package
#
# Siehe [Python Dokumentation](https://docs.python.org/3/library/xml.etree.elementtree.html#module-xml.etree.ElementTree)

# %%

# %%

# %%

# %%

# %% tags=["keep"]
os.remove(xml_file.name)

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## LXML
#
# [LXML](https://lxml.de/index.html) ist eine Alternative mit (möglicherweise) höherer Performanz.

# %% tags=["keep"]
