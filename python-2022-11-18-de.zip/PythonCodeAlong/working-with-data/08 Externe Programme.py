# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Externe Programme</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Externe Programme.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_370_scripting/topic_110_external_programs.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Sub-Prozesse
#
# *Hinweis:* Zur Ausführung dieses Notebooks müssen muss das `ext_sample_app`
# Package (in `Examples/ExternalSampleApplication`) installiert sein.
#
# `subprocess.run` ist die bevorzugte Methode um externe Applikationen zu starten.

# %%

# %%

# %% [markdown] lang="de"
# Mit `shutil.which()` kann man den vollständigen Pfad eines Programms herausfinden.

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
#
# Mit `sys.executable` kann man den Pfad des gerade aktiven Python Interpreters
# herausfinden. Das ist die bevorzugte Methode um einen Python Prozess zu
# starten.

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Popen: Nebenläufige Ausführung von Programmen
#
# Wenn man nicht warten kann, bis das gestartete Programm beendet wird muss man
# die `subprocess.Popen` Klasse verwenden:

# %%

# %%

# %%

# %% [markdown] lang="de"
#
# `proc.communicate()` sendet eine Nachricht and `proc`, schließt die Ein- und
# Ausgabeströme und beendet den Prozess.

# %%

# %% [markdown] lang="de"
#
# Mit `proc.poll()` kann man feststellen, ob der Prozess schon beendet wurde und
# was der Rückgabewert war. Falls das Ergebnis `None` ist, ist der Prozess noch
# aktiv. `proc.wait()` wartet eine bestimmte Zeit und gibt den Rückgabewert des
# Prozesses zurück. Falls der Prozess nicht in der vorgegebenen Zeit beendet
# wurde, wird eine `TimeoutExpired` Exception ausgelöst.

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Kommunikation mit Sockets
#
# Das folgende Beispiel zeigt, wie man einen Prozess starten und dann über
# Sockets mit ihm kommunizieren kann.

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
