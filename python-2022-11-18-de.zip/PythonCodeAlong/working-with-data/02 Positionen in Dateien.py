# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Positionen in Dateien</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Positionen in Dateien.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_310_working_with_data/topic_116_a2_positions_in_files.py</div> -->

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# # Positionen in Dateien
#
#  - Mit den Methoden `tell()` und `seek()` kann die Position in der Datei
#    abgefragt oder verändert werden.

# %% tags=["keep"]
line = "0123456789A123456789B123456789C123456789\n"
text = line * 2

# %%

# %%

# %%

# %%

# %%
