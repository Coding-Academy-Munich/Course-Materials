# Simple Packaging

This is a simple Python package to demonstrate, well, packaging.

It is based on
[the packaging tutorial](https://packaging.python.org/en/latest/tutorials/packaging-projects/).
