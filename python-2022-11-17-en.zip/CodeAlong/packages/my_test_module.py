def add1(n):
    """ "Adds 1 to n."""
    return n + 1


def multiply_by_2(n):
    """ "Multiplies n by 2."""
    return n * 2


def perform_complex_computation(n):
    """ "Performs a very complex computation involving n."""
    return 2 * n + 1


print("File my_test_module.py is executing!")
print(f"Module name is '{__name__}'")
