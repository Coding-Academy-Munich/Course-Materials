from ..dice import Dice

def test_dice():
    dice = Dice()
    assert dice is not None