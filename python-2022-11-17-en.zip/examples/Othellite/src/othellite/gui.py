"""
A graphical user interface for the Othellite game.

## Classes

None, so far.

## Hexagonal Architecture

This is one of the outer layers. It may depend on everything in `core` and the
middle layers, but nothing should depend on this module.
"""


def main():
    print("Hello world from Othellite (future gui version).")


if __name__ == "__main__":
    main()
