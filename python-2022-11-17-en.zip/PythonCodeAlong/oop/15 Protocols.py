# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Protocols</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">15 Protocols.py</div> -->
#
#

# %% [markdown] lang="en"
# # Protocols
#
# With protocols Python supports structural subtyping, i.e., the derivation of
# subtype relationships from the structure of classes (in contrast to nominal subtyping
# where the relationships have to be decalared via inheritance).

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Mini workshop
#
#  - Notebook `workshop_190_inheritance`
#  - Section "Protocols"
