# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Object Identity</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">07 Object Identity.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Objects identity

# %% tags=["keep"]
a = [1, 2, 3]
b = [1, 2, 3]
c = b

# %% tags=["keep"]
print(f"a = {a}, b = {b}, c = {c}")

# %% tags=["keep"]
a[0] = 10

# %% tags=["keep"]
print(f"a = {a}, b = {b}, c = {c}")

# %% tags=["keep"]
b[0] = 20

# %% tags=["keep"]
c[1] = 30

# %% tags=["keep"]
print(f"a = {a}, b = {b}, c = {c}")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
#  <img src="img/identity.svg" style="display:block;width:70%;margin:auto;"/>

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Testing object identity

# %% tags=["keep"]
a = [1, 2, 3]
b = [1, 2, 3]
c = b


# %% [markdown] lang="en"
# `==` tests equality of values, not (necessarily) object identity.

# %% tags=["keep"]
a == b

# %% tags=["keep"]
b == c

# %% tags=["keep"]
a[0] = 10
a == b

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# You can use `is` to test object identity:

# %% tags=["keep"]
a = [1, 2, 3]
b = [1, 2, 3]
c = b


# %% tags=["keep"]
a is b

# %% tags=["keep"]
b is c

# %% tags=["keep"]
b[0] = 10

# %% tags=["keep"]
print(f"a = {a}, b = {b}, c = {c}")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# The `id()` function returns the address of an object:

# %% tags=["keep"]
id([1, 2, 3])

# %% [markdown] lang="en"
# Addresses are usually represented in hexadecimal form:

# %% tags=["keep"]
hex(id([1, 2, 3]))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Identity
#
# Given the following lists:

# %% tags=["keep"]
a = [1, 2, 3]
b = [1, 2]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
#
# - Are `a` and `b` lists that have the same elements?
# - Are `a` and `b` the same list?
# - At what address is `b` located?

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Now evaluate the following cell:

# %% tags=["keep"]
b.append(3)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Are `a` and `b` now lists that have the same elements?
# - At what address is `b` located now?


# %%

# %%

# %%
