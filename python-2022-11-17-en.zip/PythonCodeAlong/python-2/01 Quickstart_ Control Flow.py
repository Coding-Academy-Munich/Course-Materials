# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Quickstart: Control Flow</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Quickstart_ Control Flow.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Boolean values and `if` statements

# %% tags=["keep"]
def check(value):
    if value:
        print(f"{value} is true.")
    else:
        print(f"{value} is false.")

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### `if`/`elif`/`else`

# %%


# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Truthiness
#
# The `if` statement can take any Python value as an argument,
# not just Boolean values.
#
# The following values are considered *not true*
#
# - `None` and `False`
# - `0` and `0.0` (and null values of other number types)
# - Empty strings, sequences and collections: ``
# - Some values of user-defined data types
#
# All other values are considered true.


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def check(value):
    if value:
        print(f"{value!r} is truthy.")
    else:
        print(f"{value!r} is falsy.")


# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## How is this used?

# %%

# %%

# %%
# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Mini workshop
#
# Write a function `fits_in_line(text: str, line_length: int = 72)`,
# which returns `True` or `False` depending on whether `text` fits into a line of
# length `line_length`:
# ```python
# >>> fits_in_line("Hello")
# True
# >>> fits_in_line("Hello", 3)
# False
# >>>
# ```
#
# Ensure that your function satisfies the provided tests.
#
# Write a function `print_line(text: str, line_length:int = 72)`,
# that
# * prints `text` to the screen if that is possible in a line of length
#   `line_length`
# * prints `...` if that is not possible.
#
# ```python
# >>> print_line("Hello")
# Hello
# >>> print_line("Hello", 3)
# ...
# >>>
# ```

# %%

# %% tags=["keep"]
assert fits_in_line("Hallo")

# %% tags=["keep"]
assert not fits_in_line("Hallo", 3)

# %%

# %% tags=["keep"]
# Hallo
print_line("Hallo")

# %% tags=["keep"]
# ...
print_line("Hallo", 3)

# %%
