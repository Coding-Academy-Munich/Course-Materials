# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>`while`-loops</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">11 while-loops.py</div> -->


# %% [markdown] lang="en" tags=["private"]
#
# Needs user input!


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # While loops
#
#  Sometimes we want to run a part of a program over and over again:
#
#  - Number of guesses until the right number is found
#  - Physics simulation until the result is accurate enough
#  - Processing of user input in interactive programs
#
#  When we don't know the number of iterations upfront, we typically
#  use a while loop to do that.

# %% lang="en"

# %% lang="en" tags=["keep"]
def run_an_experiment(trial_number):
    """Runs an experiment
    Returns True if the experiment was a success, False otherwise.
    """
    print(f"Started trial number {trial_number}...", end="")
    from random import random

    if random() > 0.8:
        print("Success!")
        return True
    else:
        print("Failure.")
        return False


# %% lang="en" tags=["keep"]
experiment_nr = 0

while not run_an_experiment(experiment_nr):
    experiment_nr += 1

print("We have completed a successful experiment.")

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Terminating loops
#
# Sometimes it's easier to determine whether to terminate a loop inside the body
# rather than in the loop condition. With the `break` statement you can
# exit a loop early:

# %% lang="en" tags=["keep"]
i = 1
while i < 10:
    print(i)
    if i % 3 == 0:
        break
    i += 1
print("After the loop:", i)

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Guessing games
#
# The following simple "games" allow the player unlimited number of
# inputs. Therefore, it makes sense to use a while loop
# to implement them.
#
# ### Guess a word
#
# Implement a function `guess_word(solution)` that prompts the user for a word and
# keeps asking until the word typed by the user matches `solution`.

# %% lang="en"

# %% lang="en"

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Number guesses
#
# Implement a function `guess_number(solution)` that asks the user for a number
# and keeps asking until the user has guessed the solution. After every input
# the function should display whether the entered number is too big, too small
# or the correct number.

# %% lang="en"

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# How do you have to modify your solution to allow the player to input
# an empty string to abort the game?

# %%

# %%

# %% lang="en"

# %% lang="en"


# %% lang="en"
