# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Default Arguments</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 Default Arguments.py</div> -->


# %% [markdown] lang="en" tags=["private"]
#
# Note: This requires the lesson on lists!

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Default arguments
#
# Function parameters can have a default value.
# - The default value is given with the syntax `parameter=value`
# - If the corresponding argument is not passed, the default value is used
# - If a parameter has a default value, all values to the right of it must also have one


# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Be careful with variable default arguments

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# Solution: use `Null` as argument, create a new list in each call

# %%

# %%

# %%
