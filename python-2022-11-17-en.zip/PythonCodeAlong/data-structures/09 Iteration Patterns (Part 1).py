# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Iteration Patterns (Part 1)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 Iteration Patterns (Part 1).py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Iteration Patterns
#
# Iteration is often used in a relatively "schematic" way.
# In the following, we consider different "patterns" how iteration is used.

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Aggregation of list items

# %%

# %%

# %% [markdown] lang="en"
# ## Mini-Workshop: Mean value of a list
#
# The mean of a list with $n$ elements $[x_0, \dots, x_{n-1}]$ is
# defined as
#
# $$\frac{x_0 + \dots + x_{n-1}}{n}$$
#
# Write a function `mean(number: list)` that calculates the mean of a list.

# %% lang="en"

# %% [markdown] lang="en"
# Test the function for appropriate arguments.

# %% lang="en"

# %% lang="en"

# %% [markdown] lang="en"
#
# ### Bonus task
#
# The mean of the elements of a list $[x_0, \dots, x_{n-1}]$ can be calculated
# iteratively as follows:
#
# - The mean $m$ of the empty list is (by definition for this solution) 0
# - If we add the $n$-th element $x_n$, then the new mean is calculated as
#
# $$m \leftarrow m + \frac{x_n - m}{n+1}$$
#
# Write a function `iterative_average(numbers: list)` that calculates the mean of a
# list iteratively.


# %% lang="en"

# %% lang="en"

# %% lang="en"

# %% lang="en"

# %% lang="en"
