# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>More about For Loops</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 More about For Loops.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Assignments to multiple variables
#
# We've already seen that you can assign to multiple variables at the same time:

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# This is also possible in `for` loops:

# %% tags=["keep"]
values = [(1, "one"), (2, "two"), (3, "three")]

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Total count and price
#
#
# In the list below we have saved the name, quantity and price per item for a list of
# purchases. Write a function
# `total_count_and_price(items: list[tuple[int, float]]) -> tuple[int, float]`
# that calculates the total number of items purchased and the total price:
#
# ```python
# >>> count_and_total([(3, 2.0 ), (5, 1.0)])
# (8, 11.0)
# ```

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% lang="en" tags=["keep"]
items = [(3, 2.0), (5, 1.0)]

# %% lang="en"
