# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Iteration over Dictionaries</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Iteration over Dictionaries.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Iteration over keys

# %% tags=["keep"]
translations = {"snake": "Schlange", "bat": "Fledermaus", "horse": "Pferd"}

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Iteration over values


# %% tags=["keep"]
translations = {"snake": "Schlange", "bat": "Fledermaus", "horse": "Pferd"}

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Iteration over key-value pairs


# %% tags=["keep"]
translations = {"snake": "Schlange", "bat": "Fledermaus", "horse": "Pferd"}

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Printing inventory
#
# We are writing the software for a high-bay warehouse in which the inventory is
# managed in a dictionary.
#
# The keys in the dictionary are the locations in the warehouse, the values are the
# products stored in these locations.
#
# Write the following functions:
#
# - `print_inventory(warehouse)` that prints out all products in the warehouse
# - `print_locations(warehouse)` that prints out all locations in the warehouse
# - `print_assignments(warehouse)` that prints a map from product to storage location

# %% [markdown] tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ```python
# >>> my_warehouse = {(0, 0): "plugs", (1, 0): "cables", (0, 1): "circuit boards"}
# ```
#
# ```python
# >>> print_inventory(my_warehouse)
# plugs
# cables
# circuit boards
# ```
#
# ```python
# >>> print_locations(my_warehouse)
# (0, 0)
# (1, 0)
# (0, 1)
# ```
#
# ```python
# >>> print_assignments(my_warehouse)
# plugs          -> (0, 0)
# cables         -> (1, 0)
# circuit boards -> (0, 1)
# ```


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
my_warehouse = {(0, 0): "plugs", (1, 0): "cables", (0, 1): "circuit boards"}

# %%

# %% tags=["keep"]
print_inventory(my_warehouse)

# %%

# %%%% tags=["keep"]
print_locations(my_warehouse)

# %%

# %%%% tags=["keep"]
print_assignments(my_warehouse)
