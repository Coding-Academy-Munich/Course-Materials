# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>The Windows Command Prompt</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 The Windows Command Prompt.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # (Anaconda) PowerShell
#
# - Found in the start menu under `Anaconda3 (64-bit)`
# - Use the Anaconda variant of Powershell
# - Only this version has access to the programs installed by Anaconda

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Running programs
# - The powershell prompt looks like this: `
#    ```powershell
#    (base) PS C:\Users\Test User>
#    ```
# - `(base)` is the current Anaconda Environment.
# - You can start many programs just by typing their name.
#   - `notepad` for a simple text editor
#   - `python` for the Python interpreter

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## The Current Directory
# - The directory displayed in the prompt is called the "current directory" or
#   "working directory".
# - You can also enter the command `pwd` to see the current directory.
# - Use `ls` or `dir` to display the files in the current directory.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Changing the working directory
#
# - You can change the current directory with the `cd` command
# - After `cd` there is a path:
#   - Absolute path: `cd c:\Windows`
#   - Relative path: `cd System` or `cd .\System `
# - You can use the `Tab` key to complete paths
# - `.` stands for the current directory, `..` for the parent directory
# - You can use `/` or `\` to separate path parts
# - Paths with spaces must be enclosed in quotes:
#   - cd 'C:\Users\Test User\'

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Now that we know that the current directory is important, the following question
#   arises quite naturally: "how do we change the current working directory?"
# - We can achieve this with the `cd` command:
# - After `cd` there is a path:
# - This can be an absolute path, which under Windows usually begins with the
#   directory name and a colon.
# - `cd C:\Windows`
# - You can also end the path with a slash, it makes no difference
# - In a corporate environment there are other possible paths, but if you are in
#   this situation then you know the names of the directories you are already using.
# - Or the path can be a relative path. This begins either directly with the name
#   of the subdirectory or with a period and a slash.
# - `cd System`
# - `cd .\Speech`
# - If a path contains spaces, you must enclose it in (single or double) quotes

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Tips for working with paths
# - Complete paths with the `Tab` key
# - Use `~` to change to your home directory
# - Use `..` to change to the parent directory
# - Copy paths from Explorer or Finder


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## That's it
#
# - The command line offers many more features than we've discussed
# - But for what we want to do in this course, we already know enough
