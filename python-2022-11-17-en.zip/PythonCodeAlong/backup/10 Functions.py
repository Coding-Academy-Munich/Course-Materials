# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Functions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">10 Functions.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Functions
#
# We want to start a company for fencing triangular plots of land.
#
# For each property bordered by streets $A$, $B$ and $C$ we calculate:

# %% lang="en" tags=["keep"]
length_a = 10  # Example value
length_b = 40  # Example value
length_c = (length_a**2 + length_b**2) ** 0.5
total_length = length_a + length_b + length_c
print(total_length)

# %% [markdown] lang="en"
# Can we solve this problem a little more elegantly?

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Pythagorean theorem
#
# We always calculate the length of $C$ from $A$ and $B$ according to the theorem of
# Pythagoras: $C = \sqrt{A^2 + B^2}$.
#
# We can express this in Python using a *function*:

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Function definition
# - Keyword `def`
# - Function name
# - Function parameters, in brackets
# - **Colon**
# - Body of the function, *indented 4 spaces*
# - In the body, the parameters can be used like variables
# - Keyword `return`
#     - Exits the function
#     - Determines which value is returned


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Function call
#
# - Function name
# - Arguments of the call, in brackets
# - One argument for each parameter

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Mini workshop
#
# Write a function `greeting(name)` that returns a greeting in the form
# "Hello *name*!", e.g.
# ```python
# >>> greeting("Max")
# 'Hello Max!'
# >>>
# ```
#
# *Note:* you can concatenate strings with the `+` operator:
# ```python
# >>> name = "Max"
# >>> "Hello, " + name
# 'Hello, Max'
# ```

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% lang="en"
