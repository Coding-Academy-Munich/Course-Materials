# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Broadcasting</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Broadcasting.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Broadcasting
#
# Most operations in Numpy can be used with scalars as well:

# %% tags=["keep"]
import numpy as np

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%


# %% [markdown] lang="en"
#
# ### Rules for broadcasting:
#
# When performing an operation on `a` and `b`:
#
# - Axes (shapes) of `a` and `b` are compared from right to left
#
# - If `a` and `b` have the same length for an axis, they are compatible
#
# - If either `a` or `b` has length 1 for an axis, it is conceptually repeated
#   along this axis to fit the other array
#
# - If `a` and `b` have different lengths along an axis and neither has length 1
#   they are incompatible
#
# - The array with lower rank is treated as if it has rank 1 for the missing
#   axes, the missing axes are appended on the left


# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
