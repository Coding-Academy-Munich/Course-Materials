# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Cleaning up with Finally</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Cleaning up with Finally.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Cleaning up with `finally`
#
# - Sometimes it is necessary to execute instructions regardless of whether an
#   exception has been thrown or not
# - e.g. when operating system resources have been requested that need to be released


# %% tags=["subslide", "start"] slideshow={"slide_type": "subslide"}
def process_data_from_file(file_name):
    print(f"Opening file {file_name}")
    print(f"Processing data from {file_name}...")
    if file_name == "bad.data":
        raise ValueError("Bad data! But recoverable.")
    if file_name == "worse.data":
        raise TypeError("Very bad data! Cannot recover.")
    print("Done.")
    print(f"Closing {file_name}.")


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Freeing Resources
#
# Your program contains the following class, which represents a database connection:

# %% tags=["keep"]
class Database:
    def __init__(self):
        self.id = f"db-{id(self) % 100}"
        self.connected = False

    def connect(self):
        print(f"Connecting to database {self.id}.")
        self.connected = True

    def disconnect(self):
        print(f"Disconnecting from database {self.id}.")
        self.connected = False

    def read_data(self):
        if self.connected:
            print(f"Reading data from database {self.id}.")
        else:
            raise RuntimeError("Not connected to database.")


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Your application uses the database in a function `process_data(db: Database)`:

# %% tags=["keep"]
def process_data(db: Database):
    print(f"Processing data with database {db.id}.")
    db.read_data()


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Since database connections occupy a lot of resources in the database used, the
# connection must be released again with `disconnect()` after it has been used.
#
# One of your colleagues tried to solve the problem as follows:

# %% tags=["keep"]
def our_great_app():
    db = Database()
    db.connect()
    process_data(db)
    db.disconnect()


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# After changing the `process_data()` function, it often happens that your program
# does not release the database connection.
#
# - What change may have caused this behavior?
# - Modify `process_data()` accordingly, and test that the database connection is
#   really not released:

# %% tags=["start"]
def process_data(db: Database):  # noqa
    print(f"Processing data with database {db.id}.")
    db.read_data()

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Modify `our_great_app()` to avoid this error.
# - Implement the solution in such a way that they avoid the problem even with
#   future changes.
# - Test that the database connection is now really released.


# %% tags=["start"]
def our_great_app():  # noqa
    db = Database()
    db.connect()
    process_data(db)
    db.disconnect()

# %%
