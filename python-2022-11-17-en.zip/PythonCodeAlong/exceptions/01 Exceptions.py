# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Exceptions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Exceptions.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Exceptions
#
# - Throwing an exception interrupts the execution of the program
# - The chain of function calls is broken off until the exception is handled

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}


# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Unhandled exceptions abort program execution:


# %%

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Exception classes
#
# In Python, there are many predefined classes that signal different types of error:
# - `Exception`: Base class of all exceptions that can be handled
# - `ArithmeticError`: Base class of all errors in arithmetic operations:
#   - OverflowError
#   - Zero Division Error
# - `LookupError`: base class when an invalid index for a data structure
#   has been used
# - `AssertionError`: error class used by `assert`
# - `EOFError`: Error when `input()` unexpectedly reaches the end of a file
# - ...
#
# The list of error classes defined in the standard library is
# [here](https://docs.python.org/3/library/exceptions.html).

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Workshop: Bank accounts
#
# Define a class `BankAccount` with an attribute `balance: float`
# and methods `deposit(amount: float)` and `withdraw(amount: float)`.
#
# *Note: For a more realistic implementation, `decimal.Decimal`
# can be used instead of `float`.*
#
# The class should throw an exception of type `ValueError` in the following cases:
#
# - If a new `BankAccount` with a negative `balance` is created.
# - If `deposit` is called with a negative value.
# - When `withdraw` is called with a negative value if by withdrawing
#   the desired amount the `balance` attribute of the account would become
#   negative.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %% [markdown] lang="en"
#
# Test the functionality of the class for both successful transactions,
# as well as for transactions that throw exceptions.

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
