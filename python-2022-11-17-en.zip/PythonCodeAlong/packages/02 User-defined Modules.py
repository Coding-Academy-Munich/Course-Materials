# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>User-defined Modules</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 User-defined Modules.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# - The Python interpreter provides only a small part of the functionality needed for
#   most programs:
#   - No interaction with the operating system
#   - No network functionality
#   - No GUI
#   - ...
# - Additional functionality can be loaded using *modules* and *packages*.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Import a package

# %%

# %% [markdown] lang="en"
#
# Use the functionality: get the current working directory

# %%

# %% [markdown] lang="en"
#
# List current directory:

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Python provides many standard modules that are installed with the interpreter:
#
#  - abc: Abstract base classes
#  - argparse: command line arguments
#  - asyncio: Asynchronous programming
#  - collections: container data types
#  - ...
#
#  [Here](https://docs.python.org/3/py-modindex.html) is a more complete list.

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Internal representation of code in the Python interpreter:


# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## User-defined modules
#
# A user-defined module is simply a file containing Python code.
#
# As we have already seen:
# - If a Python module is in the search path, it can be loaded with `import`.
# - Jupyter notebooks cannot be loaded (without additional packages) as modules.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% [markdown] lang="en"
#
# View the source code of `my_test_module.py`

# %% tags=["keep"]
# # %pycat my_test_module.py

# %% [markdown] lang="en"
#
# Another way to view the source code:

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Loading Modules
#
# - The `import` statement loads the file associated with the module
# - Top-level code is executed
# - The module is stored in a cache

# %% tags=["keep"]
# noinspection PyUnresolvedReferences
import my_test_module


# %%


# %%


# %%


# %%

# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Sidebar: Automatic reload of modules
#
# In IPython (and thus Jupyter Notebooks) it is possible to activate the automatic
# loading of modified modules:

# %% tags=["keep"]
# %load_ext autoreload
# %autoreload 2

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# In startup scripts, one can avoid syntactical warnings by using instead:

# %% tags=["keep"]
try:
    get_ipython().run_line_magic("load_ext", "autoreload")  # noqa
    get_ipython().run_line_magic("autoreload", "2")  # noqa
except NameError:
    pass

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Example: `HttpServer`
#
# The Python interpreter does not have a built-in HTTP server. Using the
# standard library, it is not difficult to write one.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Example: `ModuleTest`
#
# The `ModuleTest` example shows how a program can be composed of several modules.

# %% tags=["keep"]
__name__
