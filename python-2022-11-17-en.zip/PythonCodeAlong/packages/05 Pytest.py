# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Pytest</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Pytest.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Pytest: testing in Python
#
#  - Python provides several built-in packages for writing unit tests and documentation
#    tests (`unittest` and `doctest`).
#  - Many projects use the `pytest` package anyway, as it avoids a lot of "boilerplate"
#    when writing tests.
#  - `pytest` can run `unittest` and `doctest` tests.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Installing pytest
#
#  Pytest is pre-installed in the Anaconda installation.
#
#  When using the standard Python distribution, it can be installed with
#  ```shell
#  pip install pytest
#  ```

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Writing tests
#
#  - Pytest can be configured very flexibly
#  - We only use the most basic features and rely on automatic configuration
#  - Tests for a package are written in a sub-package `test`
#  - Tests for the `foo.py` file are in the `test/foo_test.py` file
#  - Each test is a function whose name starts with `test`
#  - Assertions are written with the `assert` statement

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Example testing `MessageQueueDist`
#
#  See `Examples/MessageQueueDist`

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Workshop
#
# - `Workshop_136_todo_list_v3`
# - Up to "Load and Save" section
