# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Packages</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Packages.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Packages
#
# - Packages are a method to structure modules in a hierarchy: `a.b.c`
# - A package is a combination of several modules
# - `b` is a subpackage of `a`
# - `c` is a submodules (or subpackages) of `b`

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Structure of packages
#
# - Hierarchy comprised of directories and Python files
#   - E.g. directory `html` with subdirectories `parser`, `entities`
# - Requires a `__init__.py` file in each directory containing code that should be
#   imported
#   - This is not quite true...
# - The `__init__.py` file can be (and often is) empty

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
#  <img src="img/package-structure.png" alt="Package structure"
#       style="display:block;margin:auto;width:40%"></img>

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Finding packages
#
#  - Python looks for the package directory in `sys.path`.
#  - This can be set using the environment variable `PYTHONPATH` or directly from
#    Python.
#  - In most cases it is better not to undertake complicated operations on
#    `sys.path`.

# %% tags=["keep"]
import sys

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### The `import` statement
#
#  `import a.b.c`:
#
#  - `a` and `b` must be packages (directories).
#  - `c` can be a module or a package
#
#  `from a.b.c import d`
#  - `a` and `b` must be packages
#  - `c` can be a module or a package
#  - `d` can be a module, package, or name (i.e. variable, function, class, etc.).

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### References within a package
#
#  - `from . import a` imports `a` from the current package
#  - `from .. import a` imports `a` from the parent package
#  - `from .foo import a` imports `a` from its "sibling module" `foo`

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Example: `MessageQueue`
#
#  The `MessageQueue` example shows how a program can consist of several packages.
