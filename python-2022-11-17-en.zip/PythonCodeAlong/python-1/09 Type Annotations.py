# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Type Annotations</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 Type Annotations.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Type annotations
#
# Python allows the types of function arguments and the return type to be specified:

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Type annotations are for documentation only and are ignored by Python:

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Type Annotations
#
# Write a function `repeat(s: str, n: int) -> str` that returns the string `s`
# repeated `n` times:
#
# ```python
# >>> repeat("abc", 3)
# "abcabcabc"
# ```
#
# *Note:* You can use the multiplication operator `*` to repeat strings:
# ```python
# >>> "abc" * 3
# "abcabcabc"
#
#
# ```

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - What happens if you call `repeat()` with two numbers?
# - What happens if you call `repeat()` with two strings?

# %%

# %%
