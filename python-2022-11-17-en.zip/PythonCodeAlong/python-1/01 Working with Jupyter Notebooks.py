# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Working with Jupyter Notebooks</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Working with Jupyter Notebooks.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Working with notebooks
#
# - Notebooks are divided into cells
# - Cells can contain either text or Python code.
# - Command and edit mode (`Esc` / `Enter`)
# - Some keyboard shortcuts: `Strg`-`Enter`, `Shift`-`Enter`

# %% tags=["keep"]
def say_hello(name):
    print(f"Hello, {name}.")


# %% tags=["keep"]
say_hello("World")

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%
