# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Generator functions and coroutines</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Generator functions and coroutines.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Generator functions
#
# More complex cases can no longer be covered by generator expressions.
#
# - Generator that generates all numbers (no upper limit)
# - Generator that modifies an iterable (e.g. executes multiple times, takes a fixed
#   number of elements)
#
# For these cases there are generator functions.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# By using the `yield` keyword a function can "return multiple times." A
# function that uses `yield` in its body is called a generator function. Simply
# calling a generator function will not evaluate the function body, instead it
# will return a *generator* that can return multiple times:

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop
#
# Write a generator function `one_based_range(n)` that simulates `range(n)` when
# used with a single argument but iterates from 1 to `n` inclusive.

# %%

# %% tags=["keep"]
assert list(one_based_range(4)) == [1, 2, 3, 4]


# %% [markdown] lang="en"
#
# Write a generator function `inclusive_range()` that simulates the complete
# functionality of `range()` (i.e., being able to be called with one, two or
# three arguments) but includes its upper limit.
#
# Ensure that your implementation satisfies the provided test cases.


# %%

# %%

# %%

# %%

# %%

# %% tags=["keep"]
assert list(inclusive_range(3)) == [1, 2, 3]

# %% tags=["keep"]
assert list(inclusive_range(2, 4)) == [2, 3, 4]

# %% tags=["keep"]
assert list(inclusive_range(2, 2)) == [2]

# %% tags=["keep"]
assert list(inclusive_range(2, 1)) == []

# %% tags=["keep"]
assert list(inclusive_range(2, 6, 2)) == [2, 4, 6]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We can use generator functions to write functions that process iterators. For
# example, the `take()` generator function takes a fixed number of values from
# an iterator:

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Note that `drop()` function,  that removes the first `n` elements from an
# iterator is not a generator function but a regular function:

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Using generator function we can also define more complex iteration operations:

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "Generators"
#
# Write a generator  `leaves(tree: Bintree)` that returns all leaves from a binary tree (i.e.,
# all nodes that are not instances of `Bintree`.

# %% tags=["keep"]

from dataclasses import dataclass
from typing import Optional


# %% tags=["keep"]
@dataclass
class Bintree:
    value: object = None
    left: Optional["Bintree"] = None
    right: Optional["Bintree"] = None


# %%

# %% tags=["keep"]
tree1 = Bintree(1)
tree2 = Bintree(2, Bintree(1), Bintree(3))
tree3 = Bintree(
    1, Bintree(0), Bintree(3, Bintree(2), Bintree(5, Bintree(4), Bintree(6)))
)

# %% tags=["keep"]
assert tuple(leaves(tree1)) == (1,)

# %% tags=["keep"]
assert tuple(leaves(tree2)) == (1, 2, 3)

# %% tags=["keep"]
assert tuple(leaves(tree3)) == tuple(range(7))


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Coroutines
#
# `yield` can also be used to return a value to the site where it is invoked. In
# this case we also use the term *coroutine* for the generator.
#
# Coroutines are useful building blocks for features such as cooperative
# multitasking or event-based programming.
#
# To start a coroutine `c` we call the method `c.send(None)`. To send subsequent
# values we use `c.send(value)`.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %%


# %%


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
