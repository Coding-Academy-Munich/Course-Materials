# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Workshop: RPG-Dice</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Workshop_ RPG-Dice.py</div> -->


# %% [markdown] lang="en"
# # RPG dice
#
# In roleplaying games, conflicts between players are often decided by rolling
# dice, often multiple dice at the same time. Furthermore games often use
# not only the well known 6-sided dice, but also 4-sided, 8-sided, 20-sided dice, etc.
#
# The number and type of dice is described by the following notation:
#
# ```text
# <number of dice> d <number of sides per die>
# ```
#
# For example, rolling two 6-sided dice is described as `2d6`.
# Sometimes more complex formulas are used: `3d20 + 2d6 - 4`
# means that three 20-sided dice and two 6-sided dice are rolled
# at the same time, and the total sum of numbers is then reduced by 4.
#
# In some games, rolling the lowest or highest number of dice is treated
# in a special way ("catastrophic failure", "critical success").
#
# In the following exercise your task is to implement RPG dice in Python.
# To simplify testing your implementation it might be advisable
# to implement it in an IDE, but it is also possible to write tests as
# assertions in a jupyter notebook.
#
# Write tests for each functionality you implement. How can you deal with the
# randomness in dice rolling? What are the strengths and weaknesses of the strategy
# you have chosen to test?

# %% [markdown] lang="en"
# ## Generalized dice: Interface `Dice`
#
# Implement an abstract class `Dice` that describes rolling of
# arbitrary dice: The class should provide the following abstract methods:
#
# - `roll(): int` returns the result of a roll with the appropriate
#   dice.
#
# - properties `max_value: int` and `min_value: int` return the smallest and largest
#   value that can be rolled with the corresponding dice.
#   dice.
#
# If you are using Pytest:
# Write parametric Pytest tests to test (indirect) instances of `Dice`.

# %%

# %%

# %% [markdown] lang="en"
# ## Class `ConstantDice`
#
# Implement a class `ConstantDice`, which implements the interface `Dice` and
# represents a die that always rolls a constant value. The result value is
# specified when the creating an instance of the class.

# %% lang="en"

# %%


# %% [markdown] lang="en"
# ## Class `FairDice`
#
# Implement a class `FairDice` that implements the interface `Dice`and
# represents a single rolls with multiple dice all having the same (configurable)
# number of sides. For example, instances of the class `FairDice` should be
# able to simulate dice rolls of the form `3d6` or `4d17`
# (although in reality there is no 17-sided (fair) die).
#
# How can you deal with randomness in dice rolling when testing? What
# are strengths or weaknesses of the chosen testing strategy?
#
# *Hint:* Look at `random.randint()` and `random.seed()`.


# %%

# %%

# %% [markdown] lang="en"
# ## Class `SumDice`
#
# Implement a class `SumDice` which implements the interface `Dice` and
# represents the sum of the dice rolls with several different dice
# (potentially of the form `<m>d<n>`).


# %%

# %%

# %%

# %% [markdown] lang="en"
# ## Class `SimpleDie`
#
# Implement a class `SimpleDie`, which implements the interface `Dice`
# and represents a single roll of a die with an arbitrary number of sides
# (specified when the die is instantiated).


# %%

# %%

# %% [markdown] lang="en"
# ## Class `MultipleRollDice`
#
# Implement a class `MultipleRollDice` which implements the interface `Dice`
# and represents rolling of a (generalized) dice a certain number of times.
# Both the die and the number of rolls should be specified when an
# instance is created.
#
# What is the relationship between `FairDice` and the combination of
# `SimpleDie` and `MultipleRollDice`? How do the two
# implementation strategies in their testability.


# %%

# %%

# %% [markdown] lang="en"
# # Factory for RPG dice
#
# Write a function `create_dice(configuration: str) -> Dice`,
# which gets a configuration of RPG dice as argument and returns an
# suitable configuration of dice instances.  For example
# for "3d8 + 6" a `SumDice` should be returned, which contains a `FairDice` (with
# 3 8-sided dice) and a `ConstantDice` with the value 6.

# %% tags=["keep"]
