# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Workshop: Caesar Cipher</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Workshop_ Caesar Cipher.py</div> -->


# %% [markdown] lang="en"
# ## Caesar encryption
#
# Caesar encryption shifts each letter of the to-be-encrypted word
# in the alphabet by 3 places, e.g. the character string
# `ABC` becomes the string `DEF`. The last three letters of the alphabet
# are replaced by the first ones, i.e. `XYZA` becomes `ABCD`.
#
# Typically, in historical encryption methods, all
# letters are converted to uppercase, spaces and special characters are
# ignored. So after encrypting, the text "I came, saw and conquered." becomes
#
# ```
# LFKNDPVDKXQGVLHJWH
# ```

# %% [markdown] lang="en"
# Write a function `encode_char(c: str)` that takes a string `c`
# consisting of a single character and encodes it as follows:
#
# - if `c` is one of the letters `a` to `z` or `A` to `Z` then it is, if
#   necessary, converted to a capital letter and encrypted using the Caesar
#   cipher;
# - if `c` is a digit, it is returned unchanged;
# - otherwise the empty string `""` is returned.
#
# *Note:* The following two strings are helpful:

# %%

# %%

# %% [markdown] lang="en"
# Test your implementation with some values

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# Write a function `encode_caesar(text: str)` that takes a string
# `text` and encrypts it using Caesar encryption.

# %%

# %% [markdown] lang="en"
# Check your program with the following examples:

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
#
# Now write functions `decode_char(c: str)` and `decode_caesar(text: str)` that
# decrypt a text encrypted with the Caesar cipher. To be robust, these functions
# should return characters, that aren't letters or digits, unchanged.

# %%

# %%

# %%

# %% [markdown] lang="en"
# Test `decode_caesar()` with `pangram` and `verlaine`.

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# Decrypt the following text:
# ```
# SDFN PB ERA ZLWK ILYH GRCHQ OLTXRU MXJV
# (SDQJUDP IURP QDVD'V VSDFH VKXWWOH SURJUDP)
# ```

# %%

# %% [markdown] lang="en"
# The functions `encode_char()` and `decode_char()` contain a lot of duplicated
# code. Can you write a function `rot_n_char(...)` that generalizes the
# functionality of both functions?

# %%

# %% [markdown] lang="en"
# How can you implement `encode_caesar_2()` and `decode_caesar_2()`
# using `rot_n_char()`?

# %%

# %%

# %% [markdown] lang="en"
# Test the new function using `secret_text` and `verlaine`.
# Are the old and new implementations compatible?

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# Decoding with the original code for the Caesar cipher may reveal a
# bug that frequently appears in the generalized implementation:
# it may mix numbers and letters.
#
# Congratulations if you managed to avoid this error!
# How can you fix this bug if it appears in your code?

# %%

# %%

# %% [markdown] lang="en"
# Test the new implementation by decoding `secret_text`.

# %%

# %% [markdown] lang="en"
# Test the new implementation with `verlaine`.

# %%

# %%

# %%

# %%
