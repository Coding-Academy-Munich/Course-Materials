# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Pirate Loot</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Pirate Loot.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Pirate Loot
#
# Since automating the computation of loot shares for your pirate gang has proven
# to be quite successful, you now want to automate loot reporting as well.
#
# To do this, write a function `create_loot_report(what: str, value: int) -> str`
# that returns a loot report:
#
# ```python
# >>> create_loot_report("old fishing net", 0)
# 'Found an old fishing net. Its worth seems to be nothing, Zounds!!!'
# >>> create_loot_report("pile of firewood", 1)
# 'Found a pile of firewood. Its worth seems to be a single, darned doubloon!'
# >>> create_loot_report("diamond ring", 100)
# 'Found a diamond ring. Its worth seems to be 100 doubloons.'
# ```
#
# Note that the article (`a` or `an`) depends on whether `what` starts with a vowel
# or a consonant and that the text for the loot amount is different for
# 0, 1 and more gold doubloons.


# %%

# %% tags=["keep"]
assert (
    create_loot_report("old fishing net", 0)
    == "Found an old fishing net. Its worth seems to be nothing, Zounds!!!"
)

# %% tags=["keep"]
assert (
    create_loot_report("pile of firewood", 1)
    == "Found a pile of firewood. Its worth seems to be a single, darned doubloon!"
)

# %% tags=["keep"]
assert (
    create_loot_report("diamond ring", 100)
    == "Found a diamond ring. Its worth seems to be 100 doubloons."
)
