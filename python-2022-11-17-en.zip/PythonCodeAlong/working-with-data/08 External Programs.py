# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>External Programs</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 External Programs.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Subprocesses
#
# *Note:* You need to have the `ext_sample_app` package (in
# `Examples/ExternalSampleApplication`) installed to run the following examples.
#
# `subprocess.run()` is the preferred way of running external applications.

# %%

# %%

# %% [markdown] lang="en"
# With `shutil.which()` you can determine the full path of a program.

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
#
# With `sys.executable` you can find out the path of the currently active Python
# interpreter. This is the preferred way to start a Python process.

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# ## Popen: Concurrent execution of programs
#
# If you can't wait for the launched program to finish, you have to use the
# `subprocess. Popen` class:

# %%

# %%

# %%

# %% [markdown] lang="en"
#
# `proc.communicate()` sends a message to `proc`, closes the input and output
# streams and ends the process.

# %%

# %% [markdown] lang="en"
#
# With `proc.poll()` you can determine whether the process has already ended and
# what its return value was. If the result is `None`, the process is still
# active. `proc.wait()` waits a certain amount of time and returns the status of
# the process. If the process hasn't finished in the allotted time, a
# `TimeoutExpired` exception is thrown.

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# ## Communication with sockets
#
# The following example shows how to start a process and then communicate with
# it using sockets.


# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
