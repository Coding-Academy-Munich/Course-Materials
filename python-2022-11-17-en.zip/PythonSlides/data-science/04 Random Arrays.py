# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Random Arrays</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Random Arrays.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Random Arrays

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Evenly distributed between 0 and 1

# %% tags=["keep"]
import numpy as np

# %% tags=["keep"]
rng = np.random.default_rng(2022)

# %%
rng.random(3)

# %%
rng.random((2, 4))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Integers

# %% tags=["keep"]
rng = np.random.default_rng(2022)

# %%
rng.integers(10)

# %%
rng.integers(1, 6, endpoint=True)

# %%
rng.integers(1, 6, size=(4, 10), endpoint=True)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Normally distributed

# %% tags=["keep"]
rng = np.random.default_rng(2022)

# %%
rng.standard_normal((3, 5))

# %%
rng.normal(loc=10.0, scale=0.5, size=(2, 5))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Other distributions
#
# A list of all distributions and their parameters is in the
# [Numpy documentation](https://numpy.org/doc/stable/reference/random/generator.html#distributions)


# %% tags=["keep"]
rng = np.random.default_rng(2022)

# %%
rng.exponential(scale=1.0, size=(2, 4))

# %%
rng.logistic(size=(3, 3))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Random Arrays
#
# Create the following arrays:

# %% [markdown] lang="en"
#
# A 2×8 array containing uniformly distributed random numbers in [0, 1).

# %%
rng = np.random.default_rng(2022)
rng.random(size=(2, 8))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# A vector of length 5 containing standard normally distributed numbers.

# %%
rng = np.random.default_rng(2022)
rng.standard_normal(5)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# A 3 × 4 array containing normally distributed numbers with mean 5 and
# standard deviation 0.5.

# %%
rng = np.random.default_rng(2022)
rng.normal(5.0, 0.5, size=(3, 4))
