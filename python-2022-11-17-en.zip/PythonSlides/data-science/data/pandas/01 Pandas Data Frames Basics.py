# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Pandas Data Frames Basics</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Pandas Data Frames Basics.py</div> -->


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
def create_data_frame():
    rng = np.random.default_rng(42)
    array = rng.normal(size=(5, 4), loc=5.0, scale=2.0)
    index = ["A", "B", "C", "D", "E"]
    columns = ["w", "x", "y", "z"]
    return pd.DataFrame(array, index=index, columns=columns)


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
PANDAS_DIR_FROM_ENV = os.getenv("PANDAS_DIR_PATH")
if PANDAS_DIR_FROM_ENV:
    pandas_dir_path = Path(PANDAS_DIR_FROM_ENV)
else:
    pandas_dir_path = Path("data/pandas").absolute()
print(f"Pandas data: {pandas_dir_path}")

# %% tags=["keep"]
df_csv = pd.read_csv(pandas_dir_path / "example_data.csv")

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Extracting Columns

# %% tags=["keep"]
df = create_data_frame()
df

# %%
df["x"]

# %%
type(df["x"])

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df[["x"]]

# %%
type(df[["x"]])

# %%
df[["x", "w", "x"]]

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Plotting data frames

# %%
df_csv["Col 0"].hist()
plt.show()

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df_csv.hist()
plt.show()

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
df_csv.hist(bins=20, figsize=(12, 8))
plt.show()

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df_csv.plot.scatter(x="Col 1", y="Col 2")
plt.show()

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
df_csv.plot(kind="scatter", x="Col 1", y="Col 2", c="Col 3", cmap="hot")
plt.show()

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
df_csv.plot(
    kind="scatter",
    x="Col 1",
    y="Col 2",
    c=df_csv["Col 3"],
    s=df_csv["Col 4"].abs() * 6,
    alpha=0.4,
    cmap="hot",
)
plt.show()

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Indices and Operations

# %% tags=["keep"]
df = create_data_frame()
df["w"]

# %%
df.index

# %%
df.index.is_monotonic_increasing

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.size

# %%
df.ndim

# %%
df.shape

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Creating, renaming, deleting columns

# %% tags=["keep"]
df = create_data_frame()

# %%
df["Sum"] = df["w"] + df["y"]

# %%
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.rename(columns={"Sum": "w + y"})

# %%
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.rename(columns={"Sum": "w + y"}, index={"E": "Z"}, inplace=True)

# %%
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.drop("A")

# %%
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.drop("B", inplace=True)

# %%
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.drop("z", axis=1)

# %%
df

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
df.drop("z", axis=1, inplace=True)

# %%
df

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
type(df["y"])

# %%
del df["y"]

# %%
df

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Selection

# %% tags=["keep"]
df = create_data_frame()
df

# %%
df["w"]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df[["x", "w"]]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
# Error!
# df["A"]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.loc["B"]

# %%
type(df.loc["B"])

# %%
df.loc["B", "z"]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.loc[["B"]]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.loc[["A", "C"]]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.loc[["A", "C"], ["x", "y"]]

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
df.loc[:, ["x", "w"]]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.iloc[0]

# %%
df.iloc[0, 0]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.iloc[[0, 3]]

# %%
df.iloc[[1, 2], [0, 3]]

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Conditional Selection

# %% tags=["keep"]
df = create_data_frame()
df

# %%
df > 5

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df[df > 5]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df["w"] > 5

# %%
df[df["w"] > 5]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df[df["w"] > 5][["x", "y"]]

# %%
df[(df["w"] > 5) & (df["x"] < 5)]

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Information about Data Frames

# %% tags=["keep"]
df = create_data_frame()
df["txt"] = list("abcde")
df.iloc[1, [1, 2]] = np.nan
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.describe()

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.info()

# %%
df.dtypes

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Data Frame Index

# %% tags=["keep"]
df = create_data_frame()
df["txt"] = list("abcde")
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.reset_index()

# %%
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.reset_index(inplace=True)

# %%
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.rename(columns={"index": "old_index"}, inplace=True)

# %%
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.set_index("txt")

# %%
df

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
df.set_index("txt", inplace=True)
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.set_index("old_index", inplace=True)
df

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df.info()

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mini-workshop: Wine Data Frame
#
# The file `pandas_dir_path "wines.csv"` contains data about different types of wine.
#
# - Load the file into a Pandas Data Frame.
# - How many rows and columns does the data frame have?
# - Analyze what columns the data frame has and what type they are.
# - What are the minima, maxima, mean and quantiles of the numeric columns?

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
wine_df = pd.read_csv(pandas_dir_path / "wines.csv", index_col=0)
wine_df

# %%
wine_df.info()

# %%
wine_df.describe()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Insert a column `normal_proline` whose values are the values of `proline` scaled
#   to the range [0, 1].
# - Verify that the new column's values are in the desired range.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
proline = wine_df["proline"]
wine_df["normal_proline"] = (proline - proline.min()) / (proline.max() - proline.min())

# %%
wine_df

# %%
wine_df["normal_proline"].min(), wine_df["normal_proline"].max()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Plot histograms of the 'alcohol' and 'total phenols' columns.
# - Plot a scatterplot of `total_phenols` versus `nonflavanoid_phenols` values.
# - Plot a scatterplot of `total_phenols` versus `nonflavanoid_phenols` values,
#   assigning the points a different color depending on the value of `target` and
#   plotting the markers with the size of the `proline` attribute divided by 75.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
wine_df.hist(column="alcohol", bins=15)
plt.show()

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
wine_df.hist(column="total_phenols", bins=15)
plt.show()

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
wine_df.plot(kind="scatter", x="total_phenols", y="nonflavanoid_phenols")
plt.show()

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
wine_df.plot(
    kind="scatter",
    x="total_phenols",
    y="nonflavanoid_phenols",
    s=wine_df["proline"] / 75,
    c="target",
    cmap="brg",
)
plt.show()
