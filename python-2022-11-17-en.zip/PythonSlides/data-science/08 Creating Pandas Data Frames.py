# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Creating Pandas Data Frames</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Creating Pandas Data Frames.py</div> -->


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
from pathlib import Path
import numpy as np
import pandas as pd
import os

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
PANDAS_DIR_FROM_ENV = os.getenv("PANDAS_DIR_PATH")
if PANDAS_DIR_FROM_ENV:
    pandas_dir_path = Path(PANDAS_DIR_FROM_ENV)
else:
    pandas_dir_path = Path("data/pandas").absolute()
print(f"Pandas data: {pandas_dir_path}")

# %% tags=["keep"]
csv_file = pandas_dir_path / "example_data.csv"
excel_file1 = pandas_dir_path / "excel_data.xlsx"
excel_file2 = pandas_dir_path / "excel_other_sheet.xlsx"

# %%
os.listdir(pandas_dir_path)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Creating Data Frames

# %% [markdown] lang="en"
# ### From a List or NumPy Array

# %% tags=["keep"]
df = pd.DataFrame([[1, 2], [3, 4], [5, 6], [7, 8]], columns=["A", "B"])

# %%
df

# %%
type(df)


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
def create_data_frame():
    rng = np.random.default_rng(42)
    array = rng.normal(size=(5, 4), loc=5.0, scale=2.0)
    index = ["A", "B", "C", "D", "E"]
    columns = ["w", "x", "y", "z"]
    return pd.DataFrame(array, index=index, columns=columns)


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
df = create_data_frame()
df

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ### From a CSV File

# %%
df_csv = pd.read_csv(csv_file)

# %%
df_csv

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df_csv = pd.read_csv(csv_file, index_col=0)

# %%
df_csv

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ### From an Excel File

# %%
df_excel = pd.read_excel(excel_file1, index_col=0)

# %%
df_excel

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df_excel2 = pd.read_excel(excel_file2)

# %%
df_excel2

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df_excel2 = pd.read_excel(
    excel_file2,
    index_col=0,
    sheet_name="Another Sheet",
    header=0,
    skiprows=[1],
)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
df_excel2.head(18)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ### Other Formats:
#
# - `pd.read_clipboard`
# - `pd.read_html`
# - `pd.read_json`
# - `pd.read_pickle`
# - `pd.read_sql` (uses SQLAlchemy to access a database)
# - ...

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Creating Data Frames
#
# The file `boston-housing.csv` (located in the `data/pandas` directory contains
# a table of housing prices in Boston. Load this table into a Pandas DataFrame.

# %%
df_boston = pd.read_csv(pandas_dir_path / "boston-housing.csv", index_col=0)

# %%
df_boston

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The Excel file `housing-data.xlsx` (in the `data/pandas` directory) contains two
# sheets: `Boston` and `California`. Load these tables into Pandas Data Frames.

# %%
df_boston2 = pd.read_excel(
    pandas_dir_path / "housing-data.xlsx", sheet_name="Boston", index_col=0
)

# %%
df_boston2

# %%
df_california = pd.read_excel(
    pandas_dir_path / "housing-data.xlsx",
    sheet_name="California",
    index_col=None,
    skiprows=[1],
)

# %%
df_california
