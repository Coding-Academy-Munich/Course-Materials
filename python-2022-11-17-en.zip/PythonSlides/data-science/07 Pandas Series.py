# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Pandas Series</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">07 Pandas Series.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Pandas Type `Series`
#
# A series represents a sequence of values, similar to a Python list. Elements
# of their series can be retrieved by their numerical index, but in addition a
# series can have a semantically meaningful index (e.g., for time series).
#
# Internally, a Pandas series is backed by a numpy array, therefore most of the
# numpy operations are applicable to series as well.
#
# In addition, it is easy (and cheap) to convert series to numpy.

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Creation
#
# ### From Lists

# %%
pd.Series(data=[10, 20, 30, 40])

# %%
pd.Series(["a", "b", "c"])

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### From Lists with Index

# %%
pd.Series(data=[1, 2, 3, 4], index=["w", "x", "y", "z"])

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### From Range or Other Iterable

# %%
pd.Series(data=range(1, 201, 2))

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
data = pd.Series(data=range(1, 201, 2))
data.head()

# %%
data.tail()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### From Dictionary

# %%
pd.Series(data={"Ice Cream": 2.49, "Cake": 4.99, "Fudge": 7.99})

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Indices

# %% tags=["keep"]
food = pd.Series({"Ice Cream": 2.49, "Cake": 4.99, "Fudge": 7.99})

# %%
food

# %%
food.index

# %%
food.size

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Accessing Values

# %%
food["Cake"]

# %%
food.loc["Cake"]

# %%
# Error!
# food["Pie"]

# %%
food[0]

# %%
food.iloc[0]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
confusing = pd.Series(data=np.arange(-1, 5), index=np.arange(-3, 3))
confusing

# %%
confusing[0]

# %%
confusing.loc[0]

# %%
confusing.iloc[0]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Methods

# %%
food.sum()

# %%
food.mean()

# %%
food.argmin()


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def discount(price):
    return price * 0.9


# %%
food.apply(discount)

# %%
food

# %%
food.apply(lambda price: price * 0.9)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Names of series

# %%
food.name

# %%
food.name = "Deserts"

# %%
food.name

# %%
food

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Plotting series

# %% tags=["keep"]
food = pd.Series({"Ice Cream": 2.49, "Cake": 4.99, "Fudge": 7.99})

# %%
food.plot.bar()
plt.show()

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
food.plot(kind="bar")
plt.show()

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
import random

# %% tags=["keep"]
data = pd.Series(data=[random.gauss(0.0, 10.0) for _ in range(5_000)])

# %%
data.plot.hist(legend=False, bins=20)
plt.show()

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Operations on multiple series

# %% tags=["keep"]
food1 = pd.Series({"Ice Cream": 2.99, "Cake": 5.99, "Fudge": 6.99})
food2 = pd.Series({"Cake": 4.99, "Ice Cream": 2.99, "Pie": 3.49, "Cheese": 4.99})

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
food_sum = food1 + food2
food_sum

# %%
food1 + 0.5

# %%
food1

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
pd.concat([food1, food2])

# %%
food1

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
all_food = pd.concat([food1, food2])

# %% tags=["keep"]
all_food

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Missing Values

# %%
food = food1 + food2
food

# %%
food.isna()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Determining how many values `NaN`s are:

# %%
food.isna().sum()

# %%
food.dropna()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Slices and Fancy Indexing

# %%
all_food[0:2]

# %%
all_food.iloc[0:2]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.iloc[0:2] = 2.99

# %%
all_food

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# You can also use a Boolean Series object for indexing. Then a sub-series
# of the series is selected:

# %% tags=["keep"]
food1

# %% tags=["keep"]
food1[pd.Series({"Ice Cream": False, "Cake": True, "Fudge": True})]

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food < 4

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food[all_food < 4]

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Multiple occurrences of values

# %%
food1

# %%
food1.is_unique

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
food2

# %%
food2.is_unique

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Multiple occurrences of index values

# %%
food1.index

# %%
food1.index.is_unique

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.index

# %%
all_food.index.is_unique

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Accessing values (again)

# %% tags=["keep"]
all_food

# %%
all_food.loc["Pie"]

# %%
all_food["Pie"]

# %%
type(all_food.loc["Pie"])

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.loc["Cake"]

# %%
all_food["Cake"]

# %%
type(all_food.loc["Cake"])

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.loc[["Pie"]]

# %%
all_food.loc[["Cake"]]

# %%
all_food.loc[["Pie", "Cake"]]

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Grouping

# %% tags=["keep"]
all_food

# %%
all_food.groupby(level=0)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.groupby(level=0).indices

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.groupby(level=0).aggregate(list)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.groupby(level=0).aggregate(set)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
all_food.groupby(level=0).min()

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Sorted and unsorted Indices

# %%
all_food.index.is_monotonic_increasing

# %%
sorted_food = all_food.sort_index()

# %%
sorted_food

# %%
sorted_food.index.is_monotonic_increasing

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
sorted_food = all_food.sort_values()

# %%
sorted_food.is_monotonic_increasing

# %%
sorted_food.index.is_monotonic_increasing

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Fancy Indexing and sorted indices

# %%
all_food

# %%
all_food.iloc[1:3]

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
# all_food.loc["Cake":"Fudge"]

# %%
sorted_food = all_food.sort_index()

# %%
sorted_food.loc["Cake":"Fudge"]

# %% [markdown] lang="en"
#
# **Important:** The upper value of the slice, `"Fudge"` is contained in the
# result!

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Simple Time-Series analysis
#
# We have the following time series with measurements:

# %% tags=["keep"]
measurements = pd.Series(
    [13.78, 13.41, 13.21, 10.24, 9.84, 9.35, 6.23, 5.78, 5.26, 3.44],
    index=[1, 4, 5, 6, 6, 7, 8, 8, 9, 11],
    name="Measurements",
)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Are the times of the measurements in ascending order?
# - Are the measurements in ascending or descending order?
# - Are the times of the measurements unique?
# - Are the values of the measurements unique?

# %%
measurements.index.is_monotonic_increasing

# %%
measurements.is_monotonic_increasing

# %%
measurements.is_monotonic_decreasing

# %%
measurements.index.is_unique

# %%
measurements.is_unique

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - What is the mean, median and standard deviation of the readings?

# %%
measurements.mean()

# %%
measurements.median()

# %%
measurements.std()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Create two new series that contain the largest (or smallest) value for
#   times with multiple measurements.
# - Create a new series containing the mean of all measurements for times
#   with multiple measurements.

# %%
min_measurements = measurements.groupby(measurements.index).min()
min_measurements

# %%
max_measurements = measurements.groupby(measurements.index).max()
max_measurements

# %%
avg_measurements = measurements.groupby(measurements.index).mean()
avg_measurements

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Create a new series containing all measurements that took place between 3 and 7
#   seconds  (including the limits).
# - Create a new series containing all measurements between the 2nd and the 6th
#   measurement (including the limits).

# %%
measurements

# %%
measurements.loc[3:7]

# %% tags=["alt"]
# measurements[3:9]

# %%
measurements.iloc[2:7]

# %% [markdown] lang="en"
#
# - Create a series containing all measurements whose value is greater than 10.

# %%
measurements[measurements > 10]
