# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Exceptions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Exceptions.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Exceptions
#
# - Throwing an exception interrupts the execution of the program
# - The chain of function calls is broken off until the exception is handled

# %%
def int_sqrt(n: int) -> int:
    for m in range(n + 1):
        if m * m == n:
            return m
    raise ValueError(f"{n} is not a square number.")


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
int_sqrt(9)


# %%
# int_sqrt(8)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Unhandled exceptions abort program execution:


# %%
def print_int_sqrt(n):
    root = int_sqrt(n)
    print(f"The root of {n} is {root}.")


# %%
print_int_sqrt(9)

# %%
print_int_sqrt(8)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Exception classes
#
# In Python, there are many predefined classes that signal different types of error:
# - `Exception`: Base class of all exceptions that can be handled
# - `ArithmeticError`: Base class of all errors in arithmetic operations:
#   - OverflowError
#   - Zero Division Error
# - `LookupError`: base class when an invalid index for a data structure
#   has been used
# - `AssertionError`: error class used by `assert`
# - `EOFError`: Error when `input()` unexpectedly reaches the end of a file
# - ...
#
# The list of error classes defined in the standard library is
# [here](https://docs.python.org/3/library/exceptions.html).

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Workshop: Bank accounts
#
# Define a class `BankAccount` with an attribute `balance: float`
# and methods `deposit(amount: float)` and `withdraw(amount: float)`.
#
# *Note: For a more realistic implementation, `decimal.Decimal`
# can be used instead of `float`.*
#
# The class should throw an exception of type `ValueError` in the following cases:
#
# - If a new `BankAccount` with a negative `balance` is created.
# - If `deposit` is called with a negative value.
# - When `withdraw` is called with a negative value if by withdrawing
#   the desired amount the `balance` attribute of the account would become
#   negative.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
from dataclasses import dataclass


# %%
@dataclass
class BankAccount:
    balance: float

    def __post_init__(self):
        if self.balance < 0:
            raise ValueError(
                f"Cannot create an account with negative balance: {self.balance}."
            )

    def deposit(self, amount: float):
        if amount > 0:
            self.balance += amount
        else:
            raise ValueError(f"Cannot deposit a negative amount: {amount}")

    def withdraw(self, amount: float):
        if amount <= 0:
            raise ValueError(f"Cannot withdraw a negative amount: {amount}")
        if amount > self.balance:
            raise ValueError(
                f"Cannot withdraw {amount} because it exceeds "
                f"the current balance of {self.balance}."
            )
        self.balance -= amount


# %% [markdown] lang="en"
#
# Test the functionality of the class for both successful transactions,
# as well as for transactions that throw exceptions.

# %%
BankAccount(100.0)

# %%
BankAccount(-100)

# %%
b = BankAccount(100.0)
b

# %%
b.deposit(200.0)
b

# %%
b.deposit(-100.0)

# %%
b.withdraw(50.0)
b

# %%
b.withdraw(-200.0)

# %%
b.withdraw(1000.0)


# %% [markdown] lang="en" tags=["alt"]
# ## Solution without dataclasses:

# %% tags=["alt"]
class BankAccount:
    def __init__(self, balance):
        if balance < 0:
            raise ValueError(
                f"Cannot create an account with negative balance: {balance}."
            )
        self.balance = balance

    def __repr__(self):
        return f"BankAccount({self.balance:.2f})"

    def deposit(self, amount: float):
        if amount > 0:
            self.balance += amount
        else:
            raise ValueError(f"Cannot deposit a negative amount: {amount}")

    def withdraw(self, amount: float):
        if amount <= 0:
            raise ValueError(f"Cannot withdraw a negative amount: {amount}")
        if amount > self.balance:
            raise ValueError(
                f"Cannot withdraw {amount} because it exceeds "
                f"the current balance of {self.balance}."
            )
        self.balance -= amount


# %% tags=["alt"]
BankAccount(100.0)

# %% tags=["alt"]
BankAccount(-100)

# %% tags=["alt"]
b = BankAccount(100.0)
b

# %% tags=["alt"]
b.deposit(200.0)
b

# %% tags=["alt"]
b.deposit(-100.0)

# %% tags=["alt"]
b.withdraw(50.0)
b

# %% tags=["alt"]
b.withdraw(-200.0)

# %% tags=["alt"]
b.withdraw(1000.0)
