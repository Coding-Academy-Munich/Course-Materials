# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Closures</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Closures.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Closures
#
# In Python it is possible to define functions inside other functions. The inner
# functions can access the variables of the outer function.

# %%
def a_fun(x, y):
    z = x + y
    result = pow(z, 3)
    print(result)
    return result


# %% tags=["keep"]
def print_raw_function_info(code):
    print(f"Consts:    {code.co_consts}")
    print(f"Names:     {code.co_names}")
    print(f"Var names: {code.co_varnames}")
    print(f"Free vars: {code.co_freevars}")


# %% tags=["keep"]
def print_function_info(fun):
    print_raw_function_info(fun.__code__)
    print(f"Closure:   {fun.__closure__}")
    if fun.__closure__:
        for i, cell in enumerate(fun.__closure__):
            print(f"    Cell[{i}] contents: {cell.cell_contents}")


# %%
print_function_info(a_fun)

# %% tags=["keep"]
from random import randint


# %%
def generate_random_value():
    return randint(1, 4)


# %%
print_function_info(generate_random_value)

# %%
generate_random_value()

# %%
print_function_info(generate_random_value)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
from dis import dis

# %%
dis(generate_random_value)


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def make_and_call_nested_function():
    def return_random_value():
        return randint(1, 4)

    return return_random_value()


# %%
make_and_call_nested_function()

# %%
print_function_info(make_and_call_nested_function)

# %%
nested_code = make_and_call_nested_function.__code__.co_consts[1]
print_raw_function_info(nested_code)

# %%
dis(nested_code)

# %%
dis(make_and_call_nested_function)


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def make_and_return_nested_function():
    def return_random_value():
        return randint(1, 4)

    return return_random_value


# %%
my_fun = make_and_return_nested_function()
my_fun

# %%
my_fun()

# %%
print_function_info(make_and_return_nested_function)

# %%
nested_code = make_and_return_nested_function.__code__.co_consts[1]
print_raw_function_info(nested_code)

# %%
dis(nested_code)

# %%
dis(make_and_return_nested_function)

# %%
print_function_info(my_fun)

# %%
dis(my_fun)


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def make_closure_1():
    local_value = randint(1, 4)

    def return_local_value():
        return local_value

    return return_local_value


# %%
my_closure_1 = make_closure_1()
my_closure_1

# %%
my_closure_1()

# %%
your_closure_1 = make_closure_1()
your_closure_1

# %%
your_closure_1()

# %%
print_function_info(make_closure_1)

# %%
nested_code = make_closure_1.__code__.co_consts[3]
print_raw_function_info(nested_code)

# %%
dis(nested_code)

# %%
dis(make_closure_1)

# %%
print_function_info(my_closure_1)

# %%
print_function_info(your_closure_1)

# %%
dis(my_closure_1)


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def make_closure_2():
    local_value = randint(1, 10)

    def return_local_value():
        return local_value

    def inc_local_value():
        nonlocal local_value
        local_value += 1

    return return_local_value, inc_local_value


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
get_value_1, inc_value_1 = make_closure_2()
get_value_2, inc_value_2 = make_closure_2()
get_value_1(), get_value_2()

# %%
get_value_1(), get_value_2()

# %%
inc_value_1()
get_value_1(), get_value_2()

# %%
inc_value_2()
get_value_1(), get_value_2()

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
print_function_info(inc_value_1)
print_function_info(get_value_1)

# %%
print_function_info(inc_value_2)
print_function_info(get_value_2)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "mean computation"
#
# Write a function `make_mean_fun()` that returns two closures
#
# - a function `add_value(new_value: int)` that appends `new_value` to a list
#   stored in a local variable `values` of `make_mean_fun()`
# - a function `compute_mean()` that return the mean value of all values
#   previously stored in `values`.
#
# Do you have to use `nonlocal` to access `value`? Why, or why not?
#
# Ensure that your implementation satisfies the provided test cases.


# %%
def make_mean_fun():
    values: list[int] = []

    def add_value(new_value: int):
        values.append(new_value)

    def compute_mean():
        return sum(values) / len(values)

    return add_value, compute_mean


# %% [markdown] lang="en"
#
# Test cases:

# %% tags=["keep"]
add_value_1, compute_mean_1 = make_mean_fun()
add_value_2, compute_mean_2 = make_mean_fun()

# %% tags=["keep"]
for i in range(10):
    add_value_1(i)

for i in range(2, 21, 4):
    add_value_2(i)

# %% tags=["keep"]
assert compute_mean_1() == 4.5

# %% tags=["keep"]
assert compute_mean_2() == 10.0


# %% [markdown] lang="en"
#
# Write a function `make_mean_fun_2()` that returns closures with similar
# functionality but stores only the number of added elements and their total
# sum.
#
# Do you have to use `nonlocal` to access the closure variables in this case?
# Why, or why not?

# %%
def make_mean_fun_2():
    sum_of_values: int = 0
    num_values: int = 0

    def add_value(new_value: int):
        nonlocal sum_of_values, num_values
        sum_of_values += new_value
        num_values += 1

    def compute_mean():
        return sum_of_values / num_values

    return add_value, compute_mean


# %% [markdown] lang="en"
#
# Test cases:


# %% tags=["keep"]
add_value_3, compute_mean_3 = make_mean_fun_2()
add_value_4, compute_mean_4 = make_mean_fun_2()

# %% tags=["keep"]
for i in range(10):
    add_value_3(i)

# %% tags=["keep"]
for i in range(2, 21, 4):
    add_value_4(i)

# %% tags=["keep"]
assert compute_mean_3() == 4.5

# %% tags=["keep"]
assert compute_mean_4() == 10.0
