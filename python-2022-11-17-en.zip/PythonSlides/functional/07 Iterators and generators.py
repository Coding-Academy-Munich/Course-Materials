# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Iterators and generators</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">07 Iterators and generators.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Iteration over different Types
#
# We have seen that the `for` loop in Python can be used on different types:

# %%
for x in [1, 2, 3]:
    print(x)

# %%
for x in "abc":
    print(x)

# %% [markdown] lang="en"
# The mechanism that Python uses to achieve this are iterators:

# %%
my_list = [1, 2, 3]

# %%
it = iter(my_list)
it

# %%
next(it)

# %%
next(it)

# %%
next(it)

# %%
# next(it)

# %%
for x in my_list:
    print(x)

# %%
for x in iter(my_list):
    print(x)

# %% [markdown] lang="en"
# The type of iterable elements is often specified as `Iterable`:

# %%
from typing import Iterable

# %%
isinstance(my_list, Iterable)

# %%
isinstance(iter(my_list), Iterable)


# %%
class MyClass:
    def __iter__(self):
        return iter([1, 2, 3])


# %%
my_obj = MyClass()

# %%
isinstance(my_obj, Iterable)

# %%
for x in my_obj:
    print(x)

# %%
list_it = iter(my_list)
obj_it = iter(my_obj)

# %%
tuple(list_it)

# %%
tuple(list_it)

# %%
tuple(obj_it)

# %%
tuple(obj_it)

# %%
a, b, c = my_obj
print(f"a = {a}, b = {b}, c = {c}")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Some types can return more than one kind of iterator:

# %%
my_dict = dict(a=1, b=2, c=3)
my_dict

# %%
tuple(my_dict)

# %%
tuple(my_dict.keys())

# %%
tuple(my_dict.values())

# %%
tuple(my_dict.items())

# %%
tuple(range(3))

# %% [markdown] lang="en"
# ## How does the `for` loop work?

# %%
r = range(3)
r

# %%
for x in range(3):
    print(x, end=" ")

# %%
_r = range(3)
_temp_iter = iter(_r)
while True:
    try:
        x = next(_temp_iter)
    except StopIteration:
        break
    print(x, end=" ")

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Generators
#
# - It is not efficient to construct a list if we only use it for
#   want to iterate over their elements
# - Python offers the possibility to define generators that can be iterated, but don't
#   have the overhead of a list
# - The simplest way to define them is with generator expressions:

# %%
squares_list = [n * n for n in range(10)]

# %%
for i in squares_list:
    print(i)

# %%
gen = (n * n for n in range(10))
gen

# %%
for i in gen:
    print(i, end=" ")

# %%
for i in gen:
    print(i, end=" ")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# It is also possible to write more complex generator expressions:

# %%
for i, j, k in ((n, m, n * m) for n in range(2, 5) for m in range(n, 5)):
    print(f"{i}, {j}, {k}")

# %%
gen = (n * n for n in range(3))
repr(gen)

# %%
it = iter(gen)
repr(it)

# %%
next(it)

# %%
next(it)

# %%
next(it)

# %% [markdown] lang="en"
# `it` is "exhausted," one cannot get new values:

# %%
# next(it)

# %%
# next(it)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "Generator-Expressions"
#
# - Compute the sum of the first 100 square by using a generator expression.
# - Compute the sum of all numbers between 100 and 500 that are divisible by 7
#   using a generator expression.
# - Write a function
#   `all_powers(numbers: Iterable[int], powers: Iterable[int])` that
#   returns a list whose elements are tuples containing all powers from `powers` of
#   elements from `numbers`

# %%
sum(x**2 for x in range(100))

# %%
sum(x for x in range(100, 501) if x % 7 == 0)


# %%
def all_powers(numbers: Iterable[int], powers: Iterable[int]):
    return [tuple(n**p for p in powers) for n in numbers]


# %% tags=["keep"]
assert all_powers(range(3), range(3)) == [(1, 0, 0), (1, 1, 1), (1, 2, 4)]

# %% tags=["keep"]
assert all_powers([10, 11, 12], [2, 3]) == [(100, 1000), (121, 1331), (144, 1728)]
