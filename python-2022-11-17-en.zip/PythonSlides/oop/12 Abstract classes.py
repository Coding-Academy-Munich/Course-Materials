# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Abstract classes</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">12 Abstract classes.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Abstract classes
#
# - Classes that cannot have direct instances
# - Have `abc.ABC` as base class
#     - (a metaclass is actually responsible for their behavior)
# - Allow use of the `@abstractmethod` decorator to define abstract methods
#     - Often the body of an abstract method is written as `...`
# - Abstract classes that have only abstract methods are called Interfaces
#     - Interfaces describe requirements placed on subclasses

# %%
...

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
from abc import ABC, abstractmethod


class MyBase(ABC):
    @abstractmethod
    def my_method(self):
        ...


# %%
class MyClass(MyBase):
    def my_method(self):
        super().my_method()
        print("my_method()")


# %%
mc = MyClass()
mc.my_method()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - Abstract methods can provide an implementation
# - Classes that inherit from an abstract class but do not override all abstract
#   methods are themselves abstract.

# %%
from abc import ABC, abstractmethod


class MyBase(ABC):
    @abstractmethod
    def my_method(self):
        print("Hi!")


# %%
class MyClass(MyBase, ABC):
    pass


# %%
# mc = MyClass()


# %%
class YourClass(MyBase):
    def my_method(self):
        super().my_method()
        print("Hello!")


# %%
yc = YourClass()
yc.my_method()


# %% [markdown] lang="en"
# # Workshop
#
# See `workshop_950_rpg_dice` to `Factory for RPG Cubes`.

# %% [markdown] lang="en"
# ## RPG dice
#
# In role-playing games, conflicts between players are often decided by rolling
# dice, often multiple dice at the same time. Furthermore games often use
# not only the well known 6-sided dice, but also 4-sided, 8-sided, 20-sided dice, etc.
#
# The number and type of dice is described by the following notation:
#
# ```text
# <number of dice> d <number of sides per die>
# ```
#
# For example, rolling two 6-sided dice is described as `2d6`.
# Sometimes more complex formulas are used: `3d20 + 2d6 - 4`
# means that three 20-sided dice and two 6-sided dice are rolled
# at the same time, and the total sum of numbers is then reduced by 4.
#
# In some games, rolling the lowest or highest number of dice is treated
# in a special way ("catastrophic failure", "critical success").
#
# In the following exercise your task is to implement RPG dice in Python.
# To simplify testing your implementation it might be advisable
# to implement it in an IDE, but it is also possible to write tests as
# assertions in a jupyter notebook.
#
# Write tests for each functionality you implement. How can you deal with the
# randomness in dice rolling? What are the strengths and weaknesses of the strategy
# you have chosen to test?
