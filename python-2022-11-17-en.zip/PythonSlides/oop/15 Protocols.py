# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Protocols</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">15 Protocols.py</div> -->
#
#

# %% [markdown] lang="en"
# # Protocols
#
# With protocols Python supports structural subtyping, i.e., the derivation of
# subtype relationships from the structure of classes (in contrast to nominal subtyping
# where the relationships have to be decalared via inheritance).

# %%
from typing import Protocol, runtime_checkable, SupportsInt


# %%
class MyNumber:
    def __int__(self):
        return 0


# %%
my_number = MyNumber()
int(my_number)

# %%
isinstance(MyNumber, SupportsInt)


# %%
@runtime_checkable
class SupportsCastSpell(Protocol):
    def cast_spell(self, name):
        ...


# %%
@runtime_checkable
class SupportsHit(Protocol):
    def hit(self, who, how):
        ...


# %%
class Mage:
    def __init__(self, name="The Mage"):
        self.name = name

    def cast_spell(self, spell):
        print(f"{self.name} casts a {spell} spell.")


# %%
class Fighter:
    @property
    def name(self):
        return "The Fighter"

    def hit(self, opponent, weapon):
        print(f"{self.name} attacks {opponent} with {weapon}.")


# %%
class Bard:
    def __init__(self, name="The Bard"):
        self.name = name


# %%
p1 = Mage()
p2 = Fighter()
p3 = Bard()

# %%
isinstance(p1, SupportsCastSpell)

# %%
isinstance(p2, SupportsCastSpell)

# %%
isinstance(p3, SupportsCastSpell)

# %%
isinstance(p1, SupportsHit)

# %%
isinstance(p2, SupportsHit)

# %%
isinstance(p3, SupportsHit)


# %%
@runtime_checkable
class HasName(Protocol):
    @property
    def name(self):
        ...


# %%
isinstance(p1, HasName)

# %%
isinstance(p2, HasName)

# %%
isinstance(p3, HasName)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Mini workshop
#
#  - Notebook `workshop_190_inheritance`
#  - Section "Protocols"
