# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Methods</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Methods.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Methods
#
# - Classes can contain methods.
# - Methods are functions that "belong to an object".
# - There is no implicit `this` in Python.
# - Methods are called using "dot-notation": `my_object.method()`.

# %% tags=["keep"]
class MyClass:
    def method(self):
        print(f"Called method on {self}")


# %% tags=["keep"]
my_object = MyClass()
my_object.method()
print(repr(my_object))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We can add a method to move a point to our `Point` class:

# %% tags=["alt"]
# noinspection PyRedeclaration
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def move(self, dx=0.0, dy=0.0):
        self.x += dx
        self.y += dy


# %% tags=["keep"]
def print_point(p):
    print(f"Point: x = {p.x}, y = {p.y}")


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
p = Point(2, 3)
print_point(p)

# %%
p.move(3, 5)
print_point(p)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Workshop: Motor Vehicles (Part 2)
#
# In Part 1 we defined the following class `MotorVehicle`:


# %% lang="en" tags=["keep"]
class MotorVehicle:
    def __init__(self, manufacturer, license_plate):
        self.manufacturer = manufacturer
        self.license_plate = license_plate


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Extend the `MotorVehicle` class with a method
# `change_registration(self, new_license_plate)`,
# which changes the vehicle's license plate.


# %% lang="en" tags=["alt"]
class MotorVehicle:
    def __init__(self, manufacturer, license_plate):
        self.manufacturer = manufacturer
        self.license_plate = license_plate

    def change_registration(self, new_license_plate):
        self.license_plate = new_license_plate

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We can use the following function to print vehicles:


# %% lang="en" tags=["keep"]
def print_motor_vehicle(vehicle: MotorVehicle):
    print(
        f"Motor vehicle: {vehicle.manufacturer} "
        f"with license plate {vehicle.license_plate!r}"
    )


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We can then again create the following instances:

# %% lang="en" tags=["keep"]
bmw_en = MotorVehicle("BMW", "M-BW 123")
bmw2_en = MotorVehicle("BMW", "M-BW 123")
vw_en = MotorVehicle("VW", "WOB-VW 246")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Change the registration of the VW generated above so that it has the new
# license plate  "BGL-A 9". How can you tell if changing the registration
# resulted in the change you wanted?

# %% lang="en"
vw_en.change_registration("BGL-A 9")

# %% lang="en"
assert vw_en.license_plate == "BGL-A 9" and vw_en.manufacturer == "VW"
# or
print_motor_vehicle(vw_en)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Change the registration of the BMW saved in `bmw` (to the new registration
# number "F-B 21"). Does the change affect the car saved in `bmw2`?

# %% lang="en"
bmw_en.change_registration("F-B 21")

# %% lang="en"
print_motor_vehicle(bmw_en)
print_motor_vehicle(bmw2_en)
