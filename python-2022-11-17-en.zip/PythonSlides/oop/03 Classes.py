# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Classes</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Classes.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Custom data types
#
# Let us now turn to the definition of user-defined data types (classes):

# %%
class PointV0:
    pass


# %% [markdown] lang="en"
#
# Class names are in pascal case (i.e. capital letters separate components of
# names), e.g. `MyVerySpecialClass`.

# %% [markdown] lang="en"
#
# In the following we will use
# [Python Tutor](https://tinyurl.com/python-classe-point-v0) to implement
# the `Point` class.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Instances of custom classes are created by calling the class name as a function.
# Some built-in operators and Functions can be used without extra effort:


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
p1 = PointV0()
p1

# %%
print(p1)

# %%
p2 = PointV0()
p1 == p2

# %%
# Fehler
# p1 < p2

# %% [markdown] lang="en"
#
# Much like dictionaries can be assigned new entries, one can assign new *attributes*
# to user-defined data types, but the `.` notation is used instead of the indexing
# notation `[]`:

# %%
# Möglich, aber nicht gut... / Possible but not good...
p1.x = 1.0
p1.y = 2.0
print(p1.x)
print(p1.y)


# %%
# Error!
# p2.x

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Unlike dictionaries, we typically *do not* create any *new* attributes for an
# instance after creation!
#
# Instead, all instances should have the same shape. We initialize all attributes of
# an object when it is constructed. This can be done with the `__init__()` method.
#
# The `__init__()` method always has (at least) one parameter, named `self` by
# convention:

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
class PointV1:
    def __init__(self):
        self.x = 0.0
        self.y = 0.0


# %%
def print_point(name, p):
    print(f"{name}: x = {p.x}, y = {p.y}")


# %%
p1 = PointV1()
p2 = PointV1()
print_point("p1", p1)
print_point("p2", p2)

# %%
p1 == p2

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The values of attributes can be changed:

# %%
p1.x = 1.0
p1.y = 2.0
print_point("p1", p1)
print_point("p2", p2)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# In many cases, when constructing an object, we would like to specify the attributes
# of the instance. This is made possible by passing additional arguments to the
# `__init__()` method.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
class PointV2:
    def __init__(self, x, y):
        self.x = x
        self.y = y


# %%
p1 = PointV2(2.0, 3.0)
p2 = PointV2(0.0, 0.0)
print_point("p1", p1)
print_point("p2", p2)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# # Motor Vehicles (Part 1)
#
# Define a class `MotorVehicle` whose instances describe motor vehicles.
# Every car should have attributes `manufacturer` and `license_plate`.


# %% lang="en"
class MotorVehicle:
    def __init__(self, manufacturer, license_plate):
        self.manufacturer = manufacturer
        self.license_plate = license_plate


# %% [markdown] lang="en"
# Create two motor vehicles:
# - a BMW with license plate "M-BW 123"
# - a VW with license plate "WOB-VW 246"
# and store them in variables `bmw` and `vw`

# %% lang="en"
bmw_en = MotorVehicle("BMW", "M-BW 123")
vw_en = MotorVehicle("VW", "WOB-VW 246")

# %% [markdown] lang="en"
# Create a new instance of `MotorVehicle` with manufacturer BMW and registration number
# "M-BW 123" and store it in a variable `bmw2`.

# %% lang="en"
bmw2_en = MotorVehicle("BMW", "M-BW 123")

# %% [markdown] lang="en"
#
# How can you determine whether `bmw` and `bmw2` (or `bmw` and `vw`) describe
# the same vehicle?

# %% lang="en"
(
    bmw_en.manufacturer == vw_en.manufacturer
    and bmw_en.license_plate == vw_en.license_plate
)

# %% lang="en"
(
    bmw_en.manufacturer == bmw2_en.manufacturer
    and bmw_en.license_plate == bmw2_en.license_plate
)
