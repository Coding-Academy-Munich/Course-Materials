# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>User-defined Modules</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 User-defined Modules.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# - The Python interpreter provides only a small part of the functionality needed for
#   most programs:
#   - No interaction with the operating system
#   - No network functionality
#   - No GUI
#   - ...
# - Additional functionality can be loaded using *modules* and *packages*.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Import a package

# %%
import os

# %% [markdown] lang="en"
#
# Use the functionality: get the current working directory

# %%
os.getcwd()

# %% [markdown] lang="en"
#
# List current directory:

# %%
os.listdir(os.getcwd())

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Python provides many standard modules that are installed with the interpreter:
#
#  - abc: Abstract base classes
#  - argparse: command line arguments
#  - asyncio: Asynchronous programming
#  - collections: container data types
#  - ...
#
#  [Here](https://docs.python.org/3/py-modindex.html) is a more complete list.

# %%
{"num-cpus": os.cpu_count(), "pid": os.getpid()}

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Internal representation of code in the Python interpreter:


# %%
import ast

# %%
ast.dump(ast.parse("print(123)"), False)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## User-defined modules
#
# A user-defined module is simply a file containing Python code.
#
# As we have already seen:
# - If a Python module is in the search path, it can be loaded with `import`.
# - Jupyter notebooks cannot be loaded (without additional packages) as modules.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
# Welche Python-Dateien gibt es im aktuellen Verzeichnis?
for filename in os.listdir(os.getcwd()):
    if filename[-3:] == ".py":
        print(filename)

# %% [markdown] lang="en"
#
# View the source code of `my_test_module.py`

# %% tags=["keep"]
# # %pycat my_test_module.py

# %% [markdown] lang="en"
#
# Another way to view the source code:

# %%
with open("my_test_module.py", "r") as file:
    text = file.read()

print(text)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Loading Modules
#
# - The `import` statement loads the file associated with the module
# - Top-level code is executed
# - The module is stored in a cache

# %% tags=["keep"]
# noinspection PyUnresolvedReferences
import my_test_module


# %%
# Top-level code wird NICHT mehr ausgeführt
import my_test_module


# %%
my_test_module.add1(2)


# %%
# add1


# %%
import my_test_module as mm

# %%
mm.add1(1)


# %%
mm.perform_complex_computation(17)


# %%
from my_test_module import multiply_by_2


# %%
multiply_by_2(2)


# %%
from my_test_module import multiply_by_2 as mult2


# %%
mult2(4)


# %%
# Im Regelfall besser vermeiden:
from my_test_module import *


# %%
multiply_by_2(3)


# %%
add1(3)


# %%
# Anzeigen aller definierten Namen:
dir(my_test_module)


# %%
[name for name in dir(my_test_module) if name[0] != "_"]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Sidebar: Automatic reload of modules
#
# In IPython (and thus Jupyter Notebooks) it is possible to activate the automatic
# loading of modified modules:

# %% tags=["keep"]
# %load_ext autoreload
# %autoreload 2

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# In startup scripts, one can avoid syntactical warnings by using instead:

# %% tags=["keep"]
try:
    get_ipython().run_line_magic("load_ext", "autoreload")  # noqa
    get_ipython().run_line_magic("autoreload", "2")  # noqa
except NameError:
    pass

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Example: `HttpServer`
#
# The Python interpreter does not have a built-in HTTP server. Using the
# standard library, it is not difficult to write one.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Example: `ModuleTest`
#
# The `ModuleTest` example shows how a program can be composed of several modules.

# %% tags=["keep"]
__name__
