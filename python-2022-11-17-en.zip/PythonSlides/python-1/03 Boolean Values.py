# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Boolean Values</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Boolean Values.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Comparisons, Boolean values

# %% [markdown] lang="en"
# Equality of values is tested with `==`:

# %%
1 == 1

# %%
1 == 2

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# The result of a comparison is a boolean value
#
# - `True`
# - `False`

# %%
type(True)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Equality of numbers

# %%
1 == 1.0

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Caution: Rounding errors!

# %%
1 / 10

# %%
1 / 100

# %%
(1 / 10) * (1 / 10) == (1 / 100)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
0.1 * 0.1

# %%
0.1 - 0.01

# %%
100 * 1.1

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
0.1 * 0.1 == 0.01

# %%
from math import isclose

# %%
isclose(0.1 * 0.1, 0.01)

# %%
100 * 1.1 == 110

# %%
isclose(100 * 1.1, 110)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Inequality of numbers
#
# The `!=` operator tests whether two numbers are different

# %%
1 != 1.0

# %%
1 != 2

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Comparison of numbers

# %%
1 < 2

# %%
1 < 1

# %%
1 <= 1

# %%
1 > 2

# %%
2 >= 1

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Comparison operators on other types
#
# The comparison operators can also be applied to many other types
# (more details later).

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ### The value `None`
#
# `None` is a value used by Python to indicate the absence of a useful value:
# Jupyter doesn't print `None` as a cell's value:

# %%
None

# %%
print(None)

# %%
type(None)

# %%
x = print("Hello, world!")

# %%
x == None

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The operator `is` is often used to check for `None` values:

# %%
x is None

# %% [markdown] lang="en"
#
# `is` checks for object identity and cannot generally be substituted for `==`.

# %% [markdown] lang="en"
# ## Mini workshop: Comparisons
#
# Is $2^{16}$ larger than $32\,000\,\,/\,\,2$?

# %%
2**16 > (32_000 / 2)

# %% [markdown] lang="en"
# Is $72$ divisible by $3$ without a remainder?

# %%
72 % 3 == 0

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Given the following variable definitions:

# %% tags=["keep"]
var1 = 2**2**4
var2 = 3**12
var3 = 100 * 200 * 300
var4 = 4**3**2

# %% [markdown] lang="en"
#
# Is the maximum of `var1` and `var2` greater than the minimum of `var3` and `var4`?

# %%
max(var1, var2) > min(var3, var4)
