# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Functions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Functions.py</div> -->
#
#

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Functions

# %%
def add_1(n):
    return n + 1


# %%
x = add_1(10)
add_1(20) + x + x

# %%
add_1(5) + add_1(7)


# %%
def my_round(n):
    return int(n + 0.5)


# %% tags=["keep"]
print(my_round(0.5), my_round(1.5), my_round(2.5), my_round(3.5))


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Mini workshop
#
# Write a function `greeting(name)` that prints a greeting in the form
# "Hello *name*!" to the screen, e.g.
# ```python
# >>> greeting("Max")
# Hi Max!
# >>>
# ```

# %%
def greeting(name):
    print("Hallo ", name, "!", sep="")


# %%
greeting("Max")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Methods

# %%
"Foo".lower()

# %%
# 5.bit_length()

# %%
number = 5
number.bit_length()


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Default and keyword arguments

# %%
def say_hi(greeting, name="world", end="."):
    print(greeting + " " + name + end)


# %%
say_hi("Hello")
say_hi("Hi", "Joe")
say_hi("What's up", "Jane", "?")
say_hi("Hello", end="!")
say_hi(name="Jill", greeting="Howdy")


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Type annotations

# %%
def mult(a: int, b: float):
    return a * b


# %%
mult(3, 2.0)

# %%
# Type annotations are only for documentation purposes:
mult("a", 3)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Type annotations can contain parametric types, optional types, etc.
# (*Note:* in older Python versions, `list` cannot take type parameters.)

# %%
from typing import Optional


def my_append(lhs: list[int], rhs: Optional[int]):
    # What exactly does this mean?
    if rhs:
        lhs.append(rhs)


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
my_list = [1, 2, 3]
my_append(my_list, None)
my_list

# %%
my_append(my_list, 4)
my_list
