# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>`while`-loops</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">11 while-loops.py</div> -->


# %% [markdown] lang="en" tags=["private"]
#
# Needs user input!


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # While loops
#
#  Sometimes we want to run a part of a program over and over again:
#
#  - Number of guesses until the right number is found
#  - Physics simulation until the result is accurate enough
#  - Processing of user input in interactive programs
#
#  When we don't know the number of iterations upfront, we typically
#  use a while loop to do that.

# %% lang="en"
number = 0
while number < 3:
    print(f"Try {number}")
    number += 1  # <==


# %% lang="en" tags=["keep"]
def run_an_experiment(trial_number):
    """Runs an experiment
    Returns True if the experiment was a success, False otherwise.
    """
    print(f"Started trial number {trial_number}...", end="")
    from random import random

    if random() > 0.8:
        print("Success!")
        return True
    else:
        print("Failure.")
        return False


# %% lang="en" tags=["keep"]
experiment_nr = 0

while not run_an_experiment(experiment_nr):
    experiment_nr += 1

print("We have completed a successful experiment.")

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Terminating loops
#
# Sometimes it's easier to determine whether to terminate a loop inside the body
# rather than in the loop condition. With the `break` statement you can
# exit a loop early:

# %% lang="en" tags=["keep"]
i = 1
while i < 10:
    print(i)
    if i % 3 == 0:
        break
    i += 1
print("After the loop:", i)


# %%
def annoy_user():
    while True:
        text = input("Say hi! ")
        if text.lower() == "hi":
            break
        else:
            print("You chose", text)


# %%
# annoy_user()

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Guessing games
#
# The following simple "games" allow the player unlimited number of
# inputs. Therefore, it makes sense to use a while loop
# to implement them.
#
# ### Guess a word
#
# Implement a function `guess_word(solution)` that prompts the user for a word and
# keeps asking until the word typed by the user matches `solution`.

# %% lang="en"
def guess_word(solution):
    guess = input("Please enter a word: ")
    while guess != solution:
        guess = input("Try again: ")
    print("That's correct!")


# %% lang="en"
# guess_word("Home")

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Number guesses
#
# Implement a function `guess_number(solution)` that asks the user for a number
# and keeps asking until the user has guessed the solution. After every input
# the function should display whether the entered number is too big, too small
# or the correct number.

# %% lang="en"
def guess_number(solution):
    geratene_zahl = input("Please enter a number: ")
    while int(geratene_zahl) != solution:
        if int(geratene_zahl) < solution:
            print(f"{geratene_zahl} is too small.")
        else:
            print(f"{geratene_zahl} is too large.")
        geratene_zahl = input("Please try again: ")
    print("You won!")


# %% lang="en"
# guess_number(23)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# How do you have to modify your solution to allow the player to input
# an empty string to abort the game?

# %%
def rate_zahl_1(lösung):
    geratene_zahl = input("Bitte geben Sie eine Zahl ein: ")
    while geratene_zahl and int(geratene_zahl) != lösung:
        if int(geratene_zahl) < lösung:
            print(f"{geratene_zahl} ist zu klein.")
        else:
            print(f"{geratene_zahl} ist zu groß.")
        geratene_zahl = input("Bitte versuchen Sie es noch einmal: ")
    if geratene_zahl:
        print("Sie haben gewonnen!")
    else:
        print("Aufgeben ist feige!")


# %%
# rate_zahl_1(23)

# %% [markdown] lang="en" tags=["subslide", "alt"] slideshow={"slide_type": "subslide"}
# Solution using the `classify_number` function

# %% [markdown] lang="en" tags=["subslide", "alt"] slideshow={"slide_type": "subslide"}
# Solution using the `classify_number` function

# %% lang="en"
def klassifiziere_zahl(geratene_zahl, lösung):
    if geratene_zahl < lösung:
        return False, "Die geratene Zahl ist zu klein! "
    elif geratene_zahl > lösung:
        return False, "Die geratene Zahl ist zu groß! "
    else:
        return True, "Sie haben gewonnen!"


# %% lang="en"
def rate_zahl_2(lösung):
    geratene_zahl = input("Bitte geben Sie eine Zahl ein: ")
    erfolg, hinweis = klassifiziere_zahl(int(geratene_zahl), lösung)
    while not erfolg:
        geratene_zahl = input(hinweis)
        erfolg, hinweis = klassifiziere_zahl(int(geratene_zahl), lösung)
    print("Sie haben gewonnen!")


# %% lang="en"
# rate_zahl_2(23)
