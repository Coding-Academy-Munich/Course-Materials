# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Iteration Patterns (Part 3)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">11 Iteration Patterns (Part 3).py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Filtering lists

# %% lang="en"
result = []
for item in [1, 2, 3, 4, 5, 6]:
    if item % 2 == 0:
        result.append(item)
result

# %% lang="en"
result = []
for item in ["abc", "def", "asd", "qwe", "bab"]:
    if "ab" in item:
        result.append(item)
result

# %% [markdown] lang="en"
# # Mini-Workshop: Filtering lists
#
# Given the following list of numbers:

# %% lang="en" tags=["keep"]
numbers = [1, 183, 7, 4, 87, 10, 23, -12, 493, 11]

# %% [markdown] lang="en"
# Create a new list containing all numbers in `numbers` that are greater than 10.

# %% lang="en"
result = []
for n in numbers:
    if n > 10:
        result.append(n)
result


# %% [markdown] lang="en"
#
# Write a function `numbers_greater_than_10(numbers)` that returns a list containing
# the numbers from `numbers` that are greater than 10.

# %% lang="en"
def numbers_greater_than_10(numbers):
    result = []
    for n in numbers:
        if n > 10:
            result.append(n)
    return result


# %% lang="en"
assert numbers_greater_than_10(numbers) == [183, 87, 23, 493, 11]
