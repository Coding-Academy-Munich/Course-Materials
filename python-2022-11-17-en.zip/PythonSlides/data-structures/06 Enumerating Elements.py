# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Enumerating Elements</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Enumerating Elements.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Enumerating Elements
#
# In some cases it is helpful to have both the index of the current element as well
# as the element itself available when iterating over a list.
#
# An example of this is the `find()` function discussed earlier.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Finding items (again)
#
# Our previous version of `find` had to go through the list twice:
#
# - Once to test if the item you are looking for is in the list
# - Once to find the index
#
# It would be nicer if we could do it in one go.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The `enumerate()` function takes a list as argument and returns an iterable
# consisting of `(index, element)` pairs:


# %% tags=["keep"]
my_list = ["a", "b", "c", "d", "e"]

# %%
enumerate(my_list)

# %%
list(enumerate(my_list))

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
for index, element in enumerate(my_list):
    print(f"index = {index}, element = {element}")

# %%
for pos, element in enumerate(my_list, 1):
    print(f"Pos = {pos}, element = {element}")


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def find(element, a_list):
    for index, list_entry in enumerate(a_list):
        if list_entry == element:
            return index
    return None


# %% tags=["alt"]
def find(element, a_list):
    result = None
    for index, list_entry in enumerate(a_list):
        if list_entry == element:
            result = index
            break
    return result


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
my_list = ["a", "b", "c", "d", "a"]

# %%
find("a", my_list)

# %%
find("d", my_list)

# %%
find("x", my_list)

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
assert find("a", my_list) == 0
assert find("d", my_list) == 3
assert find("x", my_list) is None


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Finding the last Element
#
# Write a function `find_last(element, a_list: list)` that returns the index of the
# last occurrence of `element` in `a_list`, or `None` if the element does not appear
# in the list.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Run through all the items in the list
# - If the current element is equal to the element searched for, save the index
# - After all elements have been traversed: return the saved index
# - (Return None if no index was found)


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def find_last(element, a_list: list):
    last_index = None
    for index, list_entry in enumerate(a_list):
        if list_entry == element:
            last_index = index
    return last_index


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
values = [1, 3, 2, 3, 1, 1]

# %% tags=["keep"]
assert find_last(1, values) == 5
assert find_last(2, values) == 2
assert find_last(3, values) == 3
assert find_last(4, values) is None


# %% tags=["alt"]
def find_last_rev(element, a_list: list):
    for back_offset, list_entry in enumerate(reversed(a_list), 1):
        if list_entry == element:
            return len(a_list) - back_offset
    return None


# %% tags=["alt"]
assert find_last_rev(1, values) == 5
assert find_last_rev(2, values) == 2
assert find_last_rev(3, values) == 3
assert find_last_rev(4, values) is None
