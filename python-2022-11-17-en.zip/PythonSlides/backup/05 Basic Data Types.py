# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Basic Data Types</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Basic Data Types.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Parts of a program
#
# We want to write a program that outputs
#
# ```
# Hello world!
# ```
#
# on the screen.
#
# What do we need for this?

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# What do we need for this?
#
# - Data
#     - the text `Hello, world!`
# - Instructions
#     - *Output the following text on the screen*
# - Comments
#     - Notes for the programmer, are ignored by Python

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Comments
#
# - `#` followed by any text
# - to the end of the line

# %% tags=["keep"]
# Das ist ein Kommentar.
# Alle Zeilen in dieser Zelle werden
# von Python ignoriert.


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Data
#
# - Numbers: `123`, `3.141592`
# - Text (strings): `'This is a text'`, `"Hello, world!"`

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
123

# %%
1 + 2

# %%
3.141592

# %%
2.1 + 3.8

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
# fmt: off
3,141592

# %%
2,1 + 3,8
# fmt: on


# %%
"Hello, world!"

# %% lang="en"
# fmt: off
'This is a text'
# fmt: on

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
"1"

# %%
"1" + "2"

# %% lang="en"
"""Some text,
spanning multiple lines."""

# %% lang="en" tag=["del"]
"Literal strings " "can be concatenated " "by juxtaposition"


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Displaying values with the `print()` function
#
# To display values you can use the `print()` function:
#
# `print(...)` prints the values between the trailing parens on the screen.

# %%
print(123)

# %%
print("Hello, world!")

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# Multiple arguments can be passed to a `print()` function call:
# - The arguments are separated by commas
# - All arguments are printed on one line, with spaces between arguments.

# %%
print("Der Wert von 1 + 1 ist", 1 + 1, ".")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# By supplying a *named argument* `sep=''`, the spaces in the output are
# suppressed:

# %%
print("Der Wert von 1 + 1 ist", 1 + 1, ".", sep="")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Any other strings are also allowed as the value of the `sep` argument:

# %%
# CSV (don't do this!)
print(1, 3, 7.5, 2, sep=",")

# %%
# Uh, oh
print(1, 3, 7.5, 2, "who, me?", sep=",")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# With the argument `end` you can determine which string is output at the end of
# the line:

# %%
print("a", end=", ")
print("b", end=", ")
print("c")

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mini-Workshop: Basic Data Types

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# How can you represent the string `Hello, world!` in Python?

# %% tags=["keep"]
"Hello, world!"

# %% [markdown] lang="en"
# How can you output the string `Hello, World!` to the screen?

# %% tags=["keep"]
print("Hello, World!")

# %% [markdown] lang="en"
# How can you represent your name as text (string) in Python?

# %%
"Matthias"

# %% [markdown] lang="en"
#
# How can you represent the number 123 in Python?

# %%
123

# %% [markdown] lang="en"
# How can you output your name to the screen?

# %%
print("Matthias")

# %% [markdown] lang="en"
# How can you print the number 123 to the screen?

# %%
print("Matthias")

# %% [markdown] lang="en"
# How can you output
#
# ```
# 130 grams of flour
# 250ml milk
# 1 tbsp vanilla sugar
# 1 pinch of salt
# ```
#
# to the screen?

# %%
print("130 g   Mehl")
print("250 ml  Milch")
print("1 EL    Vanillezucker")
print("1 Prise Salz")

# %% tags=["alt"]
# Alternativ:
# fmt: off
print("130 g   Mehl", "250 ml  Milch", "1 EL    Vanillezucker", "1 Prise Salz",
      sep="\n")
# fmt: on

# %% tags=["alt"]
# Alternativ:
print(
    """130 g   Mehl
250 ml  Milch
1 EL    Vanillezucker
1 Prise Salz"""
)

# %% tags=["alt"]
# Alternativ:
# fmt: off
print("130 g   Mehl\n"
      "250 ml  Milch\n"
      "1 EL    Vanillezucker\n"
      "1 Prise Salz")  # fmt: on
