# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Functions (Part 3)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">12 Functions (Part 3).py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Functions without parameters
#
# - A function can also be defined without formal parameters.
# - The parentheses must be used in the definition and in calls.

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
def zero():
    return 0


# %% lang="en"
zero()

# %% lang="en"
# Error: 'call' without brackets
zero

# %% lang="en"
# Error: 'call' without parentheses
# zero + 1


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Functions with side effects
#
# Functions can
#
# - Calculate values: `round(3.3)`
# - Have side effects: `print("Hans")`

# %%
round(3.3)

# %%
print("Hans")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# This also applies to user-defined functions:

# %%
def add1(x):
    return x + 1


# %%
add1(10)

# %%
def say_hi(name):
    print("Hi", name)


# %%
say_hi("John")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### The return value `None`
#
# - The return value of the `print()` function is the special value `None`.
# - This value is not displayed *as a result* by the notebook.
# %%
say_hi("Hans")

# %%
x = say_hi("Hans")
x is None

# %%
print(None)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - Functions can have side effects
#     - E.g. by calling `print`
# - These are executed when a function call is evaluated
# - Even functions with side effects return a value
#     - Often this is the special value `None`
#     - If a function returns `None` we don't need an explicit `return` statement

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def say_hello():
    print("Hello, world!")
    print("Today is a great day!")


# %%
say_hello()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Pirates (Part 2)
#
# In a previous task, we calculated the loot split for your pirate crew as
# follows:
#
# - The loot is divided evenly among all pirates. Only whole gold doubloons are
#   paid out.
# - The captain receives the rest of the gold doubloons.


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# But now your pirate crew is in danger of mutiny because the calculation of the spoils
# takes too long.
#
# Write a function `print_division_of_loot(doubloons, pirates)`,
# which calculates the split and prints it in the following format:
#
# ```
# Pirates: 8
# Gold Doubloons: 17
# Each pirate gets: 2 gold doubloon(s)
# Captain gets extra: 1 gold doubloon(s)
# ```

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
def print_division_of_loot(doubloons, pirates):
    doubloons_per_pirate = doubloons // pirates
    doubloons_captain = doubloons % pirates
    print("Pirates:", pirates)
    print("Gold doubloons:", doubloons)
    print("Each pirate gets:", doubloons_per_pirate, "gold doubloon(s)")
    print("Captain gets extra:", doubloons_captain, "gold doubloon(s)")


# %% lang="en"
print_division_of_loot(17, 8)
