# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>List Properties</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">15 List Properties.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Properties of lists
#
# - Lists can store arbitrary Python values
# - Elements in a list have a fixed order
# - Elements of a list can be accessed by index
# - Lists can be modified
#
# Lists can contain elements of different types, but most lists contain elements of a
# single type.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Number of occurrences of elements

# %% tags=["keep"]
numbers = [1, 1, 2, 1, 3, 2, 1]

# %%
numbers.count(1)

# %%
numbers.count(4)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Finding the position of an element

# %% tags=["keep"]
my_list = ["a", "b", "c", "d", "b", "d", "b"]

# %%
my_index = my_list.index("b")
my_index

# %%
my_list[my_index]


# %%
# Fehler
# [1, 3, 5].index(2)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Mini workshop:
#
# The `index` method throws an exception if the searched object does not
# appear in the list. Write a function
# ```
# find(item, a_list: list)
# ```
#
# - which returns an index if the element `element` is in the list, and
# - returns `None` if it is not

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def find(element, a_list: list):
    if element in a_list:
        return a_list.index(element)
    else:
        return None


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
my_list = ["a", "b", "c", "d", "e"]

# %% tags=["keep"]
assert find("a", my_list) == 0

# %% tags=["keep"]
assert find("d", my_list) == 3

# %% tags=["keep"]
assert find("x", my_list) is None
