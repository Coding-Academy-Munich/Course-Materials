# %% tags=["keep"]
from dataclasses import dataclass

# %% tags=["keep"]
@dataclass
class Project:
    name: str
    assets: float
