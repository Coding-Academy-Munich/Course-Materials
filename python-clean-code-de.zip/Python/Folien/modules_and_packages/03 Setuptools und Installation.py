# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Setuptools und Installation</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Setuptools und Installation.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_190_setuptools/topic_110_a5_setuptools_and_installation.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
#  # Setuptools: Distribution von Python Packeten
#
#  - Setuptools sind das Standard-Tool um installierbare Python-Pakete zu erzeugen.
#  - Das Wort "Packages" ist in der Python Welt überladen:
#      - Sammlung von Python Dateien wie im Kapitel über Module und Packages beschrieben.
#      - Distribution einer installierbaren Version einer Bibliothek ("wheel"), die dann importiert werden kann.

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
#  ### Beispiel: Erstellen einer Anwendung mit Bibliothek
#
#  - Hinzufügen von `setup.cfg` und `pyproject.toml`-Dateien mit Information über die zu installierenden Packages und Skripte
#  - Hinzufügen einiger Hilfsdateien (`README.md`, `LICENSE`)
#  - Erstellen der Distribution mit `python -m build` (Benötigt das PyPA `build` [package](https://github.com/pypa/build))
#  - Installation mit `pip` und dem generierten Wheel
#  - Installation während der Entwicklung: `pip install -e .`

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Workshop
#
# - `Workshop_136_todo_list_v3`
# - Abschnitt "Packaging"
