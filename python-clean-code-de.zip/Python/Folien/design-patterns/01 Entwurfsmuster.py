# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Entwurfsmuster</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Entwurfsmuster.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_210_design_patterns/topic_110_patterns_intro.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Entwurfsmuster


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# # Entwurfsmuster
#

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Grundlagen
#
# Dasselbe (bewährte) Lösungsmuster kann für Probleme, die einander
# ähnlich sind, wiederverwendet werden.
#
# <img src="img/pattern.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Vorteile
#
# -   Wiederverwendung von erprobten Lösungsprinzipien
#     (Qualität, Kostenersparnis)
#
# -   abstrakte Dokumentation von Entwürfen
#
# -   gemeinsames Vokabular zur (schnellen) Verständigung unter
#     Entwicklern
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Nachteile
#
# -   Oftmals erhöhte Komplexität
#
# -   Oftmals weniger statische Information
#
# -   Oftmals geringere Performance
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Architekturpattern (C. Alexander)
#
# **Window Place**
#
# Everybody loves window seats, bay windows, and big windows with low
# sills and comfortable chairs drawn up to them...
#
# A room which does not have a place like this seldom allows you to feel
# comfortable or perfectly at ease...
#
# If the room contains no window which is a "place," a person in the room
# will be torn between two forces: 1. He wants to sit down and be
# comfortable. 2. He is drawn toward the light. Obviously, if the
# comfortable places---those places in the room where you most want to
# sit---are away from the windows, there is no way of overcoming this
# conflict...
#
# Therefore: In every room where you spend any length of time during the
# day, make at least one window into a "window place."
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### What is a pattern? (C. Alexander)
#
# Each pattern is a three-part rule, which expresses a relation between a
# certain **context**, a **problem**, and a **solution**.
#
# As an element **in the world**, each pattern is a relationship between a
# certain **context**, a certain system of **forces** which occurs
# repeatedly in that context, and a certain spatial configuration which
# allows these forces to resolve themselves.
#
# As an element of **language**, a pattern is an instruction, which shows
# how this spatial configuration can be used, over and over again, to
# resolve the given system of forces, wherever the context makes it
# relevant.
#
# The pattern is, in short, at the same time a thing, which happens in the
# world, and the **rule** which tells us how to create that thing, and
# when we must create it. It is **both a process and a thing**; both a
# description of a thing which is alive, and a description of the process
# which will generate that thing.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Komponenten eines Patterns
#
# <img src="img/pattern-components.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Geschichte
#
# -   1977 Alexander: Architekturmuster für Gebäude und Städtebau
#
# -   1980 Smalltalks MVC-Prinzip (Model View Controller)
#
# -   Seit 1990 Objektorientierte Muster im Software-Engineering
#
# -   1995 Design Pattern Katalog von Gamma, Helm, Johnson, Vlissides
#     ("Gang of Four", GoF)
#
# -   Martin Fowler (1996). Analysis Patterns
#
# -   Frank Buschmann et al. (1996-2007(?)). Pattern-Oriented Software
#     Architecture, Volumes 1--5
#
# -   Martin Fowler (2002). Patterns of Enterprise Application
#     Architecture
#
# -   Gregor Hohpe, Bobby Woolf (2003). Enterprise Integration Patterns:
#     Designing, Building, and Deploying Messaging Solutions
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Arten von Pattern
#
# Pattern können in verschiedenen Abstraktionsgraden definiert werden:
#
# -   Architektur-Pattern: Beschreiben die komplette Architektur eines
#     Systems
#     Beispiele: Geschichtete Architektur, "Pipes und Filter" Architektur
#
# -   Design-Pattern: Beschreiben Lösungen für Design-Probleme auf einer
#     niedrigeren Abstraktionsebene als Architektur-Pattern
#     Beispiele: Singleton, Abstract Factory, Composite
#
# -   Idiome: Beschreiben Sprachspezifisch Lösungen.
#     Beispiele: Smart Pointers (C/C++), Resource Allocation is
#     Initialization (RAII, C++)
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Beispiel: GUI in Smalltalk 80
#
# <img src="img/smalltalk-80.jpg"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### MVC Architektur
#
# Smalltalk 80 war eine der ersten graphischen Programmierumgebungen. Um
# die Entwicklung graphischer Oberflächen zu vereinfachen wurde in den
# 1980er Jahren in Smalltalk 80 die Model-View-Controller
# (MVC)-Architektur eingeführt.
#
# Es wurden viele Varianten des ursprünglichen MVC Patterns vorgeschlagen
# (e.g., Model-View-Presenter, Model-Document-Abstraction,
# Model-View-Viewmodel). Leider werden viele dieser Varianten oft
# ebenfalls als MVC-Pattern bezeichnet.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### MVC Architektur
#
# **Name:** Model-View-Controller
# **Kontext:**
# Sie entwickeln eine Applikation mit graphischer Benutzeroberfläche und
# wollen Benutzeroberfläche und Geschäftslogik unabhängig voneinander
# halten.
# **Problem:**
# Wenn man den Code, der die Benutzeroberfläche verwaltet direkt in die
# Geschäftslogik einer Anwendung einbettet erhält man Anwendungen, deren
# eigentliche Funktionalität eng mit der Präsentation der Daten verwoben
# ist. Das Erschwert die Unterstützung verschiedener Plattformen und
# verkompliziert die Geschäftslogik.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### MVC Architektur
#
# **Lösung:**
# Spalte die Anwendung in drei Arten von Objekten/Komponenten auf:
#
# -   Das *Modell* ist verantwortlich dafür, die Geschäftsprozesse und
#     Domänenobjekte abzubilden, und es verarbeitet die Daten entsprechend
#     den geschäftsspezifischen Anforderungen. Das Modell hängt nicht von
#     spezifischen Ein-Ausgabeverhalten oder Benutzeroberflächen ab.
#
# -   *View*-Komponenten sind für die graphische Darstellung der Daten
#     verantwortlich. Sie erhalten die anzuzeigenden Daten vom Modell.
#     Mehrere Views können die gleichen Daten des Modells darstellen.
#
# -   Jede View hat einen oder mehrere *Controller*, die Eingaben vom
#     Benutzer bekommen. Diese Eingaben werden in Events für die View oder
#     das Modell umgewandelt. Jegliche Benutzerinteraktion wird durch
#     Controller geregelt.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### MVC Architektur
#
# **Struktur:** (Kein UML Diagramm!)
#
# <img src="img/mvc.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### MVC Architektur
#
# **Interaktion (Kommunikationsdiagramm):**
#
# <img src="img/mvc_ia.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### MVC Architektur
#
# **Konsequenzen:**
#
# -   Modell und Benutzeroberfläche sind vollständig entkoppelt
#
# -   Es können leicht verschiedene Benutzeroberflächen für die gleiche
#     Geschäftslogik erstellt werden
#
# -   Das Modell muss einen generischen Notifikationsmechanismus
#     bereitstellen um Views und Controller über Änderungen informieren zu
#     können
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Web-MVC Architektur
#
# <img src="img/web-mvc.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Web-MVC Architektur
#
# Viele andere Architekturen wurden in der Literatur ebenfalls als
# MVC-Architektur bezeichnet. Z.B. wird in Web-Applikationen oft der
# "Application Controller" im Diagramm auf der vorhergehenden Folie als
# "Controller" bezeichnet. In einer traditionellen MVC-Architektur ist der
# "Application Controller" Teil des Modells und kein Controller.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Alternative zu Web-MVC: Flux
#
# <img src="img/flux.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Alternative zu Web-MVC: Flux
#
# <img src="img/flux-diagram.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Andere Anwendung eines MVC-Artigen Patterns
#
# <img src="img/game-01.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Pattern-Sprachen und -Kataloge
#
# -   Pattern werden zu verschiedenen Zwecken und auf verschiedenen
#     Abstraktionsebenen verwendet
#
# -   Daher gibt es verschiedene "Pattern-Sprachen," die sich in den
#     Elementen unterscheiden, die für jedes Pattern aufgeschrieben werden
#
# -   Typischerweise werden nicht einzelne Pattern aufgeschrieben sondern
#     Sammlungen miteinander verwandter Patterns, die alle in der gleichen
#     Pattern-Sprache notiert sind
#
# -   Eine solche Sammlung von Patterns nennt sich Pattern-Katalog
#
# -   Pattern-Kataloge existieren für verschiedenartige Themengebiete
#
#     -   Analyse, Software-Design, ...
#
#     -   Enterprise-Architektur, verteilte Systeme, ...
#
#     -   Programmiersprachen (JavaScript, Smalltalk...)
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Wesentliche Elemente eines Entwurfsmusters
#
# -   Name des Musters
#
# -   Beschreibung der Problemklasse, bei der das Muster anwendbar ist
#
# -   Beschreibung eines Anwendungsbeispiels
#
# -   Beschreibung der Lösung (Struktur, Verantwortlichkeiten, \...)
#
# -   Beschreibung der Konsequenzen (Nutzen/Kosten-Analyse)
#
