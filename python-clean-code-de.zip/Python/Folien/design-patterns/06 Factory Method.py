# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Factory Method</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Factory Method.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_210_design_patterns/topic_240_factory_method.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Factory Method


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Designproblem: Erzeugen von Bonusitems
#
# Während des Spiels werden Bonusitems erzeugt, die der Spieler aufsammeln
# kann.
#
# -   Verschiedenartige Bonusitems sollen verschiedenen Auswirkungen auf
#     den Spieler haben
#
# -   An verschiedenen Orten sollen unterschiedliche Bonusitems erzeugt
#     werden
#
# Die Orte, an denen Bonusitems erzeugt ("gespawned") werden sollen vom
# Level-Designer durch sogenannte Spawn-Volumes festgelegt werden.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Erster Entwurf: Verschiedene Spawn-Volumes
#
# <img src="img/PlantUML/spawn-volume-1.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Factory Method (Creational Pattern)
#
# **Intent**
# Define an interface for creating a certain type of object; let
# subclasses decide which concrete class should be instantiated.
#
# **Motivation**
# Consider an office suite like Microsoft Office or Libre Office. If the
# programs in the suite use a common framework to manage their documents,
# this framework has to provide functionalities for managing documents,
# e.g., opening, closing, or saving them. Each application has a
# particular type of document on which it operates, but many of the
# features provided by the framework are independent of the specific
# document type.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Factory Method (Creational Pattern)
#
# **Applicability**
# Use the Factory Method pattern when
#
# -   A class may have to create an open-ended number of document types.
#
# -   Subclasses should be responsible for creating the concrete types.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Factory Method (Creational Pattern)
#
# **Structure**
#
# <img src="img/PlantUML/pat_factory_method.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Factory Method (Creational Pattern)
#
# **Participants**
#
# -   [Product]{.sans-serif}: The type of object that should be created
#     (often a pure interface)
#
# -   [Concrete Product]{.sans-serif}: Implements the
#     [Product]{.sans-serif} interface
#
# -   [Creator]{.sans-serif}: Declares the Factory Method that returns an
#     instance of [Product]{.sans-serif}. May define a default
#     implementation.
#
# -   [Concrete Creator]{.sans-serif}: Overrides the Factory Method.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Factory Method (Creational Pattern)
#
# **Collaborations**
# [Creator]{.sans-serif} relies on its subclasses to implement the
# required creational method.
# **Consequences**
#
# -   No need for application-specific classes in the framework code.
#
# -   Framework code can work with any user-defined concrete class.
#
# -   Clients need to subclass the [Creator]{.sans-serif} class, thereby
#     coupling parts of the client tightly to the framework.
#
# -   Factory Method provides hooks for subclasses.
#
# **Example** ...
