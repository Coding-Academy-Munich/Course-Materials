# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Observer</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Observer.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_210_design_patterns/topic_210_observer.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Observer


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Designproblem: Unabhängige Item-Erzeuger
#
# -   Bevor das Spiel startet und nach dem Ende des Spiels sollen alle
#     Item-Erzeuger angehalten werden.
#
# -   Der Stand des Spiels wird von einer Instanz der Klasse `UGameMode`
#     verwaltet
#
# -   `UGameMode` soll nichts über Item-Erzeuger wissen, sondern nur die
#     Transitionen zwischen Spiel aktiv/gewonnen/verloren verwalten
#
# -   `APickup` soll nichts über die Funktionalität von `UGameMode` wissen
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Observer (Behavioral Pattern)
#
# **Intent**
# Define a one-to-many dependency between objects so that when one object
# changes state, all its dependents are notified and updated
# automatically.
#
# **Motivation**
# When partitioning a system into collaborating classes it is often
# necessary to maintain consistency between related objects. We don't want
# to have tight coupling between these classes. The Observer pattern
# describes how a *subject* may have any number of *observers* that are
# kept update about changes to the subject.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Observer (Behavioral Pattern)
#
# **Applicability**
# Use the Observer pattern when
#
# -   An abstraction has two aspects and one of them depends on the other.
#
# -   When a change in one object causes change in several others and you
#     don't know exactly how many or which ones.
#
# -   When an Object needs to notify other objects without making
#     assumptions what these objects are.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Observer (Behavioral Pattern)
#
# **Structure**
#
# <img src="img/observerPattern1.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Observer (Behavioral Pattern)
#
# **Participants**
#
# -   Subject
#
#     -   knows its observers. Any number of Observer objects may observe
#         a subject
#
#     -   provides an interface for attaching and detaching Observer
#         objects
#
# -   Observer
#
#     -   defines an updating interface for objects that should be
#         notified of changes in a subject
#
# -   ConcreteSubject
#
#     -   stores state of interest to ConcreteObserver objects
#
#     -   sends a notification to its observers when its state changes
#
# -   ConcreteObserver
#
#     -   maintains a reference to a ConcreteSubject object
#
#     -   stores state that should stay consistent with the subject's
#
#     -   implements the Observer updating interface to keep its state
#         consistent with the subject's
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Observer (Behavioral Pattern)
#
# **Collaborations**
#
# -   ConcreteSubject notifies its observers whenever a change occurs that
#     could make its observers' state inconsistent with its own.
#
# -   After being informed of a change in the concrete subject, a
#     ConcreteObserver object may query the subject for information.
#     ConcreteObserver uses this information to reconcile its state with
#     that of the subject.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Observer (Behavioral Pattern)
#
# <img src="img/observerPattern2.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Observer (Behavioral Pattern)
#
# **Consequences**
#
# The Observer pattern lets you vary subjects and observers independently.
# You can reuse subjects without reusing their observers, and vice versa.
# It lets you add observers without modifying the subject or other
# observers. Further benefits and liabilities of the Observer pattern
# include the following:
#
# -   Abstract coupling between Subject and Observer \[...\]
#
# -   Support for broadcast communication \[...\]
#
# -   Unexpected updates \[...\]
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Observer (Behavioral Pattern)
#
# **Known uses**
# Event listeners in user interfaces (SWT)
#
# **Related Patterns**
#
# -   Mediator (273): By encapsulating complex update semantics, the
#     ChangeManager acts as mediator between subjects and observers
#
# -   Singleton (127): The ChangeManager \[in a variant implementation of
#     the pattern\] may use the Singleton pattern to make it unique and
#     globally accessible
#
