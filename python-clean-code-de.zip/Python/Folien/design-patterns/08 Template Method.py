# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Template Method</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Template Method.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_210_design_patterns/topic_260_template_method.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Template Method


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Designproblem: Bonusitems
#
# -   Wir wollen mehrere Arten von Bonusitems (Pickups) haben, die
#     unterschiedliche Effekte auf den Spieler haben
#
# -   Teile des Verhaltens sollen aber immer gleich bleiben
#
# -   Wir habe die Lösung dieses Problems bereits bei den UML
#     Klassendiagrammen besprochen
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Template Method (Behavioral Pattern)
#
# **Intent**
# Define the skeleton of an algorithm in an operation, deferring some
# steps to subclasses. Template Method lets subclasses redefine certain
# steps of an algorithm without changing the algorithm's structure.
# **Motivation**
#
# -   An application framework that has to deal with several document
#     classes. There are some similarities, but also differences between
#     the handling of various types of documents
#
# -   The framework defines concrete operations that call abstract
#     operations as part of their execution
#
# -   Instances of the framework implement the virtual methods
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Template Method (Behavioral Pattern)
#
# **Applicability**
#
# -   to implement the invariant parts of an algorithm once and leave it
#     up to subclasses to implement the behavior that can vary
#
# -   when common behavior among subclasses should be factored and
#     localized in a common class to avoid code duplication
#
# -   to control subclasses extensions
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Template Method (Behavioral Pattern)
#
# **Structure**
#
# <img src="img/PlantUML/pat_template_method.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Template Method (Behavioral Pattern)
#
# **Participants**
#
# -   AbstractClass:
#
#     -   defines abstract *primitive operations* that concrete subclasses
#         define (hooks)
#
#     -   implements a template method defining the skeleton of an
#         algorithm
#
# -   ConcreteClass: implements the primitive operations
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Template Method (Behavioral Pattern)
#
# **Collaborations**
# ConcreteClass relies on AbstractClass to implement the invariant steps
# of the algorithm
# **Consequences**
# Template Methods are a fundamental technique of code reuse. They lead to
# an inverted control structure sometimes called the "Hollywood
# Principle." It is important for template methods to specify which
# operations *may* and which ones *must* be overridden.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Template Method (Behavioral Pattern)
#
# <img src="img/PlantUML/pat_pickups-01.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Template Method (Behavioral Pattern)
#
# <img src="img/PlantUML/pat_pickups-02.png"
#      style="display:block;margin:auto;width:70%"/>
