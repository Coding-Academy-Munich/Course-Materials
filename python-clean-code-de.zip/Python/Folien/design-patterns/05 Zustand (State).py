# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Zustand (State)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Zustand (State).py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_210_design_patterns/topic_230_state.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Zustand (State)


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Designproblem: Verschiedene Modi
#
# Der Designer hat sich entschieden, dass der Spieler eine Auswahl
# zwischen verschiedenen Figuren haben soll. Um das zu ermöglichen muss
# dass System zwischen zwei "Zuständen" unterscheiden können:
#
# -   Auswahl einer Spielfigur
#
# -   Spielen des eigentlichen Levels
#
# Während des Spielens treten drei (bzw. vier) Unterzustände auf:
#
# -   (Spiel ist in einem undefinierten Zustand)
#
# -   Spiel wird ausgeführt
#
# -   Spieler hat gewonnen
#
# -   Spieler hat verloren
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Designproblem: Verschiedene Modi
#
# <img src="img/PlantUML/game-state-1.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Designproblem: Verschiedene Modi
#
# <img src="img/PlantUML/game-state-2.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### State (Behavioral Pattern)
#
# **Intent**
# Allow an object to alter its behaviour when its internal state changes.
# The object will appear to change its class.
#
# **Also Known As**
# Objects for States
#
# **Motivation**
# TCP-connection object. We use Streams as simpler example.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### State (Behavioral Pattern)
#
# <img src="img/PlantUML/stream-2.png"
#      style="display:block;margin:auto;width:70%"/>

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### State (Behavioral Pattern)
#
# <img src="img/PlantUML/stream-1.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### State (Behavioral Pattern)
#
# **Applicability**
# Use the State pattern in either of the following cases:
#
# -   An object's behavior depends on its state, and it must change its
#     behavior at run-time depending on that state.
#
# -   Operations have large, multipart conditional statements that depend
#     on the object's state. This state is usually represented by one or
#     more enumerated constants. Often, several operations will contain
#     this same conditional structure. The State pattern puts each branch
#     of the conditional in a separate class. This lets you treat the
#     object's state as an object in its own right that can vary
#     independently from other objects.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### State (Behavioral Pattern)
#
# **Structure**
#
# <img src="img/state.png"
#      style="display:block;margin:auto;width:70%"/>
#
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### State (Behavioral Pattern)
#
# **Participants**
#
# -   Context
#
#     -   defines the interface of interest to clients
#
#     -   maintains an instance of a ConcreteState subclass that defines
#         the current state.
#
# -   State
#
#     -   defines an interface for encapsulating the behavior associated
#         with a particular state of the Context
#
# -   ConcreteState subclasses
#
#     -   each subclass implements a behavior associated with a state of
#         the Context
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### State (Behavioral Pattern)
#
# **Collaborations**
#
# -   Context delegates state-specific requests to the current
#     ConcreteState object
#
# -   A context may pass itself as an argument to the State object
#     handling the request. This lets the State object access the context
#     if necessary
#
# -   Context is the primary interface for clients. Clients can configure
#     a context with State objects. Once a context is configured, its
#     clients don't have to deal with the State objects directly
#
# -   Either Context or the ConcreteState subclasses can decide which
#     state succeeds another and under what circumstances.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### State (Behavioral Pattern)
#
# **Consequences**
# The State pattern has the following consequences:
#
# -   It localizes state-specific behavior and partitions behavior for
#     different states.
#
# -   It makes state transitions explicit
#
# -   State objects can be shared
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### State (Behavioral Pattern)
#
# **Implementation and Sample Code** ...
# **Known Uses**
# Realization of state diagrams by state objects.
# **Related Patterns**
# The Flyweight (195) pattern explains when and how State objects can be
# shared.
#
# State objects are often Singletons (127).
