# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Singleton</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 Singleton.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_210_design_patterns/topic_270_singleton.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Singleton


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Designproblem: Eine Instanz des Spiels
#
# -   Das Spiel benötigt mehrere Resourcen die von verschiedenen
#     Subsystemen aus ansprechbar sein sollen
#
#     -   System-Resourcen (Bildschirm/Renderer)
#
#     -   Spielelemente (Figuren, Level)
#
# -   Es soll sichergestellt werden, dass jede Resource nur einmal erzeugt
#     wird und alle Subsysteme auf die gleiche Resource zugreifen
#
# -   Globale Variablen?
#
# -   Statische Attribute?
#
# -   Flexibler: Eine Klasse, die ihre einzige Instanz selber verwaltet.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Singleton (Creational Pattern)
#
# **Intent**
# Ensure a class has only one instance; provide a global point of access
# to it.
# **Motivation**
# Some classes should have exactly one instance, e.g., classes that
# correspond to unique physical resources. This instance should be easily
# accessible. Singleton makes the class itself responsible for keeping
# track of its single instance.
# **Applicability**
# Use the Singleton pattern when
#
# -   there must be exactly one instance of a class, and it must be
#     accessible to clients from a well-known access point
#
# -   the sole instance should be extensible by subclassing, and clients
#     should be able to use an extended instance without modifying their
#     code.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Singleton (Creational Pattern)
#
# **Structure**
#
# ![image](pat_singleton){width="10cm"}
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Singleton (Creational Pattern)
#
# **Consequences**
# The *Singleton* has several benefits:
#
# -   Controlled access to sole instance.
#
# -   Reduced name space.
#
# -   Permits refinement of operations and representation.
#
# -   Permits a variable number of instances.
#
# -   More flexible than class operations.
#
# **Known uses** `java.lang.Runtime`; `org.eclipse.core.runtime.Plugin`.
# **Example** ...
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Singleton (Creational Pattern)
#
# **Consequences**
# The *Singleton* has several benefits:
#
# -   Controlled access to sole instance.
#
# -   Reduced name space.
#
# -   Permits refinement of operations and representation.
#
# -   Permits a variable number of instances.
#
# -   More flexible than class operations.
#
# **Known uses** `java.lang.Runtime`; `org.eclipse.core.runtime.Plugin`.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Singleton (Creational Pattern)
#
# **Example**
#
# ![image](pat_world){width="8cm"}
#
# (**Note:** This is not how the Unreal Engine works.)
