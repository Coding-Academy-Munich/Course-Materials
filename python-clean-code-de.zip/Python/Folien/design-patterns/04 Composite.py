# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Composite</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Composite.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_210_design_patterns/topic_220_composite.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Composite


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Designproblem: Benutzeroberfläche
#
# -   Komponenten in der Benutzeroberfläche haben eine hierarchische
#     Struktur:
#
#     -   Bildschirm
#
#     -   Fenster
#
#     -   Eingabemaske
#
#     -   Eingabefeld, Button, etc.
#
# -   Das Interface der Komponenten soll einheitlich sein
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Composite (Structural Pattern)
#
# **Intent**
# Compose objects into tree structures to represent part-whole
# hierarchies. Composite lets clients treat individual objects and
# compositions of objects uniformly.
#
# **Motivation**
# Graphical editors let users build complex diagrams from simpler
# components. Components can be grouped to form larger components, which
# can themselves be grouped to form even larger components. Code that uses
# these components should not have to distinguish between primitives and
# complex components. The *Composite* pattern describes how to use
# recursive composition so that clients don't have to make this
# distinction.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Composite (Structural Pattern)
#
# **Applicability**
# Use the Composite pattern when
#
# -   You want to represent part-whole hierarchies of objects.
#
# -   You want clients to be able to ignore the difference between
#     compositions of objects and individual objects. Clients will treat
#     all objects in the composite structure uniformly.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Composite (Structural Pattern)
#
# **Structure**
#
# <img src="img/composite.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Composite (Structural Pattern)
#
# **Consequences**
# The *Composite* pattern
#
# -   defines class hierarchies consisting of primitive and composite
#     objects
#
# -   makes the clients simple
#
# -   makes it easier to add new kinds of components
#
# -   can make your design overly general
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Composite (Structural Pattern)
#
# **Known uses** `Composite` and `Control` in SWT, abstract syntax trees
# in compilers, ...
# **Related Patterns**
#
# -   Chain of Command
#
# -   Decorator
#
# -   Iterator
#
# -   Visitor
#
# -   ...
#
# **Example** ...
#
