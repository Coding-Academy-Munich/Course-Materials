# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Abstract Factory</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">07 Abstract Factory.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_210_design_patterns/topic_250_abstract_factory.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Abstract Factory


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Designproblem: Erzeugen von Bonusitems
#
# Zur Erinnerung: Die Orte, an denen Bonusitems erzeugt werden sollen vom
# Level-Designer durch sogenannte Spawn-Volumes festgelegt werden.
#
# **Problem mit dem angegebenen Design**
# Es ist für den Designer nicht möglich, den von einem Spawn-Volume
# erzeugten Objekttyp zu verändern.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Zweiter Entwurf: Konfigurierbares Spawn-Volume
#
# <img src="img/PlantUML/spawn-volume-2.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Zweiter Entwurf: Konfigurierbares Spawn-Volume
#
# Dieser Entwurf erlaubt die Konfiguration des erzeugten Objekts, hat aber
# einige Nachteile:
#
# -   Die Verwendung von Strings zur Angabe des Typs ist fehleranfällig
#     Besser: Verwendung einer Enumeration, aber dann muss für jeden neuen
#     Pickup-Typ die Enumeration angepasst werden
#
# -   Die SpawnPickup()-Methode muss alle Pickup-Typen kennen und per
#     Fallunterscheidung den richtigen Typ auswählen
#
#
#
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Designproblem: Mehrere Bonusitems pro Region
#
# Unser jetziges Design hat einige positive Eigenschaften:
#
# -   Der von einem Spawn-Volume erzeugte Pickup-Typ kann leicht geändert
#     werden
#
# -   Das Hinzufügen von neuen Pickup-Typen geht ohne jede Änderung an der
#     Spawn-Volume Implementierung
#
# Aber: Es ist nicht leicht möglich in einem Spawn-Volume mehrere
# Bonusitem-Typen zu erzeugen.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Vierter Entwurf: Spawn-Volume mit Abstract Factory
#
#
# <img src="img/PlantUML/spawn-volume-5.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Abstract Factory (Creational Pattern)
#
# **Intent**
# Provides an interface for creating families of related or dependent
# objects without specifying their concrete classes.
# **Motivation**
# UI toolkit that supports multiple looks and feels. Widget look and feel
# should not be hard-coded. Define an abstract `WidgetFactory` class that
# provides a uniform interface for creating widgets for different looks
# and feels, instantiate a concrete subclass for each look and feel.
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Abstract Factory (Creational Pattern)
#
# **Applicability**
# Use the Abstract Factory pattern when
#
# -   a system should be independent of how its products are created,
#     composed, and represented
#
# -   a system should be configured with one of multiple families of
#     products
#
# -   a family of related product objects is designed to be used together,
#     and you need to enforce this constraint
#
# -   you want to provide a class library of products, and you want to
#     reveal just their interfaces, not their implementations
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Abstract Factory (Creational Pattern)
#
# **Structure**
#
# <img src="img/abstractFactory.png"
#      style="display:block;margin:auto;width:70%"/>
#
# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ### Abstract Factory (Creational Pattern)
#
# **Consequences**
# The *Abstract Factory* pattern
#
# -   isolates concrete classes
#
# -   makes exchanging product families easy
#
# -   promotes consistency among products
#
# -   makes it difficult to support new kinds of products
#
# -   (significantly) increases code complexity
#
# **Known uses** `Toolkit` in AWT.
# **Related Patterns**
#
# -   Factory Method
#
# -   Prototype
#
# -   Singleton (the factory is often a Singleton)
