# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Schreiben von guten Unit-Tests</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Schreiben von guten Unit-Tests.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_240_unit_testing/topic_160_writing_unit_tests.py</div> -->

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Welche Form hat ein Unit Test?
# - Arrange
# - Act
# - Assert

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def test_the_extend_method_of_the_built_in_list_type():
    x = [1, 2, 3]  # arrange
    y = [10, 20]

    x.extend(y)  # act

    assert x == [1, 2, 3, 10, 20]  # assert


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Wie finden wir gute Tests?

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Versuch: Erschöpfendes Testen
#
# - Wir schreiben erschöpfende Tests, d.h. Tests, die alle möglichen Eingaben eines
#   Programms abdecken

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Erschöpfendes Testen ist nicht möglich
# - Beispiel Passworteingabe:
#   - Angenommen, Passwörter mit maximal 20 Zeichen sind zulässig,
#     80 Eingabezeichen sind erlaubt (große und kleine Buchstaben, Sonderzeichen)
#   - Das ergibt $80^{20}$ = 115.292.150.460.684.697.600.000.000.000.000.000.000
#     mögliche Eingaben
#   - Bei 10ns für einen Test würde man ca. $10^{24}$ Jahre brauchen, um alle Eingaben
#     zu testen
#   - Das Universum ist ungefähr $1.4 \times 10^{10}$ Jahre alt

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Effektivität und Effizienz von Tests
#
# - Unit-Tests sollen effektiv und effizient sein
#   - Effektiv: Die Tests sollen so viele Fehler wie möglich finden
#   - Effizient: Wir wollen die größte Anzahl an Fehlern mit der geringsten Anzahl
#     an möglichst einfachen Tests finden
# - Effizienz ist wichtig, da Tests selbst Code sind, der gewartet werden muss und
#   Fehler enthalten kann

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Strategien zum Finden von (effektiven und effizienten) Tests
#
# - Analyse von Randwerten (Boundary Value Analysis, BVA)
# - Partitionierung
# - Zustandsbasiertes Testen
# - Kontrollflussbasiertes Testen
# - Richtlinien
# - Kenntnis häufiger Fehler in Software
# - (Kenntnis häufiger Probleme von Tests (Test Smells))


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Faustregeln für Unit-Tests
#
# - Teste Funktionalität, nicht Implementierung
# - Verwende Test-Doubles dann (aber auch nur dann), wenn eine Abhängigkeit
#   "eine Rakete abfeuert"
# - Bevorzuge Tests von Werten gegenüber Tests von Zuständen
# - Bevorzuge Tests von Zuständen gegenüber Tests von Verhalten
# - Teste kleine Einheiten
# - (Diese Regeln setzen voraus, dass der Code solche Tests erlaubt)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Teste Funktionalität, nicht Implementierung
#
# Abstrahiere so weit wie möglich von Implementierungsdetails
# - Auch auf Unit-Test Ebene
# - Oft testen sich verschiedene Methoden gegenseitig
# - Dies erfordert manchmal die Einführung von zusätzlichen Methoden
#     - Diese Methoden sind oft nicht nur für Tests sinnvoll
#     - Oft "abstrakter Zustand" von Objekten
#     - **Nicht:** konkreten Zustand öffentlich machen

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Teste Funktionalität, nicht Implementierung
#
# **Warum?**
# - Funktionalität ist leichter zu verstehen
# - Funktionalität ist stabiler als Implementierung
# - Funktionalität entspricht eher dem Kundennutzen

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
class Stack:
    def __init__(self):
        self._items = []

    def push(self, new_item):
        self._items.append(new_item)

    def pop(self):
        return self._items.pop()


# %% tags=["keep"]
my_stack = Stack()
my_stack.push(1)

# %% tags=["keep"]
assert my_stack._items == [1]  # noqa <- This might tell you something :)


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
class Stack:
    def __init__(self):
        self._items = []

    def __len__(self):
        return len(self._items)

    def push(self, new_item):
        self._items.append(new_item)

    def pop(self):
        return self._items.pop()


# %% tags=["keep"]
my_stack = Stack()
my_stack.push(5)

# %% tags=["keep"]
assert len(my_stack) == 1
assert my_stack.pop() == 5


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Test Doubles
#
# - Test Doubles: Stubs, Fakes, Spies, Mocks
# - Ersetzen eine Abhängigkeit im System durch eine vereinfachte Version
#   - z.B. Ersetzen einer Datenbankabfrage durch einen fixen Wert
# - Test Doubles sind wichtig zum Vereinfachen von Tests
# - Aber: zu viele oder komplexe Test Doubles machen Tests unübersichtlich
#   - Was wird von einem Test eigentlich getestet?


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Typischer Einsatz von Test Doubles
#
# - Zugriff auf Datenbank, Dateisystem
# - Zeit, Zufallswerte
# - Nichtdeterminismus
# - Verborgener Zustand (`AdderSpy`)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Werte > Zustand > Verhalten
#
# - Verständlicher
# - Leichter zu testen
# - Oft stabiler gegenüber Refactorings
#
# Ausnahme: Testen von Protokollen


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Wert

# %%
def add(x, y):
    return x + y


# %%
assert add(2, 3) == 5


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Zustand

# %%
class Adder:
    def __init__(self, x, y):
        self.result = x + y


# %%
my_adder = Adder(2, 3)
assert my_adder.result == 5


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Verhalten

# %%
def call_add(add):
    _hidden_result = add(2, 3)
    # Presumably do something with _hidden_result...
    return "How do you test that add was called?"


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
class AdderSpy:
    def __init__(self):
        self.was_called = False
        self.result = None

    def __call__(self, x, y):
        self.was_called = True
        self.result = x + y
        return self.result


# %%
spy = AdderSpy()
assert not spy.was_called

# %%
assert spy(2, 3) == 5

# %%
assert spy.was_called
assert spy.result == 5

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
adder_spy = AdderSpy()
call_add(adder_spy)
assert adder_spy.was_called
assert adder_spy.result == 5

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Teste kleine Einheiten (bei Unit-Tests)
# - Test von kleinen Einheiten
#   - spezifizieren das Verhalten der getesteten Einheit besser
#   - erleichtern die Lokalisierung von Fehlern
#   - sind leichter zu pflegen
# - Tests größerer Einheiten oder des Gesamtsystems sind wichtig als
#   - Integrationstests
#   - Systemtests
#   - Akzeptanztests

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Wie schreibt man testbaren Code?
#
# - Keine globalen oder statischen Daten
# - Techniken aus der funktionalen Programmierung (Iterables, Higher-order Funktionen,
#   etc.)
# - Funktionale Datenstrukturen (Immutability)
# - Gutes objektorientiertes Design
#   - Hohe Kohärenz
#   - Geringe Kopplung, Management von Abhängigkeiten
# - Etc.
#
# Hilfsmittel: Test-Driven Development


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mini-Workshop: Tests für die Einkaufslisten-Implementierung
#
# Fügen Sie zur Implementierung einer Einkaufsliste in `examples/ShoppingListPytestSK`
# geeignete Unit-Tests hinzu.
#
# (Falls Sie die Einkaufsliste in einem vorherigen Workshop bereits implementiert haben,
# ist es besser, Sie verwenden stattdessen Ihre eigene Implementierung.)
