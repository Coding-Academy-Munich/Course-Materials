# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Doctests</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Doctests.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_240_unit_testing/topic_155_doctests.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Doctests
#
# In Docstrings können Tests integriert werden, die von Pytest (oder Doctest)
# ausgeführt werden. Dazu wird eine Code-Zeile mit dem Präfix `>>>` versehen.
# Die Ausgabe, die der Python-Interpreter dafür anzeigen würde, wird in den folgenden
# Zeilen ohne Präfix angegeben:

# %% tags=["keep"]
def add(x, y):
    """Adds two numbers or concatenates two sequences.

    >>> add(2, 3)
    5
    >>> add([1], [2])
    [1, 2]
    >>> add(1, "a")
    Traceback (most recent call last):
    ...
    TypeError: unsupported operand type(s) for +: 'int' and 'str'
    """
    return x + y


# %% tags=["keep"]
import doctest

# %% tags=["keep"]
doctest.testmod()

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mini-Workshop: Doctests
#
# Schreiben Sie Doctests für die `negate()` und `my_abs()` Funktionen in
# `examples/SimplePytestStarterKit`.
