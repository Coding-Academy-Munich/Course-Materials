# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Clean Code: Namen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Clean Code_ Namen.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_230_clean_code/topic_130_a3_names.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Clean Code: Namen
#
# Unterschätze niemals die Macht von Namen!

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Namen sind ein mächtiges Kommunikationsmittel.
# - Sie sind überall im Programm zu finden
# - Sie verbinden den Code mit Domänen-Konzepten.


# %% tags=["keep"]
def foo(a: float, b: float) -> float:
    if b > 40.0:
        raise ValueError("Not allowed!")
    return 40.0 * a + 60.0 * b


# %%
foo(40.0, 3.5)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
REGULAR_PAY_PER_HOUR = 40.0
OVERTIME_PAY_PER_HOUR = 60.0
MAX_ALLOWED_OVERTIME = 40.0


# %%
class TooMuchOvertimeError(ValueError):
    pass


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def compute_total_salary(regular_hours_worked: float,
                         overtime_hours_worked: float) -> float:
    if overtime_hours_worked > MAX_ALLOWED_OVERTIME:
        raise TooMuchOvertimeError(
            f"Not allowed to work {overtime_hours_worked:.1f} hours overtime!")
    regular_pay = regular_hours_worked * REGULAR_PAY_PER_HOUR
    overtime_pay = overtime_hours_worked * OVERTIME_PAY_PER_HOUR
    return regular_pay + overtime_pay


# %%
compute_total_salary(40.0, 3.5)

# %%
# compute_total_salary(20.0, 50.0)

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
from dataclasses import field, dataclass


@dataclass
class BadNames:
    the_list: list = field(default_factory=list)

    def get_them(self):
        list1 = []
        for x in self.the_list:
            if x[0] == 1:
                list1.append(x)
        return list1


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
from enum import IntEnum


class Status(IntEnum):
    FLAGGED = 1
    UNFLAGGED = 2


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
@dataclass
class Cell:
    index: int
    status: Status = Status.UNFLAGGED
    bomb_count: int = 0


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
Board = list[Cell]


def make_board(size=64) -> Board:
    return [Cell(index) for index in range(size)]


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
@dataclass
class MineSweeper:
    board: Board = field(default_factory=make_board)

    def get_flagged_cells(self):
        """Return all flagged cells.

        >>> game = MineSweeper()
        >>> game.board[2].status = Status.FLAGGED
        >>> game.get_flagged_cells()
        [Cell(index=2, status=<Status.FLAGGED: 1>, bomb_count=0)]
        """
        return [cell for cell in self.board if cell.status == Status.FLAGGED]


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Um doctests in einem Notebook auszuführen kann man folgende Anweisungen verwenden:

# %% tags=["keep"]
import doctest

# %% tags=["keep"]
doctest.testmod()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Doctests können mit
#
# ```shell
# $ python -m doctest my_module.py
# ```
# oder
# ```shell
# $ pytest --doctest-modules my_module.py
# ```
#
# ausgeführt werden.

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Wie findet man gute Namen?
#
# - Wähle nach Aussagekraft, nicht nach Bequemlichkeit
# - Verwende Namen, die sagen, was sie bedeuten, und bedeuten, was sie sagen
# - Sonst wird die Wartung viel schwieriger...
# - ... und der größte Teil der Kosten für Software entsteht durch Wartung

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Was ist ein guter Name?
#
# - Beantwortet
#   - Warum gibt es diese Funktion (Klasse, Modul, Objekt...)?
#   - Was macht sie?
#   - Wie wird sie verwendet?
# - Kommuniziert die Intention (ist "intention revealing")
# - (Ist im Allgemeinen nicht leicht zu finden)


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Was ist ein schlechter Name?
#
# - Braucht einen Kommentar
# - Kann nur verstanden werden, wenn man sich den Code ansieht
# - Verbreitet Desinformation
# - Entspricht nicht den Namensregeln

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Clean Code Namensregeln
#
# Gute Namen
#
# - sind selbsterklärend
# - offenbaren die Intention
# - sind aussprechbar und durchsuchbar
# - beschreiben das Problem, nicht die Implementierung
# - vermeiden Desinformation und benennen eine sinnvolle Unterscheidung
# - vermeiden Kodierungen (ungarische Notation)
# - verwenden die richtige Wortart (lexikalische Kategorie)
# - verwenden die Regeln für Umfang und Länge (Scope-Length Rules)


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Namensregeln für Python
#
# Namen entsprechen den
# [PEP-8 Konventionen](https://peps.python.org/pep-0008/#naming-conventions)


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Selbsterklärende Namen

# %% tags=["keep"]
# Elapsed time in days
d = 0

# %%
elapsed_time_in_days = 0

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Namen, die die Intention offenbaren
#
# Reflektieren Absicht, Verhalten, Existenzberechtigung

# %% tags=["keep"]
my_list = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

# %% tags=["keep"]
dpm_lst = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

# %% tags=["alt"]
days_per_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Namen sind aussprechbar und durchsuchbar


# %% tags=["keep"]
hw_crsr_pxy = [0, 0]

# %%
hardware_cursor_position = [0, 0]


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Namen beschreiben das Problem, nicht die Implementierung
#
# Vermeide Namen, die sich auf Implementierungsdetails beziehen:
# - Sie verraten nicht, warum der Code so geschrieben wurde, wie er geschrieben ist
# - Aber die Vermittlung der Intention hinter dem Code hat höchste Priorität!

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
def add_elements(lst):
    return sum(lst)


# %% tags=["keep"]
add_elements(days_per_month)  # Seems reasonable


# %%
def compute_yearly_salary(monthly_salaries):
    return sum(monthly_salaries)


# %%
compute_yearly_salary(days_per_month)  # WHAT?!?

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Desinformation und sinnvolle Unterscheidungen
#
# - Namen bedeuten etwas
# - Desinformation:
#   - Die Bedeutung des Namens impliziert etwas anderes als der Programmcode:


# %% tags=["keep"]
verify_configuration = False

# %% tags=["keep"]
if verify_configuration:
    print("Deleting configuration files...")

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
from typing import NamedTuple


# %% tags=["keep"]
class Pair(NamedTuple):
    first: int
    second: int
    third: int


# %%
class Triple(NamedTuple):
    first: int
    second: int
    third: int


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Regeln zur Vermeidung von Desinformation
#
# - Vermeide Plattformnamen wie `sco`, `aix`, `nt`
#   - Oft sind Merkmalsprüfungen besser
# - Nimm keinen Typ in einen Variablennamen auf, wenn die Variable nicht von
#   diesem Typ ist
#   - Meistens: Gib überhaupt keinen Typ in einem Variablennamen an

# %% tags=["keep"]
vector_of_cards: int = 0

# %%
num_cards = 0

# %%
card_deck: list = [...]

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Regeln zur Vermeidung von Desinformation
#
# - Sei vorsichtig mit Namen, die sich nur geringfügig unterscheiden

# %% tags=["keep"]
is_melee_defence_available = True
is_melee_defense_available = False

# %% tags=["keep"]
print(is_melee_defence_available == is_melee_defense_available)  # Oops...

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Regeln zur Vermeidung von Desinformation
#
# - Benutze Namen, die etwas bedeuten

# %% tags=["keep"]
foobar = 0
bar = 1

# %%
number_of_visitors = 0
days_till_release = 1

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Regeln zur Vermeidung von Desinformation
#
# - Sei bei der Namensgebung konsistent

# %% tags=["keep"]
number_of_objects = 10
num_buyers = 12
n_transactions = 2

# %%
num_objects = 10
num_buyers = 12
num_transactions = 2

# %%
n_objects = 10
n_buyers = 12
n_transactions = 2

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Sinnvolle Unterscheidungen
#
# - Verwende Namen, die die Bedeutung der Konzepte so klar wie möglich ausdrücken


# %% tags=["keep"]
a1 = "Fluffy"
a2 = "Garfield"

# %%
my_dog = "Fluffy"
jons_cat = "Garfield"

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
INCLUDE_NONE = 0
INCLUDE_FIRST = 1
INCLUDE_SECOND = 2
INCLUDE_BOTH = 3

# %% tags=["keep"]
INCLUDE_NO_DATE = 0
INCLUDE_START_DATE = 1
INCLUDE_END_DATE = 2
INCLUDE_START_AND_END_DATE = 3


# %%
class DatesToInclude(IntEnum):
    NONE = 0
    START = 1
    END = 2
    START_AND_END = 3


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Sinnvolle Unterscheidungen
#
# - Verwende denselben Namen für dasselbe Konzept


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
from pathlib import Path

# %% tags=["keep"]
my_path = Path.home()
your_dir = Path.home()
file_loc = Path.home()

# %% tags=["keep"]
my_path = Path.home()
your_path = Path.home()
file_path = Path.home()

# %% tags=["keep"]
my_dir = Path.home()
your_dir = Path.home()
file_dir = Path.home()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Sinnvolle Unterscheidungen
#
# - Verwende deutlich unterschiedliche Namen für verschiedene Konzepte


# %% tags=["keep"]
MY_EFFICIENT_STRING_PROCESSING_HANDLE = 1
MY_EFFICIENT_STRING_PROCESSING_HANDLER = 2

# %% tags=["keep"]
EFFICIENT_STRING_PROCESSING_FLAG = 1
STRING_PROCESSOR_INDEX = 2

# %%
# But:
tasks = ["do this", "do that"]
for task in tasks:
    print(task)

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Mini-Workshop: Namen
#
# Das folgende Programm verwendet sehr schlechte Namen. Ändern Sie die Namen
# so, dass sie den PEP-8 Konventionen folgen und den Regeln für gute Namen
# folgen.

# %% tags=["keep"]
from dataclasses import dataclass, field


# %% tags=["keep"]
# Class representing Line Items:
@dataclass
class LI:
    # number of items
    X: int
    # description of the items
    ChrLst: str
    # price per item
    Y: float

    # compute the total price
    def foo(self):
        return self.X * self.Y


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
# Class representing an Order
@dataclass
class LIManager:
    # a list of line items
    LIVec: list[LI] = field(default_factory=list)

    # compute the total price
    def my_result(self):
        return sum(li.foo() for li in self.LIVec)


# %% tags=["keep"]
# Prepare an order
my_order = LIManager([LI(2, "tea", 0.99), LI(3, "coffee", 0.89)])
print(my_order.my_result())


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
@dataclass
class LineItem:
    num_items: int
    description: str
    price_per_item: float

    def total_price(self):
        return self.num_items * self.price_per_item


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
@dataclass
class Order:
    line_items: list[LineItem] = field(default_factory=list)

    def total_price(self):
        return sum(li.total_price() for li in self.line_items)


# %%
# Prepare an order
my_order = Order([LineItem(2, "tea", 0.99), LineItem(3, "coffee", 0.89)])
print(my_order.total_price())

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Vermeide Kodierungen
#
# Verwende keine ungarische Notation:


# %% tags=["keep"]
i_days = 12
i_month = 3


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Vermeide Kodierungen
#
# Verwende keine Präfixe für Attribute:

# %% tags=["keep"]
@dataclass
class MyClass:
    m_days: int
    m_months: int


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Vermeide Kodierungen
#
# Vermeiden Sie Präfixe wie C/I: CClass, IInterface

# %% tags=["keep"]
@dataclass
class CMyClass:
    days: int
    months: int


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Verwende die richtige lexikalische Kategorie
#
# - Klassen und Variablen: Substantive oder Substantivphrasen
# - Funktionen: Verben oder Verbphrasen
# - Enums: oft Adjektive
# - Boolesche Variablen und Funktionen: oft Prädikate: `ist_...`, `hat_...`

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
@dataclass
class GoToTheServer:
    def connection(self):
        ...

    def server_availability(self) -> bool:
        return True


# %%
class ServerConnection:
    def connect(self):
        ...

    def is_server_available(self) -> bool:
        return True


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Möglicherweise
#
# Vermeide Wörter, die keine Bedeutung haben, wie Manager, Prozessor, Daten,
# Info

# %% tags=["keep"]
class ObjectManager:
    pass


# %% tags=["keep"]
class ObjectController:
    pass


# %% tags=["keep"]
class DataController:
    pass


# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Python-Spezifisch
#
# Vermeide Getter/Setter für Zugriff auf Attribute:

# %% tags=["keep"]
class MyBox:
    def __init__(self, x) -> None:
        self._x = x

    def get_x(self):
        return self._x

    def set_x(self, new_value):
        self._x = new_value


# %% tags=["keep"]
my_box = MyBox(1)
print(my_box.get_x())
my_box.set_x(200)
print(my_box.get_x())


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
class YourBox:
    def __init__(self, x) -> None:
        self.x = x


# %% tags=["keep"]
your_box = YourBox(1)
print(your_box.x)
your_box.x = 200
print(your_box.x)


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Mit Properties kann die bestehende Syntax für kontrollierten oder berechneten Zugriff
# auf Attribute beibehalten werden:

# %% tags=["keep"]
class YourControlledBox:
    def __init__(self, x) -> None:
        self.x = x

    @property
    def x(self):
        return self._x + 1

    @x.setter
    def x(self, new_value):
        if new_value < 100:
            self._x = new_value + 100
        else:
            self._x = new_value - 100


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
your_box = YourControlledBox(1)
print(your_box.x)
your_box.x = 200
print(your_box.x)

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Regeln für Umfang und Länge (Scope-Length Rules)
#
# - Variablen:
# - Langer Geltungsbereich = langer Name
# - Kurzer Geltungsbereich = kurzer Name
# - Klassen und Methoden
# - Langer Geltungsbereich = kurzer Name
# - Kurzer Geltungsbereich = langer Name
#
# **Oder:** Verwende lange Namen für lange Geltungsbereiche


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
class FixedSizeOrderedCollectionIndexedByInts:
    pass


# %%
class Array:
    pass
