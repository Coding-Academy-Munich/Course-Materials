# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Clean Code: Kommentare und Dokumentation</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Clean Code_ Kommentare und Dokumentation.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_230_clean_code/topic_150_a3_comments_and_docs.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Clean Code: Kommentare und Dokumentation

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Docstrings
#
# Aus [PEP-257](https://peps.python.org/pep-0257/):
#
# Ein Docstring ist ein String-Literal, das als erste Anweisung in einer Modul-,
# Funktions-, Klassen- oder Methodendefinition auftritt. Ein solcher Docstring
# wird zum `__doc__`-Attribut dieses Objekts.
#
# Alle Module sollten normalerweise Docstrings haben, und alle Funktionen und
# Klassen, die von einem Modul exportiert werden, sollten auch Docstrings haben.
# Öffentliche Methoden (einschließlich des `__init__` Konstruktors) sollten auch
# docstrings haben. Ein Package kann im Modul-Docstring der Datei `__init__.py`
# im Package-Verzeichnis mit Dokumentation versehen werden.


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Docstring-Konventionen
#
# - Einzeilige Docstrings
#   - Verwende dreifache Anführungszeichen
#   - Keine Leerzeile davor oder danach
#   - Eine Phrase, die mit einem Punkt endet
#   - Geschrieben als ein Befehl: "Tu dies", "Gib diesen Wert zurück"
#   - Ist nicht die Signatur der Funktion (die kann durch Introspektion
#     ermittelt werden)
#   - Mehr Informationen in
#     [PEP-257](https://peps.python.org/pep-0257/#one-line-docstrings)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Docstring-Konventionen
#
# - Mehrzeilige Docstrings
#   - Zusammenfassungszeile wie ein einzeiliger Docstring
#   - Auf die Zusammenfassungszeile folgt eine Leerzeile
#   - Dann folgt eine ausführlichere Beschreibung, möglicherweise mit Doctests
#   - Auf den Docstring folgt eine Leerzeile
#   - Mehr Informationen in
#     [PEP-257](https://peps.python.org/pep-0257/#multi-line-docstrings)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Kommentare
#
# - Kommentare kompensieren unser Unvermögen, uns in Code auszudrücken.
# - Wenn möglich, drücke dich in Code aus, nicht in Kommentaren!
#   - Wann immer du einen Kommentar schreiben willst, prüfe, ob du es nicht im
#     Code tun kannst.
#   - Schreibe lieber Assertions oder Doctests, wenn möglich.
#   - Verwende erklärende Variablen

# %% tags=["keep"]
def add(x, y):
    """Compute the sum of two numbers.

    >>> add(1, 2)
    3
    >>> add(0, -2)
    -2
    """
    return x + y


# %% tags=["keep"]
days_of_work = 4

# %% tags=["keep"]
# Multiply the seconds in a day times the days of work.
duration_in_seconds = 60 * 60 * 24 * days_of_work

# %% tags=["keep"]
SECONDS_PER_DAY = 60 * 60 * 24
duration_in_seconds = SECONDS_PER_DAY * days_of_work


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Wie Kommentare scheitern
#
# - Kommentare sind schwer zu pflegen
# - Deshalb lügen sie oft
# - Sie werden nicht geändert, wenn der Code aktualisiert wird
# - Sie werden nicht verschoben, wenn der Code verschoben wird

# %%
# ```python
# # Check to see if the employee is eligible for full benefits
# if (employee.flags & HOURLY_FLAG) and (employee.age > 65):
#     ...
# ```
#
# versus
#
# ```
# if employee.is_eligible_for_full_benefits():
#     ...
# ```

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## PEP-8 Regeln für Kommentare
#
# Befolge die [PEP-8](https://peps.python.org/pep-0008/#comments) Richtlinien
# für Kommentare:
#
# - Halte die Kommentare aktuell, wenn sich der Code ändert.
# - Kommentare sollten aus vollständigen Sätzen bestehen.
#   - Das erste Wort wird großgeschrieben, es sei denn, es ist ein Bezeichner.
#   - Bezeichner sollten niemals geändert werden
#   - Verwenden Sie in mehrsätzigen Kommentaren zwei Leerzeichen nach einem
#     satzabschließenden Punkt.
# - Die Kommentare müssen klar und leicht verständlich sein.
# - Python-Coder aus nicht englischsprachigen Ländern: Bitte schreiben Sie Ihre
#   Kommentare auf Englisch, es sei denn, Sie sind 120% sicher, dass der Code
#   niemals von Leuten gelesen wird, die Ihre Sprache nicht sprechen.


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Gute Kommentare
#
# Kommentare sind gut, wenn sie
#
# - aus juristischen Gründen notwendig sind
# - Konzepte erklären, die nicht im Code ausgedrückt werden können
# - den Zweck des Codes erklären
# - Code erklären, den man nicht bereinigen kann (z.B. eine veröffentlichte
#   Schnittstelle)
# - veröffentlichte Schnittstellen dokumentieren (z.B. mit Doxygen)
# - `TODO`-Kommentare sind (wenn sie sparsam verwendet werden)
# - wichtige Aspekte betonen ("Dies ist sehr wichtig, weil...")

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Schlechte Kommentare
#
# - Unklare Kommentare (Nuscheln)
#
# Angenommen, der folgende Kommentar ist tatsächlich richtig. Was sagt er uns?

# %% tags=["keep"]
try:
    with open("my-app.cfg", mode="r", encoding="utf-8"):
        ...
except FileNotFoundError:
    # Somebody else has already loaded the defaults.
    pass


# %% [markdown] lang="de"
#
# - Redundante Kommentare (dauern länger als der Code zu lesen, ohne klarer zu
#   sein)

# %% tags=["keep"]
def read_and_apply_configuration(file):
    ...


# %% tags=["keep"]
# Read the configuration from file `my-app.cfg`. The file has to be readable and
# in UTF-8 encoding. If the file cannot be found we simply ignore the attempt.
# If the file is indeed found, we read it and apply the configuration to the
# system.
try:
    with open("my-app.cfg", mode="r", encoding="utf-8") as file:
        read_and_apply_configuration(file)
except FileNotFoundError:
    pass


# %% [markdown] lang="de"
#
# - Irreführende Kommentare

# %% tags=["keep"]
# Return a new list that is the concatenation of the elements in `list_1` and
# `list_2`.
def concatenate_lists(list_1, list_2):
    if not list_1:
        return list_2
    elif not list_2:
        return list_1
    else:
        return list_1 + list_2


# %% tags=["keep"]
assert concatenate_lists([1, 2], [3, 4]) == [1, 2, 3, 4]

# %% [markdown] lang="de"
#
# Aufgrund des Kommentars würde man folgendes Verhalten nicht erwarten:

# %% tags=["keep"]
x = [1, 2]
assert concatenate_lists(x, []) is x
assert concatenate_lists([], x) is x


# %% [markdown] lang="de"
#
# - Vorgeschriebene Kommentare (durch Style-Guides, nicht durch Gesetze)
# - Journal-Kommentare (Geschichte der Datei)

# %% tags=["keep"]
# file: widget.py
#
# Changes made to the file:
#
# 2022-08-10: Added a frobnicator as proposed by Jane
# 2022-08-11: Twiddled the frobnicator's parameters
# 2022-08-12: Further tweaks to the frobnicator settings
# 2022-08-13: Added flux compensation to the frobnicator
# 2022-08-14: Improved flux compensation
# 2022-09-03: Revisited flux compensation after discussion with Joe
#
class Frobnicator:
    pass


# %% [markdown] lang="de"
#
# - Inhaltsfreie Kommentare (Noise comments)

# %% tags=["keep"]
class FluxCompensator:
    # The `__init__()` method of the flux compensator.
    def __init__(self) -> None:
        ...


# %% tags=["keep"]
# Hourly wage in US$
HOURLY_WAGE_IN_USD = 80


# %% [markdown] lang="de"
#
# - Positions-Markierungen

# %% tags=["keep"]
class MyVeryLargeClass:
    ####################################################
    # Initialization Methods
    ####################################################
    def init(self):
        ...

    def init_in_another_way(self):
        ...

    ####################################################
    # Computations
    ####################################################
    def compute_this(self):
        ...

    def compute_that(self):
        ...

    ####################################################
    # State Updates
    ####################################################
    def set_some_state(self, x):
        ...


# %% [markdown] lang="de"
#
# - Zuschreibungen und Namensnennungen

# %% tags=["keep"]
# Added by Jack <jack@example.org> on 2018-03-12
def some_function(x, y):
    return x + y


# %% [markdown] lang="de"
#
# - Auskommentierter Code
#   - Neigt dazu, nie gelöscht zu werden
#   - Unklar, warum er da ist: sollte er gelöscht oder wieder einkommentiert
#     werden?
#   - Sollte lieber gelöscht und bei Bedarf aus dem Versionskontrollsystem
#     wiederhergestellt werden

# %% tags=["keep"]
# def some_function(x, y):
#     return x + y

# %% tags=["keep"]
def some_other_function(x, y):
    # z = x + y
    # return z
    return 123


# %% [markdown] lang="de"
#
# - HTML-Kommentare
#
# In Python werden Formatierungen in Kommentaren entweder in Markdown oder in
# reStructuredText (RST) geschrieben:

# %% tags=["keep"]
# <p><strong>Important:</strong></p>
# <ul>
#   <li>
#     Don&#39;t use <code>frobnicator_1</code> to tweak
#     <code>flux_compensator_2</code> because they are not
#     coherent!
#   </li>
#   <li>
#     Make sure that <code>fuzzbox_2</code> is turned to
#     at least 11 before plugging in the guitar.
#   </li>
# </ul>


# %% tags=["keep"]
# **Important:**
#
# - Don't use `frobnicator_1` to tweak `flux_compensator_2` because they are not
#   coherent!
# - Make sure that `fuzzbox_2` is turned to at least 11 before plugging in the
#   guitar.

# %% [markdown] lang="de"
#
# - Nichtlokale Information

# %% tags=["keep"]
# This is set to its correct value by `frob_foo()` in file `frobnicator.py`.
foo = 123

# %% [markdown] lang="de"
#
# - Zu viel Information

# %% tags=["keep"]

# Implement protocol handling according to ABC Standard 212-3.
#
# This was first proposed by Steve in a meeting in 2013, but at the time we had
# no compatible implementation of the support libraries available. We therefore
# shelved the discussion until Tina brought the topic up in the famous all-hands
# meeting of October 2019. There were some initial problems, but we finally
# succeeded in getting a running implementation working in 2021. This contains a
# bug that is still present in the current code base that causes the system to
# crash when talking to a client that implements variant /4 of the protocol.
# Finally, in early 2022 we also adapted this implementation for the XYZ device
# series.

# %% [markdown] lang="de"
#
# - Unklarer Bezug zum Code

# %% tags=["keep"]
# Adjust for target endianness and buffer size
foo = max((foo + 7) * 2, 256)
