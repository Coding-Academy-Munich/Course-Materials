# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Clean Code: Formatierung</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Clean Code_ Formatierung.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_230_clean_code/topic_160_a3_formatting.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Clean Code: Formatierung
#
# - Folge [PEP-8](https://peps.python.org/pep-0008/)
# - Verwende einen automatischen Code-Formatierer, wie z.B.
#   [black](https://github.com/psf/black)
# - Füge einen Pre-Commit-Hook zu Git hinzu, um den Code vor dem Einchecken
#   automatisch zu formatieren
#   - Siehe z.B. [https://pre-commit.com/] für eine vorgefertigte Lösung

