# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>SOLID: Einführung</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 SOLID_ Einführung.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_280_solid/topic_110_a3_solid_intro.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # SOLID: Einführung
#
# Eine Sammlung von fünf Prinzipien/Leitlinien, zusammengestellt von Robert C.
# Martin (Uncle Bob)
#
# - Single-Responsibility-Prinzip (SRP)
# - Open/Closed-Prinzip (OCP)
# - Liskov-Substitutions-Prinzip (LSP)
# - Interface-Segregation-Prinzip (ISP)
# - Dependency-Inversion-Prinzip (DIP)
