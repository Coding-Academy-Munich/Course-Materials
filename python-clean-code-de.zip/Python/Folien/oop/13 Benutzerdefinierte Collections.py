# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Benutzerdefinierte Collections</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">13 Benutzerdefinierte Collections.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_200_object_orientation/topic_210_defining_collections.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# Es ist möglich, eine Klasse zu definieren, deren Instanzen sich wie Listen verhalten.
# Um die Implementierung zu vereinfachen, delegieren wir die Verwaltung der Elemente
# an eine Liste, die als Attribut gespeichert ist.
# Diese Form der Komposition findet man häufig in der objektorientierten Programmierung.

# %%
class MyBadList:
    def __init__(self, elements=None):
        if elements is None:
            elements = []
        self.elements = elements

    def __getitem__(self, n):
        if isinstance(n, slice):
            return MyBadList(self.elements[n])
        return self.elements[n]

    def __len__(self):
        return len(self.elements)

    def __repr__(self):
        return f"MyBadList({self.elements!r})"

    def append(self, element):
        self.elements.append(element)


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
my_list_1 = MyBadList()
my_list_2 = MyBadList()
my_list_3 = MyBadList([1, 2, 3])
print(my_list_1)
print(my_list_2)
print(my_list_3)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
my_list_1.append("a")
my_list_1.append("b")
my_list_1.append("c")
print(my_list_1)
print(my_list_2)
print(my_list_3)

# %%
print(len(my_list_1))
print(my_list_1[0])
# print(my_list_1[10])

# %%
for elt in my_list_1:
    print(elt)

# %%
my_list_1[1:]


# %% tags=["keep"]
