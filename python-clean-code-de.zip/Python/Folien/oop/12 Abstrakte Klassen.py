# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Abstrakte Klassen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">12 Abstrakte Klassen.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_200_object_orientation/topic_200_abstract_classes.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Abstrakte Klassen
#
# - Klassen, von denen keine direkte Instanz erzeugt werden kann
# - Haben die Klasse `abc.ABC` als Basisklasse
#     - (Eigentlich ist eine Metaklasse verantwortlich für das Verhalten)
# - Erlauben die Verwendung des `@abstractmethod` Decorators um abstrakte Methoden
#   zu definieren
#     - Der Rumpf einer abstrakten Methode ist oft `...`
# - Abstrakte Klassen, die nur abstrakte Methoden haben nennt man Interfaces
#     - Interfaces beschreiben Anforderungen an ihre Unterklassen

# %%
...

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
from abc import ABC, abstractmethod


class MyBase(ABC):
    @abstractmethod
    def my_method(self):
        ...


# %%
class MyClass(MyBase):
    def my_method(self):
        super().my_method()
        print("my_method()")


# %%
mc = MyClass()
mc.my_method()

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - Abstrakte Methoden können eine Implementierung haben
# - Klassen, die von einer abstrakten Klasse erben aber nicht alle abstrakten
#   Methoden überschreiben sind selber abstrakt.

# %%
from abc import ABC, abstractmethod


class MyBase(ABC):
    @abstractmethod
    def my_method(self):
        print("Hi!")


# %%
class MyClass(MyBase, ABC):
    pass


# %%
# mc = MyClass()


# %%
class YourClass(MyBase):
    def my_method(self):
        super().my_method()
        print("Hello!")


# %%
yc = YourClass()
yc.my_method()


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
# # Workshop
#
# Siehe `workshop_950_rpg_dice` bis `Factory für RPG-Würfel`.


# %% [markdown] lang="de"
# ## RPG-Würfel
#
# In Rollenspielen werden Konflikte zwischen Spielern oft durch Würfeln
# entschieden. Dabei werden oft mehrere Würfel gleichzeitig verwendet. Außerdem
# werden nicht nur die bekannten 6-seitigen Würfel verwendet, sondern auch
# 4-seitige, 8-seitige, 20-seitige Würfel, etc.
#
# Die Anzahl und Art der Würfel wird dabei durch folgende Notation beschrieben:
#
# ```text
# <Anzahl der Würfel> d <Seiten pro Würfel>
# ```
#
# Zum Beispiel wird das Würfeln mit zwei 6-seitigen Würfeln als `2d6`
# beschrieben. Manchmal werden auch komplexere Formeln verwendet:
# `3d20 + 2d6 - 4` bedeutet, dass gleichzeitig drei 20-seitige Würfel und zwei 6-seitige
# Würfel geworfen werden und die Gesamtsumme der Augenzahlen dann um 4
# verringert wird.
#
# In manchen Spielen wird das Werfen der niedrigsten oder höchsten Augenzahl
# besonders behandelt ("katastrophale Niederlage", "kritischer Erfolg").
#
# In den folgenden Aufgaben sollen Sie derartige RPG-Würfel in Python
# implementieren. Um Ihre Implementierung testen zu können empfiehlt es sich
# sie in einem IDE zu realisieren.
#
# Schreiben Sie Tests für jede Funktionalität, die Sie implementieren.
# Wie können Sie beim Testen mit der Zufälligkeit beim Würfeln umgehen?
# Was sind Stärken bzw. Schwächen der von Ihnen gewählten Teststrategie?
