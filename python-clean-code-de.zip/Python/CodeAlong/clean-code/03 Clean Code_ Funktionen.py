# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Clean Code: Funktionen</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Clean Code_ Funktionen.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_230_clean_code/topic_140_a3_functions.py</div> -->

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Clean Code: Funktionen
#
# Verpacke Sinnvolle Operationen als sorgfältig benannte Funktionen
#
# - Besser lesbar
# - Einfacher zu testen
# - Wird eher wiederverwendet
# - Fehler sind weniger wahrscheinlich

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Die 1. Clean Code Regel für Funktionen
#
# - Funktionen sollten kurz sein
# - Kürzer als man meint!
# - Maximal 4 Zeilen!

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Lockere Regeln
#
# (Aus den C++ Core Guidelines)
#
# - Funktionen sollten auf einen Bildschirm passen
# - Große Funktionen sollten in kleinere, zusammenhängende und benannte
#   Funktionen aufgeteilt werden
# - Funktionen mit einer bis fünf Zeilen sollten als normal angesehen werden

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Konzentration auf eine Aufgabe
#
# - Funktionen sollten eine Aufgabe erfüllen ("do one thing")
# - Sie sollten diese Aufgabe gut erfüllen
# - Sie sollten nur diese Aufgabe erfüllen

# %%

# %%

# %%

# %%

# %%

# %%

# %%


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Abstraktionsebenen
#
# Alles, was die Funktion in ihrem Rumpf tut, sollte eine (und nur eine)
# Abstraktionsebene unterhalb der Funktion selbst sein.

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## "Um zu"-Absätze: Kontrolle der Abstraktionsebenen
#
# Um render_page_with_setups_and_teardowns durchzuführen
#
# prüfen wir, ob die Seite eine Testseite ist und
#
# wenn ja, binden wir Setup und Teardown ein.
#
# In jedem Fall rendern wir die Seite in HTML.

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Die Step-Down-Regel
#
# - Wir wollen, dass sich der Code wie eine Erzählung von oben nach unten liest
# - Auf jede Funktion sollten die Funktionen eine Abstraktionsebene darunter
#   folgen

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Do one Thing
#
# Die Funktion `handle_money_stuff()` macht mehr als eine Sache.
#
# Teilen Sie sie in mehrere Funktionen auf, so dass jede nur eine Sache tut.
# Stellen Sie sicher, dass
# - jede Funktion ihre Aufgabe gut erfüllt und sich auf einer einzigen
#   Abstraktionsebene befindet,
# - alle Namen angemessen sind, und
# - der Code leicht zu verstehen ist.
#
# *Tipp:* Beginnen Sie damit, die Variablen gemäß den Kommentaren umzubenennen,
# um den Rest der Arbeit zu vereinfachen.


# %% lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Die Funktion `handle_money_stuff()` hat folgende Parameter:
#
# - den Wochentag (`i_dow`, day of week),
# - das Gehalt pro Tag (`f_spd`, salary per day),
# - den Namen des Angestellten (`str_n`, name) und
# - einen Liste der bisher gezahlten Gehälter (`lst_slrs`, salaries).
#
# Das neue Gehalt wird an die Liste `lst_slrs` angehängt.
#
# Die Funktion gibt die zu zahlende Steuer zurück.

# %% tags=["keep"]
def handle_money_stuff(i_dow: int, f_spd: float, str_n: str, lst_slrs: list):
    # Get the day of week from the list of days.
    # We count Sunday as 1, Monday as 2, etc. but the work week starts on Monday.
    str_dow = lst_dns[i_dow - 1]
    # Compute the salary so far based on the day
    f_ssf = (i_dow - 1) * f_spd
    # The tax
    f_t = 0.0
    if f_ssf > 500.0 and f_ssf <= 1000.0:
        f_t = f_ssf * 0.05
    elif f_ssf > 1000.0 and f_ssf <= 2000.0:
        f_t = f_ssf * 0.1
    else:
        f_t = f_ssf * 0.15
    # Update salary based on the tax to pay
    f_ssf = f_ssf - f_t
    # Add the salary to the list of all salaries paid
    lst_slrs.append(f_ssf)
    print(f"{str_n} worked till {str_dow} and earned ${f_ssf} this week.")
    print(f"Their taxes were ${f_t}.")
    return f_t


# %% tags=["keep"]
_salaries = [2345, 1234]
_result = handle_money_stuff(4, 200, "Joe", _salaries)
print(_result)

# %% tags=["keep"]
assert _salaries == [2345, 1234, 570]
assert _result == 30


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %% tags=["keep"]
_salaries = [2345, 1234]
_result = compute_salary_and_taxes_v1(4, 200, "Joe", _salaries)
print(_result)

# %% tags=["keep"]
assert _salaries == [2345, 1234, 570]
assert _result == 30

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% tags=["keep"]
_salaries = [2345, 1234]
_result = compute_salary_and_taxes_v2(4, 200, "Joe", _salaries)
print(_result)

# %% tags=["keep"]
assert _salaries == [2345, 1234, 570]
assert _result == 30


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Switch-Anweisungen und Abstraktion
#
# Switch-Anweisungen führen oft Operationen auf der gleichen Abstraktionsebene aus.
# (für "Subtypen" anstelle des ursprünglichen Typs).
#
# "Subtypen" werden oft durch Typ-Tags unterschieden.

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
from enum import IntEnum
from dataclasses import dataclass


# %% tags=["keep"]
class EmployeeType(IntEnum):
    COMMISSIONED = 0
    HOURLY = 1
    SALARIED = 2


# %% tags=["keep"]
@dataclass
class Money:
    amount_in_euros: float

    def __add__(self, rhs):
        return Money(self.amount_in_euros + rhs.amount_in_euros)


# %% tags=["keep"]
print(Money(100.0) + Money(50.0))


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
@dataclass
class EmployeeV1:
    type: EmployeeType


# %% tags=["keep"]
def calculate_commissioned_pay(e: EmployeeV1):
    return Money(100.0)


# %% tags=["keep"]
def calculate_hourly_pay(e: EmployeeV1):
    return Money(120.0)


# %% tags=["keep"]
def calculate_salaried_pay(e: EmployeeV1):
    return Money(80.0)


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def calculate_pay(e: EmployeeV1):
    if e.type == EmployeeType.COMMISSIONED:
        return calculate_commissioned_pay(e)
    elif e.type == EmployeeType.HOURLY:
        return calculate_hourly_pay(e)
    elif e.type == EmployeeType.SALARIED:
        return calculate_salaried_pay(e)
    else:
        raise ValueError("No valid employee type.")


# %% tags=["keep"]
e1 = EmployeeV1(type=EmployeeType.HOURLY)
e2 = EmployeeV1(EmployeeType.SALARIED)

# %% tags=["keep"]
print(calculate_pay(e1))
print(calculate_pay(e2))


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Ersetze Switch-Anweisung durch Polymorphie
#
# Es ist oft besser, switch-Anweisungen durch "echtes" Subtyping und
# Polymorphismus zu ersetzen:

# %% tags=["keep"]
from abc import ABC, abstractmethod


# %% tags=["keep"]
class Employee(ABC):
    @abstractmethod
    def calculate_pay(self):
        ...


# %% tags=["keep"]
@dataclass
class CommissionedEmployee(Employee):
    def calculate_pay(self):
        return Money(100.0)


# %% tags=["keep"]
@dataclass
class HourlyEmployee(Employee):
    def calculate_pay(self):
        return Money(120.0)


# %% tags=["keep"]
@dataclass
class SalariedEmployee(Employee):
    def calculate_pay(self):
        return Money(80.0)


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def create_employee(employee_type: EmployeeType):
    if employee_type == EmployeeType.COMMISSIONED:
        return CommissionedEmployee()
    elif employee_type == EmployeeType.HOURLY:
        return HourlyEmployee()
    elif employee_type == EmployeeType.SALARIED:
        return SalariedEmployee()
    else:
        raise ValueError("Not a valid employee type.")


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
e1 = create_employee(EmployeeType.HOURLY)
e2 = create_employee(EmployeeType.SALARIED)


# %% tags=["keep"]
print(e1.calculate_pay())
print(e2.calculate_pay())


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
class EmployeeFactory:
    def create_employee(self, employee_type: EmployeeType):
        if employee_type == EmployeeType.COMMISSIONED:
            return CommissionedEmployee()
        elif employee_type == EmployeeType.HOURLY:
            return HourlyEmployee()
        elif employee_type == EmployeeType.SALARIED:
            return SalariedEmployee()
        else:
            raise ValueError("Not a valid employee type.")


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
factory = EmployeeFactory()
e1 = factory.create_employee(EmployeeType.HOURLY)
e2 = factory.create_employee(EmployeeType.SALARIED)


# %% tags=["keep"]
print(e1.calculate_pay())
print(e2.calculate_pay())

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Ersetzen von Switch-Anweisungen
#
# Strukturieren Sie den folgenden Code so um, dass nur noch bei der Erzeugung
# der Objekte eine "switch-Anweisung" verwendet wird:

# %% tags=["keep"]
from dataclasses import dataclass
from abc import ABC


# %% tags=["keep"]
COMPUTER_TYPE_PC = 0
COMPUTER_TYPE_MAC = 1
COMPUTER_TYPE_CHROMEBOOK = 2


# %% tags=["keep"]
@dataclass
class ComputerV1:
    computer_type: int


# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
def compile_code(computer: ComputerV1):
    if computer.computer_type == COMPUTER_TYPE_PC:
        print("Compiling code for PC.")
    elif computer.computer_type == COMPUTER_TYPE_MAC:
        print("Compiling code for Mac.")
    elif computer.computer_type == COMPUTER_TYPE_CHROMEBOOK:
        print("Compiling code for Chromebook.")
    else:
        raise ValueError(f"Don't know how to compile code for {computer}.")


# %% tags=["keep"]
my_pc = ComputerV1(COMPUTER_TYPE_PC)
my_mac = ComputerV1(COMPUTER_TYPE_MAC)
my_chromebook = ComputerV1(COMPUTER_TYPE_CHROMEBOOK)

# %% tags=["keep"]
compile_code(my_pc)
compile_code(my_mac)
compile_code(my_chromebook)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Weitere Regeln für Funktionen
#
# - Verwende beschreibende Namen
# - Verwende wenige (oder keine) Argumente
# - Verwende keine booleschen Argumente (Flag-Argumente)
# - Vermeide versteckte Seiteneffekte

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Versteckte Seiteneffekte

# %% [markdown]
#
# ```java
# bool checkPassword(std::string userName, std::string password) {
#     User& user = UserGateway.findByName(userName);
#     if (user != User.NULL) {
#         std::string codedPhrase = user.getPhraseEncodedByPassword();
#         std::string phrase = cryptographer.decrypt(codedPhrase, password);
#         if (phrase == "Valid Password") {
#             session.initialize();
#             return true;
#         }
#     }
#     return false;
# }
# ```

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Vermeide "Ausgabeargumente"
#
# Python hat keine "echten" Ausgabeargumente. Aber Modifikation von Objekten hat
# oft ähnliche Konsequenzen:

# %% tags=["keep"]
class HitResultV1:
    pass


# %% tags=["keep"]
class PlayerV1:
    def check_collision(self, obstacles, hit_result):
        # Complicated computation...
        hit_result.collision_occurred = True


# %% tags=["keep"]
player = PlayerV1()
hit_result = HitResultV1()
player.check_collision([], hit_result)
if hit_result.collision_occurred:
    print("Detected collision!")


# %%

# %%

# %%

# %% tags=["keep"]
player = Player()
hit_result = player.check_collision([])
if hit_result.collision_occurred:
    print("Detected collision!")

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Command-Query Separation

# %% tags=["keep"]
default_value = -1


# %% tags=["keep"]
def bad_has_default_value() -> bool:
    global default_value
    if default_value >= 0:
        return True
    else:
        default_value = 123
        return False

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%


# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Fehlerbehandlung
#
# Verwende Ausnahmen zur Fehlerbehandlung.
#
# (Siehe `module_170_exceptions`.)

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## DRY: Don't Repeat Yourself
#
# - Versuche, duplizierten Code zu eliminieren.
#   - Wiederholung bläht den Code auf
#   - Wiederholung von Code erfordert mehrere Modifikationen für jede Änderung
# - Aber: oft ist duplizierter Code mit anderem Code durchsetzt
# - Berücksichtige den Bereich, in dem Sie den Code DRY halten!
