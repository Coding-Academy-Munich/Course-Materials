# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Klassenmethoden und Factories</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">14 Klassenmethoden und Factories.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_200_object_orientation/topic_220_a3_class_methods_and_factories.py</div> -->

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Klassenmethoden und Factories
#
# Eine Factory ist eine Funktion (oder Klasse), die zur Konstruktion von
# Objekten verwendet werden kann. Python bietet mit Klassenmethoden ein
# mächtiges Konstrukt für die Implementierung von Factories an.
#
# Klassenmethoden sind Methoden, die typischerweise auf einer Klasse (und nicht
# einem Objekt) aufgerufen werden. Im Gegensatz zu statischen Methoden (die
# keine Information über die Klasse, auf der sie aufgerufen werden bekommen)
# bekommen Klassenmethoden das Klassenobjekt, auf dem sie aufgerufen werden, als
# argument. Dieses Klassenobjekt kann verwendet werden um Operationen
# auszuführen, die von der Klasse abhängen, z.B. das Erstellen von
# Objektinstanzen.

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Falls die Konstruktor-Argumente einer Subklasse mit der Oberklasse kompatibel
# sind, können die Klassenmethoden der Oberklasse direkt als Factories für die
# Unterklassen verwendet werden.

# %%

# %%

# %%

# %%

# %% [markdown] lang="de" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Attribute von Klassen
#
# Die meisten Attribute werden auf der Instanz-Ebene definiert, d.h.,
# jedes Objekt hat seine eigenen Werte für die Attribute. Manchmal ist es
# aber sinnvoll Attribute auch auf der Klassenebene zu definieren:

# %%

# %%

# %%

# %%

# %%

# %%


# %% [markdown] lang="de"
# ### Vererbung


# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
