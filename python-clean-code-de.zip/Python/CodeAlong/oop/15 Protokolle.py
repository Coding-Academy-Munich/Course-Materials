# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="de" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#  <b>Protokolle</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">15 Protokolle.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_200_object_orientation/topic_230_protocols.py</div> -->

# %% [markdown] lang="de"
# # Protokolle
#
# Durch Protokolle unterstützt Python strukturelles Subtyping, bei dem
# Subtyp-Beziehungen aus der Struktur der Klassen erschlossen werden (im Gegensatz zum
# nominalen Subtyping, bei dem die Beziehungen explizit deklariert werden müssen).

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
# ## Workshop: Protokolle
#
# Implementieren Sie ein zur Laufzeit überprüfbares Protokoll `SupportsConnect`,
# das Instanzen von Klassen beschreibt, die eine Methode `connect(self, device)`
# haben.

# %%

# %%

# %% [markdown] lang="de"
#
# Implementieren Sie Klassen `Plugboard` und `PatchCord`, die das
# `SupportsConnect` Protokoll unterstützen.

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="de"
#
# - Erfüllt die folgende Klasse das Protokoll `SupportsConnect`?
# - Lässt sich das zur Laufzeit feststellen?

# %% tags=["keep"]
class SelfConnector:
    def connect(self):  # noqa
        print("Connecting to self!")

# %%
