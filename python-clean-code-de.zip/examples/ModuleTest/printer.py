print("Loading printer.py")
print(f"__name__ is {__name__}")


def print_greeting(name):
    print(f"Hallo, {name}.")


def my_fun():
    return "printer.my_fun()"


if __name__ == "__main__":
    print("printer.py started as main program.")
