print("simple.py: __name__ is", __name__)
