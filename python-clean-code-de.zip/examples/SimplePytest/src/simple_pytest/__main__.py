

def say_hi():
    print(f"Hello, world!")


if __name__ == "__main__":
    say_hi()


