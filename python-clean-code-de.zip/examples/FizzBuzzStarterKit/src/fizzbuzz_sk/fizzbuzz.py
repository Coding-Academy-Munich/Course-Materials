def fizzbuzz(n: int) -> None:
    pass
