from .fizzbuzz import fizzbuzz
