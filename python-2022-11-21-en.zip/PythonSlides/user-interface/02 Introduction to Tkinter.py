# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Introduction to Tkinter</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Introduction to Tkinter.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_360_gui/topic_110_a5_tk_intro.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Introduction to Tkinter
#
# Tkinter is a GUI toolkit included in the standard Python distribution. The
# IDLE development environment uses Tkinter for its user interface.
#
# The following example shows a simple Tkinter program to explain its basic
# features. It is not an example for good programming style!

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We want to build the following application:
#
# <img src="img/converter-01.png"
#      style="display:block;margin:auto;width:30%"/>


# %%
def convert_fahrenheit_to_celsius(fahrenheit):
    return (fahrenheit - 32) * 5 / 9


# %%
import tkinter as tk
import tkinter.ttk as ttk

# %%
root = tk.Tk()
root.title = "Convert Fahrenheit to Celsius"

# %%
main_frame = ttk.Frame(root, padding="3 3 12 12")
main_frame.grid(column=0, row=0, sticky="NSEW")

# %%
fahrenheit_text = tk.StringVar()
fahrenheit_entry = ttk.Entry(main_frame, width=6, textvariable=fahrenheit_text)
fahrenheit_entry.grid(column=2, row=1, sticky="W E")
fahrenheit_entry.focus()

# %%
celsius_text = tk.StringVar(value="<none>")
celsius_label = ttk.Label(main_frame, textvariable=celsius_text)
celsius_label.grid(column=2, row=2, sticky="W E")

# %%
def perform_conversion(*args):
    try:
        celsius = convert_fahrenheit_to_celsius(float(fahrenheit_text.get()))
        celsius_text.set(f"{celsius:.2f}")
    except:
        fahrenheit_text.set("<invalid input>")
        celsius_text.set("<none>")


# %%
convert_button = ttk.Button(
    main_frame,
    text="Convert",
    command=perform_conversion,
)
convert_button.grid(column=2, row=3, sticky="E")
root.bind("<Return>", perform_conversion)

# %%
ttk.Label(main_frame, text="Fahrenheit:").grid(column=1, row=1, sticky="E")
ttk.Label(main_frame, text="Celsius:").grid(column=1, row=2, sticky="E")

# %%
for child in main_frame.winfo_children():
    child.grid_configure(padx=2, pady=1)

# %%
root.mainloop()
