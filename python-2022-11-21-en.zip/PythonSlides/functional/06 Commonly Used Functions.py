# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Commonly Used Functions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Commonly Used Functions.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_340_d4_functional_programming.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Commonly Used Functions

# %%
from operator import add, mul

# %%
add(2, 3)

# %%
mul(2, 3)

# %%
from operator import itemgetter, attrgetter

# %%
my_list = [1, 2, 3, 4]
your_list = [10, 20, 30, 40]

# %%
first_elt = itemgetter(1)

# %%
print(first_elt(my_list))
print(first_elt(your_list))

# %%
from pathlib import Path

# %%
path = Path("foo.bar")
other_path = Path("my_file.txt")

# %%
name_getter = attrgetter("name")

# %%
name_getter(path)

# %%
name_getter(other_path)

# %%
from operator import methodcaller

# %%
as_uppercase = methodcaller("upper")

# %%
as_uppercase("foo")

# %%
sorted(["Hello", "World", "artist", "FILE", "great", "list"])

# %%
sorted(["Hello", "World", "artist", "FILE", "great", "list"], key=as_uppercase)

# %%
sorted(["Hello", "World", "artist", "FILE", "great", "list"], key=methodcaller("lower"))

# %%
from functools import partial

# %%
add2 = partial(add, 2)

# %%
add2(3)

# %%
any(x % 3 == 0 for x in range(10))

# %%
all(x < 3 for x in range(4))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "Valid Groups"
#
# For an event, groups should only be admitted if
# - either all participants are at least 18 years old or
# - there is at least one teacher in the group
# Implement a  function `is_valid_group(group: list[Person])` that checks this.


# %% tags=["keep"]
from dataclasses import dataclass


# %% tags=["keep"]
@dataclass
class Person:
    age: int
    profession: str = "unknown"


# %% tags=["keep"]
group1 = [Person(23), Person(42), Person(84, "doctor"), Person(29)]
group2 = [Person(12), Person(13), Person(53, "teacher"), Person(11)]
group3 = [Person(12), Person(32)]


# %%
def is_valid_group(group: list[Person]):
    return all(p.age >= 18 for p in group) or any(
        p.profession.lower() == "teacher" for p in group
    )


# %% tags=["keep"]
assert is_valid_group(group1)

# %% tags=["keep"]
assert is_valid_group(group2)

# %% tags=["keep"]
assert not is_valid_group(group3)

# %%
zip([1, 2, 3], range(100, 200))

# %%
tuple(zip([1, 2, 3], range(100, 200)))

# %%
list(zip([1, 2], [2, 3], strict=True))

# %%
# list(zip([1, 2, 3], [2, 3], strict=True))

# %%
zip([1, 2, 3], [2, 3], strict=True)

# %%
list(((x, x + 10) for x in range(3)))

# %%
list(zip(*((x, x + 10) for x in range(3))))

# %%
map(add2, range(10))

# %%
list(map(add2, range(10)))

# %%
from itertools import islice, count, cycle, repeat, chain

# %%
list(islice(count(), 5))

# %%
list(islice(count(), 5, 10))

# %%
list(islice(count(), 5, 10, 2))

# %%
list(islice(count(2, 3), 5))

# %%
list(islice(cycle([1, 2, 3]), 1))

# %%
list(islice(repeat([1, 2, 3]), 5))

# %%
list(islice(chain(range(10, 12), range(30, 50)), 5))

# %%
from itertools import tee

it1, it2 = tee(count(1, 10))
list(islice(it1, 3)), list(islice(it2, 3))

# %%
from itertools import takewhile, dropwhile

# %%
list(takewhile(lambda x: x < 10, count(2, 2)))

# %%
list(islice(dropwhile(lambda x: x < 10, count(2, 2)), 5))

# %%
from itertools import compress

list(compress(range(10), [True, False, True, False, True]))

# %%
it1, it2 = tee(count(1, 10))
list(compress(it1, islice(map(lambda x: x % 3 == 0, it2), 10)))

# %%
from operator import concat
from functools import reduce

# %%
reduce(add, range(11))

# %%
reduce(mul, range(1, 11))

# %%
reduce(concat, map(partial(mul, 2), list("abcd")))

# %%
# noinspection PyTypeChecker
reduce(concat, (char * 2 for char in "abcd"))

# %%
# noinspection PyTypeChecker
reduce(concat, (char * 2 for char in ""), "")

# %%
# noinspection PyTypeChecker
reduce(concat, (char * 2 for char in "abcd"), "")

# %%
from itertools import accumulate

# %%
list(accumulate((char * 2 for char in "abcd"), concat))

# %%
from itertools import combinations, permutations, combinations_with_replacement

# %%
list(combinations(range(5), 2))

# %%
list(permutations(range(5), 2))

# %%
list(permutations(range(4)))

# %%
list(combinations_with_replacement(range(5), 2))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "Seating Arrangements"
#
# In an event with 4 participants, how many ways are there to allocate the
# participants to the seats if there are 5 numbered seats?
#
# Does your implementation scale to larger events?

# %%
len(tuple(permutations(range(5), 4)))

# %%
len(tuple(permutations(range(8), 6)))

# %%
len(tuple(permutations(range(12), 7)))

# %%
from operator import mul
from functools import reduce


def seating_arrangements(seats, people):
    free_seats = seats - people
    print(free_seats, people)
    if free_seats >= 0:
        return reduce(mul, range(free_seats + 1, seats + 1))


# %%
seating_arrangements(5, 4)

# %%
seating_arrangements(8, 6)

# %%
seating_arrangements(12, 7)

# %%
seating_arrangements(100, 50)
