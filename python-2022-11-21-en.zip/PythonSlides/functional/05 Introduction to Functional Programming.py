# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Introduction to Functional Programming</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Introduction to Functional Programming.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_320_d4_functional_programming_intro.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Introduction to Functional Programming
#
# Traditionally functional programming is characterized by the following features:
# - First-class and higher-order functions
# - Immutable data types (immutable data types)
# - Recursion instead of iteration

# %%
def sum_to(n):
    if n <= 0:
        return 0
    else:
        return sum_to(n - 1) + n


# %%
sum_to(3)

# %%
sum_to(10)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "mean computation"
#
# Write a function `fact(n: int)` that calculates the product of the numbers from 1
# to `n`.

# %%
def fact(n):
    if n <= 0:
        return 1
    else:
        return n * fact(n - 1)


# %% tags=["keep"]
assert fact(3) == 6

# %% tags=["keep"]
assert fact(10) == 3628800

# %% tags=["keep"]
assert fact(50) == 30414093201713378043612608166064768844377641568960512000000000000


# %%
def sum_from_to(m, n):
    if m > n:
        return 0
    else:
        return m + sum_from_to(m + 1, n)


# %%
sum_from_to(0, 3)

# %%
sum_from_to(1, 10)


# %% tags=["keep"]
class LispList:
    pass


# %% tags=["keep"]
class Nil(LispList):
    def __repr__(self):
        return "nil"


# %% tags=["keep"]
nil = Nil()


# %%
def is_empty(lst):
    return isinstance(lst, Nil)


# %% tags=["keep"]
class Cons(LispList):
    def __init__(self, first, rest):
        self.first = first
        self.rest = rest

    def __repr__(self):
        return f"({self.first}{self.rest_to_str()})"

    def rest_to_str(self) -> str:
        if isinstance(self.rest, Nil):
            return ""
        elif isinstance(self.rest, Cons):
            return f" {self.rest.first}{self.rest.rest_to_str()}"
        else:
            return f" . {self.rest}"


# %% tags=["keep"]
nil

# %% tags=["keep"]
Cons(1, Nil())

# %% tags=["keep"]
Cons(1, Cons(2, Nil()))

# %% tags=["keep"]
Cons(1, Cons(2, Cons(3, Nil())))

# %% tags=["keep"]
Cons(1, 2)


# %% tags=["keep"]
def lisp_list(*args):
    def build_list(elements):
        if len(elements) > 0:
            return Cons(elements[0], build_list(elements[1:]))
        else:
            return Nil()

    return build_list(args)


# %% tags=["keep"]
lisp_list(1, 2, 3)

# %% tags=["keep"]
lisp_ints = lisp_list(*range(10))
lisp_ints

# %% tags=["keep"]
is_empty(nil)

# %% tags=["keep"]
is_empty(lisp_ints)


# %%
def lisp_add(lst):
    if is_empty(lst):
        return 0
    else:
        return lst.first + lisp_add(lst.rest)


# %%
lisp_add(nil)

# %%
lisp_add(lisp_list(1, 2, 3))


# %%
def lisp_find(elt, lst):
    if is_empty(lst):
        return nil, False
    elif lst.first == elt:
        return elt, True
    else:
        return lisp_find(elt, lst.rest)


# %%
lisp_find(2, lisp_ints)

# %%
lisp_find(10, lisp_ints)


# %%
def lisp_drop(n, lst):
    if n == 0:
        return lst
    else:
        return lisp_drop(n - 1, lst.rest)


# %%
lisp_drop(2, lisp_ints)

# %%
lisp_drop(10, lisp_ints)


# %% [markdown] lang="en"
# ## Problems with recursion in Python

# %%
# sum_to(10_000)

# %%
def recursive_find(elt, lst):
    if len(lst) == 0:
        return None, False
    elif lst[0] == elt:
        return lst[0], True
    else:
        return recursive_find(elt, lst[1:])


# %%
recursive_find(2, list(range(10)))

# %%
recursive_find(10, list(range(10)))

# %% [markdown] lang="en"
# ## Benefits of a functional programming style
#
# - Compositionality
# - Modularity
# - Ease of testing and debugging
