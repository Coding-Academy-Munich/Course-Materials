# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Decorators</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Decorators.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_290_e2_decorators.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Decorators
#
# See [PEP 318](https://peps.python.org/pep-0318/)

# %%
def log_exec(fun):
    def logged_fun(*args, **kwargs):
        print(f"Calling {fun.__name__} on {args}, {kwargs}.")
        return fun(*args, **kwargs)

    return logged_fun


# %%
@log_exec
def say_hi(name="world"):
    print(f"Hi {name}!")


# %%
say_hi()

# %%
say_hi("Joe")


# %%
@log_exec
def my_dict(id, **kwargs):
    return dict(id=id, **kwargs)


# %%
my_dict(123)

# %%
my_dict(123, foo=234, bar=345)

# %%
d = dict(foo=234, bar=345)

# %%
my_dict(1, **d)

# %% tags=["keep"]
