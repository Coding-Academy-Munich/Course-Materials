# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Tuple Properties</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Tuple Properties.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_150_collections/topic_152_b1_tuple_properties.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Properties of tuples
#
# - Tuples can store arbitrary Python values
# - Elements in a tuple have a fixed order
# - Elements of a tuple can be accessed by index
# - `for` loops can iterate over a tuple's elements (Iterables)
# - Tuples can *not* be modified
#
# Tuples are often used to store *heterogeneous* data.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Modifizierbarkeit von Tupeln

# %%
my_tuple = ([1], [10])

# %%
# my_tuple[0] = [1, 2]

# %%
my_tuple[0].append(2)

# %%
my_tuple
# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Books
#
# We want to use tuples to represent books. Each book is stored a tuple containing
# the author (as string), title (as string) and page number (as integer value).
#
# Represent George Orwell's 328-page book "1984" in this form and store it in
# a variable named `orwell`.

# %%
orwell = ("1984", "George Orwell", 328)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Build a list from the mentioned book "1984", as well as
#
# - Catch-22 by Joseph Heller (453 pages)
# - Fahrenheit 451 by Ray Bradbury (256 pages)
#
# and assign it to a variable `books`.

# %%
books = [
    orwell,
    ("Catch-22", "Joseph Heller", 453),
    ("Fahrenheit 451", "Ray Bradbury", 256),
]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Write functions `title(book)`, `author(book)` and `pages(book)` that return the
# title, author and number of pages in a book.
#
# Test the functions with the book "1984".


# %%
def title(book) -> str:
    return book[0]


# %%
assert title(orwell) == "1984"


# %%
def author(book) -> str:
    return book[1]


# %%
assert author(orwell) == "George Orwell"


# %%
def pages(book) -> int:
    return book[2]


# %%
assert pages(orwell) == 328


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Write a function `get_short_books(books)` that takes a list of books as argument
# and returns a list of those books that have less than 300 pages:
#
# ```python
# >>> get_short_books(books)
# [('Fahrenheit 451', 'Ray Bradbury', 256)]
# ```

# %%
def get_short_books(books):
    result = []
    for book in books:
        if pages(book) < 300:
            result.append(book)
    return result


# %% tags=["keep"]
assert get_short_books(books) == [("Fahrenheit 451", "Ray Bradbury", 256)]


# %% tags=["alt"]
def get_short_books_2(books):
    return [book for book in books if pages(book) < 300]


# %% tags=["alt"]
assert get_short_books(books) == [("Fahrenheit 451", "Ray Bradbury", 256)]
