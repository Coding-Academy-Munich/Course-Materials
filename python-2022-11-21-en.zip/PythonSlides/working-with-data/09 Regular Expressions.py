# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Regular Expressions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 Regular Expressions.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_120_data_types/topic_220_a4_regular_expressions.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Finding and replacing in strings

# %% tags=["keep"]
tongue_twister = (
    "How much wood would a woodchuck chuck, if a woodchuck could chuck wood?"
)

# %%
first_index = tongue_twister.index("wood")
first_index

# %%
tongue_twister[first_index : first_index + len("wood")]

# %%
print(first_index)
print(first_index + len("wood"))

# %%
# tongue_twister[9:13] = "coffee"

# %%
tongue_twister[:9] + "coffee" + tongue_twister[13:]

# %%
tongue_twister.index("wood", first_index + 1)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Finding with regular expressions

# %%
import re

# %%
re.findall("wood", tongue_twister)

# %%
result = re.search("wood", tongue_twister)
result

# %%
start, end = result.span()
print("start:", start)
print("end:", end)

# %%
result.start()

# %%
result.end()

# %%
result = re.search("wood", tongue_twister[end:])
result

# %%
tongue_twister[end:][result.start() :]

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Replacing with regular expressions

# %%
re.sub("wood", "coffee", tongue_twister)

# %%
re.sub("wood ", "coffee ", tongue_twister)

# %%
re.sub("wood\\W", "coffee", tongue_twister)

# %%
re.sub("wood(\\W)", "coffee\\1", tongue_twister)

# %%
re.sub(r"wood(\W)", r"coffee\1", tongue_twister)

# %%
wood_rx = re.compile("wood")
type(wood_rx)

# %%
wood_rx.findall(tongue_twister)

# %%
wood_rx.search(tongue_twister)

# %%
wood_rx.search(tongue_twister, 13)

# %%
wood_rx2 = re.compile(r"\bwood\b")

# %%
wood_rx2.sub(r"coffee", tongue_twister)

# %%
def annotate(match):
    return f"{match.group()}[{match.start()}-{match.end()}]"


# %%
wood_rx2.sub(annotate, tongue_twister)

# %%
four_letter_word_rx = re.compile(r"\b\w{4}\b")

# %%
four_letter_word_rx.sub("XXXX", tongue_twister)

# %%
any_length_rx = re.compile(r"\w*")

# %%
def x_out(match):
    return "X" * (match.end() - match.start())


# %%
any_length_rx.sub(x_out, tongue_twister)

# %%
short_word_rx = re.compile(r"\b\w{1,4}\b")

# %%
short_word_rx.sub(lambda m: "X" * len(m.group()), tongue_twister)

# %%
long_word_rx = re.compile(r"\b\w{5,}\b")

# %%
long_word_rx.sub(lambda m: m.group().upper(), tongue_twister)

# %%
long_word_rx.search(tongue_twister)

# %%
long_word_rx.search("To be or not to be?")

# %%
long_word_rx.search("To be or not to be?") is None

# %%
double_vocal_rx = re.compile(r"\w*([aeiou]{2})\w*")

# %%
match = double_vocal_rx.search(tongue_twister)
match

# %%
match.group(0)

# %%
match.group(1)

# %%
match = double_vocal_rx.search(tongue_twister, 13)
match

# %%
match.group(0)

# %%
match.group(1)

# %%
email_rx = re.compile(r"([\w._+-]+)@([\w._+-]+)", re.IGNORECASE)

# %%
match = email_rx.match("joe.cool@people.example.com")

# %%
match.group(0, 1, 2)

# %%
email_rx.match("Email: joe.cool@people.example.com") is None

# %%
match = email_rx.match("joe-cool+123@my_domain.example.com or something")

# %%
match.group(0, 1, 2)

# %%
match = email_rx.fullmatch("joe-cool+123@my_domain.example.com")

# %%
match.group(0, 1, 2)

# %%
email_rx.fullmatch("joe-cool+123@my_domain.example.com or something")
