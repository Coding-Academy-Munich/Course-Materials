# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Pathlib</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">07 Pathlib.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_310_working_with_data/topic_114_a1_pathlib.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Object-oriented handling of files: Pathlib
#
# The `pathlib` module offers a very elegant `Path` class
# that offers an object-oriented approach to handling files:

# %%
from pathlib import Path

# %%
my_path = Path()
print("relative path:", my_path)
print("absolute path:", my_path.absolute())
my_path

# %%
my_file = my_path / "README.md"
print("Name:         ", my_file.name)
print("Parent:       ", my_file.parent.absolute())
print("Suffix:       ", my_file.suffix)
print("Change suffix:", my_file.with_suffix(".txt"))
print("Exists?       ", my_file.exists())

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
tmp_dir = Path.home() / "Tmp"
print(tmp_dir.absolute())
print(tmp_dir.exists())

# %%
assert not tmp_dir.exists()
my_dir = tmp_dir / "subdir1/subdir2" / "subdir3"
my_dir.mkdir(parents=True, exist_ok=False)
my_dir.exists()

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
my_file = my_dir / "test.txt"
with my_file.open("w", encoding="utf-8") as file:
    file.write("Hello, world")
print("Exists?", my_file.exists())
print(list(my_dir.glob("*")))
my_file.unlink()
print("Exists?", my_file.exists())
print(list(my_dir.glob("*")))
my_file.unlink(missing_ok=True)

# %%
if my_dir.exists():
    my_dir.rmdir()
print("Exists?", my_dir.exists())

# %%
import shutil

shutil.rmtree(tmp_dir, ignore_errors=True)


# %%
tmp_dir.exists()
