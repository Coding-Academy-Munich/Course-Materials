# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>JSON</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 JSON.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_310_working_with_data/topic_220_a4_json.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # JSON
#
# Python offers a built-in package `json` that can be used to translate JSON data
# into Python data structures.

# %% tags=["keep"]
import json
import os
from dataclasses import dataclass
from pprint import pprint
from tempfile import NamedTemporaryFile

# %% tags=["keep"]
json_data = """\
{"menu": {
  "id": "file",
  "value": "File",
  "menuitems": [
      {"value": "New", "onclick": "CreateNewDoc()"},
      {"value": "Open", "onclick": "OpenDoc()"},
      {"value": "Close", "onclick": "CloseDoc()"}
  ]
}}
"""

# %%
type(json_data)

# %%
data = json.loads(json_data)

# %%
type(data)

# %%
pprint(data)

# %%
json_dump = json.dumps(data)

# %%
type(json_dump)

# %5
print(json_dump)

# %%
print(json.dumps(data, indent=4))

# %%
json_file = NamedTemporaryFile(mode="w+", encoding="utf-8", delete=False)

# %%
json.dump(data, json_file)

# %%
json_file.tell()

# %%
json_file.seek(0)

# %%
loaded_data = json.load(json_file)

# %%
json_file.tell()

# %%
loaded_data == data

# %%
json_file.close()

# %%
os.remove(json_file.name)


# %% tags=["keep"]
@dataclass
class Menu:
    id: str
    value: str
    items: list["MenuItem"]

    @staticmethod
    def from_dict(d):
        return Menu(
            d["id"], d["value"], [MenuItem.from_dict(m) for m in d["menuitems"]]
        )


# %% tags=["keep"]
@dataclass
class MenuItem:
    value: str
    onclick: str

    @staticmethod
    def from_dict(d):
        return MenuItem(d["value"], d["onclick"])


# %%
def menu_hook(d: dict):
    print(f"Menu hook: {d}")
    if "menu" in d:
        return Menu.from_dict(d["menu"])
    return d


# %%
my_menu = json.loads(json_data, object_hook=menu_hook)

# %%
my_menu


# %%
# json.dumps(my_menu)

# %%
def menu_serializer(obj):
    if isinstance(obj, Menu):
        return {
            "menu": {
                "id": obj.id,
                "value": obj.value,
                "menuitems": obj.items,
            }
        }
    if isinstance(obj, MenuItem):
        return {"value": obj.value, "onclick": obj.onclick}
    return obj


# %%
print(json.dumps(my_menu, default=menu_serializer, indent=2))


# %%
class MenuEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Menu):
            return {"menu": {"id": obj.id, "value": obj.value, "menuitems": obj.items}}
        elif isinstance(obj, MenuItem):
            return {"value": obj.value, "onclick": obj.onclick}
        return json.JSONEncoder.default(self, obj)


# %%
json.dumps(my_menu, cls=MenuEncoder)
