# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>XML</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 XML.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_310_working_with_data/topic_230_a4_xml.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## The XML Package
#
# See the [Python documentation](https://docs.python.org/3/library/xml.etree.elementtree.html#module-xml.etree.ElementTree)

# %%
from xml.etree import ElementTree
from tempfile import NamedTemporaryFile
import os

# %%
xml_data = """\
<?xml version="1.0"?>
<data>
    <country name="Liechtenstein">
        <rank>1</rank>
        <year>2008</year>
        <gdppc>141100</gdppc>
        <neighbor name="Austria" direction="E"/>
        <neighbor name="Switzerland" direction="W"/>
    </country>
    <country name="Singapore">
        <rank>4</rank>
        <year>2011</year>
        <gdppc>59900</gdppc>
        <neighbor name="Malaysia" direction="N"/>
    </country>
    <country name="Panama">
        <rank>68</rank>
        <year>2011</year>
        <gdppc>13600</gdppc>
        <neighbor name="Costa Rica" direction="W"/>
        <neighbor name="Colombia" direction="E"/>
    </country>
</data>
"""

# %%
xml_file = NamedTemporaryFile(mode="w", delete=False)
xml_file.write(xml_data)
xml_file.close()

# %%
tree = ElementTree.parse(xml_file.name)

# %% tags=["keep"]
os.remove(xml_file.name)

# %%
tree

# %%
root = tree.getroot()
root

# %%
root.tag

# %%
root.attrib

# %%
for child in root:
    print(child.tag, child.attrib)

# %%
root[0]

# %%
root[0][1]

# %%
root[0][1].text

# %% [markdown] lang="en"
# ## LXML
#
# [LXML](https://lxml.de/index.html) is an alternative with (possibly) higher performance.

# %% tags=["keep"]
