# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Quickstart: Control Flow</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Quickstart_ Control Flow.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_140_control_flow/topic_120_c3_control_flow.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Boolean values and `if` statements

# %% tags=["keep"]
def check(value):
    if value:
        print(f"{value} is true.")
    else:
        print(f"{value} is false.")


# %%
check(True)

# %%
check(False)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### `if`/`elif`/`else`

# %%
text = "This is a text"


# %%
if len(text) <= 5:
    print("This is a very short text!")
elif len(text) < 20:
    print("That's a decent amount of text.")
else:
    print("That's a quite long text.")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Truthiness
#
# The `if` statement can take any Python value as an argument,
# not just Boolean values.
#
# The following values are considered *not true*
#
# - `None` and `False`
# - `0` and `0.0` (and null values of other number types)
# - Empty strings, sequences and collections: ``
# - Some values of user-defined data types
#
# All other values are considered true.


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def check(value):
    if value:
        print(f"{value!r} is truthy.")
    else:
        print(f"{value!r} is falsy.")


# %%
check(True)

# %%
check(False)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
check(None)

# %%
check(0)

# %%
check(1)

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
check("")

# %%
check("123")

# %%
check([])

# %%
check([1, 2, 3])


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## How is this used?

# %%
def print_elements(collection):
    if collection:
        for elt in collection:
            print(elt)
    else:
        print(f"{collection} has no elements!")


# %%
print_elements([1, 2, 3])

# %%
print_elements([])
# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Mini workshop
#
# Write a function `fits_in_line(text: str, line_length: int = 72)`,
# which returns `True` or `False` depending on whether `text` fits into a line of
# length `line_length`:
# ```python
# >>> fits_in_line("Hello")
# True
# >>> fits_in_line("Hello", 3)
# False
# >>>
# ```
#
# Ensure that your function satisfies the provided tests.
#
# Write a function `print_line(text: str, line_length:int = 72)`,
# that
# * prints `text` to the screen if that is possible in a line of length
#   `line_length`
# * prints `...` if that is not possible.
#
# ```python
# >>> print_line("Hello")
# Hello
# >>> print_line("Hello", 3)
# ...
# >>>
# ```

# %%
def fits_in_line(text: str, line_length: int = 72):
    return len(text) <= line_length


# %% tags=["keep"]
assert fits_in_line("Hallo")

# %% tags=["keep"]
assert not fits_in_line("Hallo", 3)


# %%
def print_line(text: str, line_length: int = 72):
    if fits_in_line(text, line_length=line_length):
        print(text)
    else:
        print("...")


# %% tags=["keep"]
# Hallo
print_line("Hallo")

# %% tags=["keep"]
# ...
print_line("Hallo", 3)

# %%
