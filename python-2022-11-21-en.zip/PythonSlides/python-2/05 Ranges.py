# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Ranges</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Ranges.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_150_collections/topic_125_b3_ranges.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Simulation of the traditional `for` loop
#
# Iteration with a `for` loop is also possible over data structures other than lists.
#
# In Python, the `range` type represents a sequence of integers:
#
# - `range(n)` generates the integer interval from $0$ to $n-1$
# - `range(m, n)` produces the integer interval from $m$ to $n-1$
# - `range(m,n,k)` produces the integer sequence $m, m+k, m+2k, ..., p$, where $p$ is
#    the largest number of the form $m + jk$ with $j \geq 0$ and $p < n$

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
range(1, 4)

# %%
list(range(1, 4))

# %%
range(4)

# %%
list(range(4))

# %%
list(range(1, 9, 2))

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
for i in range(3):
    print(i, end=", ")

# %%
for i in range(1, 6, 2):
    print(i, end=", ")


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Mini workshop
#
# Write a function `print_squares(n: int)` that prints the squares of the
# numbers from 1 to n, one element per line:
#
# ```python
# >>>print_squares(3)
# 1**2 = 1
# 2**2 = 4
# 3**2 = 9
# >>>
# ```

# %%
def print_squares(n: int):
    for i in range(1, n + 1):
        print(i, "**2 = ", i * i, sep="")


# %%
print_squares(3)
