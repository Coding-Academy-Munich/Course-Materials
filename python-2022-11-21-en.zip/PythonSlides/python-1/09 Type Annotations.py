# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Type Annotations</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 Type Annotations.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_130_b3_type_annotations.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Type annotations
#
# Python allows the types of function arguments and the return type to be specified:

# %%
def mult(a: int, b: float) -> float:
    return a * b


# %%
mult(3, 2.0)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Type annotations are for documentation only and are ignored by Python:

# %%
mult("a", 3)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Type Annotations
#
# Write a function `repeat(s: str, n: int) -> str` that returns the string `s`
# repeated `n` times:
#
# ```python
# >>> repeat("abc", 3)
# "abcabcabc"
# ```
#
# *Note:* You can use the multiplication operator `*` to repeat strings:
# ```python
# >>> "abc" * 3
# "abcabcabc"
#
#
# ```

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def repeat(s: str, n: int) -> str:
    return s * n


# %%
repeat("abc", 3)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - What happens if you call `repeat()` with two numbers?
# - What happens if you call `repeat()` with two strings?

# %%
repeat(3, 4)

# %%
repeat("abc", "def")
