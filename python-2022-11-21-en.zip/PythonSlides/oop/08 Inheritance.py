# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Inheritance</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Inheritance.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_200_object_orientation/topic_192_inheritance.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Inheritance
#
# We have implemented the following class:

# %% tags=["keep"]
import random


# %% tags=["keep"]
class Point:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    def __repr__(self):
        return f"Point({self.x:.1f}, {self.y:.1f})"

    def move(self, dx=0, dy=0):
        self.x += dx
        self.y += dy

    def randomize(self):
        self.x = random.gauss(2, 0.5)
        self.y = random.gauss(3, 0.5)


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
p = Point(1, 1)
p

# %% tags=["keep"]
p.move(2, 3)
p

# %% tags=["keep"]
p.randomize()
p


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# How can we introduce colored points without having to re-implement the
# entire functionality of `Point`?

# %%
class ColorPoint(Point):
    def __init__(self, x=0, y=0, color="black"):
        super().__init__(x, y)
        self.color = color

    def __repr__(self):
        return f"ColorPoint({self.x:.1f}, {self.y:.1f}, {self.color!r})"

    def randomize(self):
        super().randomize()
        self.color = random.choice(["black", "red", "green", "blue", "yellow", "white"])


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
cp = ColorPoint(2, 3)
# cp


# %% tags=["keep"]
assert cp.x == 2.0
assert cp.y == 3.0
assert cp.color == "black"

# %% tags=["keep"]
cp.color = "red"

# %% tags=["keep"]
assert cp.x == 2.0
assert cp.y == 3.0
assert cp.color == "red"

# %% tags=["keep"]
cp.move(2, 3)
# cp


# %% tags=["keep"]
assert cp.x == 4.0
assert cp.y == 6.0
assert cp.color == "red"

# %% tags=["keep"]
cp.randomize()
# cp

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Workshop: Employees
#
# In the following we will implement a class hierarchy for employees of a company:
#
# - Employees can be either workers or managers
# - Each employee of the company has a name, a personnel number and a
#   base salary
# - For each worker, the accumulated overtime and the hourly wage
#   are stored in attributes.
# - A worker's salary is calculated as 13/12 times the
#   base salary plus overtime pay
# - Each manager has an individual bonus
# - A manager's salary is calculated as 13/12 times the
#   base salary plus bonus
#
# Implement Python classes `Employee`, `Worker` and `Manager` with
# appropriate attributes and a method `salary()` that calculates the salary.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
from dataclasses import dataclass


# %%
@dataclass
class Employee:
    name: str
    id: str
    base_salary: float

    def salary(self):
        return 13 / 12 * self.base_salary


# %%
@dataclass
class Worker(Employee):
    overtime: float = 0.0
    hourly_wage: float = 0.0

    def salary(self):
        return super().salary() + self.overtime * self.hourly_wage


# %%
@dataclass
class Manager(Employee):
    bonus: float

    def salary(self):
        return super().salary() + self.bonus


# %% [markdown]
#
# Create a worker named Hans, personnel number 123, a base salary of
# 36000.0 Euros, who worked 3.5 hours of overtime at 40.0 euros each.
# Print out the salary.

# %%
a = Worker("Hans", "123", 36_000, 3.5, 40.0)
print(a.salary())
a

# %% [markdown]
#
# Schreiben sie Assertions, die die Funktionalität der Klasse `Worker` testen.

# %% [markdown]
#
# Write assertions to test the functionality of the class `Worker`.

# %%
# These assertions are superfluous!
assert a.name == "Hans"
assert a.id == "123"
assert a.base_salary == 36_000
assert a.overtime == 3.5
assert a.hourly_wage == 40.0

# This is the assertion that should be present
assert a.salary() == 39_140.0

# %% [markdown] lang="en"
# Create a manager named Sepp, personnel number 834, who is a
# base salary of 60000.0 euros and a bonus of 30000.0 euros. Print out
# the salary.

# %%
m = Manager("Sepp", "834", 60_000.0, 30_000.0)
print(m.salary())
m

# %% [markdown] lang="en"
# Test the functionality of the class `Manager`.

# %%
assert m.salary() == 95_000.0


# %% [markdown] lang="en" tags=["alt"]
# ## Solution without dataclasses:

# %% tags=["alt"]
class Employee:
    def __init__(self, name, pers_nr, base_salary):
        self.name = name
        self.pers_nr = pers_nr
        self.base_salary = base_salary

    def salary(self):
        return 13 / 12 * self.base_salary


# %% tags=["alt"]
class Worker(Employee):
    def __init__(self, name, pers_nr, base_salary, overtime, hourly_wage):
        super().__init__(name, pers_nr, base_salary)
        self.overtime = overtime
        self.hourly_wage = hourly_wage

    def __repr__(self):
        return (
            f"Worker({self.name!r}, {self.pers_nr!r}, {self.base_salary}, "
            f"{self.overtime}, {self.hourly_wage})"
        )

    def salary(self):
        return super().salary() + self.overtime * self.hourly_wage


# %% tags=["alt"]
class Manager(Employee):
    def __init__(self, name, pers_nr, base_salary, bonus):
        super().__init__(name, pers_nr, base_salary)
        self.bonus = bonus

    def __repr__(self):
        return (
            f"Manager({self.name!r}, {self.pers_nr!r}, {self.base_salary}, "
            f"{self.bonus})"
        )

    def salary(self):
        return super().salary() + self.bonus


# %% tags=["alt"]
a = Worker("Hans", 123, 36_000, 3.5, 40)

# %%
assert a.salary() == 39_140.0

# %% tags=["alt"]
m = Manager("Sepp", 834, 60_000, 30_000)

# %%
assert m.salary() == 95_000.0
