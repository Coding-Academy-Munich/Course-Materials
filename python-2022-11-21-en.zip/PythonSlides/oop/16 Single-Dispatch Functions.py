# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Single-Dispatch Functions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">16 Single-Dispatch Functions.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_200_object_orientation/topic_240_single_dispatch.py</div> -->
#
#

# %% [markdown] lang="en"
#
# ## Single dispatch functions
#
# Single dispatch functions allow "methods" to be defined outside of classes,
# i.e. one can define functions that are polymorphic in their first argument.
#
# This mechanism allows the flexible extension of already existing classes.

# %% tags=["keep"]
from functools import singledispatch
from typing import Protocol, runtime_checkable


# %% tags=["keep"]
class Mage:
    def __init__(self, name="The Mage"):
        self.name = name

    def cast_spell(self, spell):
        print(f"{self.name} casts a {spell} spell.")


# %% tags=["keep"]
class Fighter:
    @property
    def name(self):
        return "The Fighter"

    def hit(self, opponent, weapon):
        print(f"{self.name} attacks {opponent} with {weapon}.")


# %% tags=["keep"]
class Bard:
    def __init__(self, name="The Bard"):
        self.name = name


# %% tags=["keep"]
p1 = Mage()
p2 = Fighter()
p3 = Bard()


# %%%% tags=["keep"]
@runtime_checkable
class HasName(Protocol):
    @property
    def name(self) -> str:
        ...


# %%
@singledispatch
def attack(player: HasName, opponent):
    print(f"{player.name} just stares at the carnage.")


# %%
@attack.register
def _(player: Mage, opponent):
    player.cast_spell("fireball")


# %%
@attack.register
def _(player: Fighter, opponent):
    player.hit(opponent, "sword")


# %%
attack(p1, "The Baddie")

# %%
attack(p2, "The Baddie")

# %%
attack(p3, "The Baddie")
