Cliparts taken from [Open Clip Art](https://openclipart.org):

- [home page](https://openclipart.org/detail/203567/utopic-unicorn) (Bro666)
- [blog page](https://openclipart.org/detail/273480/winged-unicorn-line-art) (GDJ)
- [unused](https://openclipart.org/detail/246933/unicorn-silhouette-2) (GDJ)
