# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Commonly Used Functions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Commonly Used Functions.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_340_d4_functional_programming.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Commonly Used Functions

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "Valid Groups"
#
# For an event, groups should only be admitted if
# - either all participants are at least 18 years old or
# - there is at least one teacher in the group
# Implement a  function `is_valid_group(group: list[Person])` that checks this.


# %% tags=["keep"]
from dataclasses import dataclass


# %% tags=["keep"]
@dataclass
class Person:
    age: int
    profession: str = "unknown"


# %% tags=["keep"]
group1 = [Person(23), Person(42), Person(84, "doctor"), Person(29)]
group2 = [Person(12), Person(13), Person(53, "teacher"), Person(11)]
group3 = [Person(12), Person(32)]

# %%

# %% tags=["keep"]
assert is_valid_group(group1)

# %% tags=["keep"]
assert is_valid_group(group2)

# %% tags=["keep"]
assert not is_valid_group(group3)

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "Seating Arrangements"
#
# In an event with 4 participants, how many ways are there to allocate the
# participants to the seats if there are 5 numbered seats?
#
# Does your implementation scale to larger events?

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
