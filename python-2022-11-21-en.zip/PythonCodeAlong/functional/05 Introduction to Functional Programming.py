# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Introduction to Functional Programming</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Introduction to Functional Programming.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_320_d4_functional_programming_intro.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # Introduction to Functional Programming
#
# Traditionally functional programming is characterized by the following features:
# - First-class and higher-order functions
# - Immutable data types (immutable data types)
# - Recursion instead of iteration

# %%

# %%

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop "mean computation"
#
# Write a function `fact(n: int)` that calculates the product of the numbers from 1
# to `n`.

# %%

# %% tags=["keep"]
assert fact(3) == 6

# %% tags=["keep"]
assert fact(10) == 3628800

# %% tags=["keep"]
assert fact(50) == 30414093201713378043612608166064768844377641568960512000000000000


# %%

# %%

# %%

# %% tags=["keep"]
class LispList:
    pass


# %% tags=["keep"]
class Nil(LispList):
    def __repr__(self):
        return "nil"


# %% tags=["keep"]
nil = Nil()


# %%

# %% tags=["keep"]
class Cons(LispList):
    def __init__(self, first, rest):
        self.first = first
        self.rest = rest

    def __repr__(self):
        return f"({self.first}{self.rest_to_str()})"

    def rest_to_str(self) -> str:
        if isinstance(self.rest, Nil):
            return ""
        elif isinstance(self.rest, Cons):
            return f" {self.rest.first}{self.rest.rest_to_str()}"
        else:
            return f" . {self.rest}"


# %% tags=["keep"]
nil

# %% tags=["keep"]
Cons(1, Nil())

# %% tags=["keep"]
Cons(1, Cons(2, Nil()))

# %% tags=["keep"]
Cons(1, Cons(2, Cons(3, Nil())))

# %% tags=["keep"]
Cons(1, 2)


# %% tags=["keep"]
def lisp_list(*args):
    def build_list(elements):
        if len(elements) > 0:
            return Cons(elements[0], build_list(elements[1:]))
        else:
            return Nil()

    return build_list(args)


# %% tags=["keep"]
lisp_list(1, 2, 3)

# %% tags=["keep"]
lisp_ints = lisp_list(*range(10))
lisp_ints

# %% tags=["keep"]
is_empty(nil)

# %% tags=["keep"]
is_empty(lisp_ints)

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# ## Problems with recursion in Python

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# ## Benefits of a functional programming style
#
# - Compositionality
# - Modularity
# - Ease of testing and debugging
