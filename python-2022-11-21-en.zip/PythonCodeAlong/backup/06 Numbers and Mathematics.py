# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Numbers and Mathematics</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Numbers and Mathematics.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_120_data_types/topic_120_b1_numbers.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Numbers and maths
#
# - Integers: `1`, `837`, `-12`
# - Floating point numbers: `0.5`, `123.4`, `-0.01`
# - Arithmetic operations:
#     - Addition: `+`
#     - Subtraction: `-`
#     - Multiplication: `*`
#     - Division: `/`

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Python as pocket calculator

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Different types of numbers
#
# - Python distinguishes integers and floating point numbers:
#     - `1` is an integer (`int`)
#     - `1.0` is a floating point number (`float`)
# - With `type(...)` you can get the type of the argument:

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Integers in Python have no (practically relevant) upper limit:

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Arithmetic operations
#
# | Operator | Operation            |
# |:--------:|:---------------------|
# | +        | Sum                  |
# | -        | Difference           |
# | *        | Multiplication       |
# | /        | Division             |
# | **       | Power                |
# | %        | Modulo, Remainder    |
# | //       | Integer division     |

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Division

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# `/` is left-associative (just like `//`, `%`, `+`, `-`, `*`)

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Exponentiation (power)

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# `**` is right-associative
#
# $2^{(2^3)} = 2^8 = 256 \qquad$
# $(2^2)^3 = 4^3 = 64$

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# The `**` operator can also be used to extract roots:
#
# $\sqrt{4} = 4^{1/2} = 2$
# $\sqrt{9} = 9^{1/2} = 3$
# $\sqrt{2} = 2^{1/2} \approx 1.4142$

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Mini-Workshop: Numbers and mathematics
#

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# How can you represent the number `32` in Python?


# %%

# %% [markdown] lang="en"
# How can you determine the type of `14` in Python?

# %%

# %% [markdown] lang="en"
# How can you determine the type of `14.0` in Python?

# %%

# %% [markdown] lang="en"
# How can you determine the type of `"14"' in Python?

# %%

# %% [markdown] lang="en"
# What is the value of `1 + 2 * 3`?

# %%

# %% [markdown] lang="en"
# What is the type of `1 + 2 * 3` in Python?

# %%

# %% [markdown] lang="en"
# What is the value of `4 / 2` in Python?

# %%

# %% [markdown] lang="en"
# What is the type of `4 / 2` in Python?

# %%

# %% [markdown] lang="en"
# What is the value and type of `1 + 1.0` in Python? Can you determine the data type
# without using `type`, just by looking at the output?

# %%
