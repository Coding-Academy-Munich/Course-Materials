# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Built-in Functions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 Built-in Functions.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_120_data_types/topic_140_b1_built_in_functions.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Built-in functions
#
# Some functions in Python are
# [predefined](https://docs.python.org/3/library/functions.html#built-in-functions)
# by the interpreter. Many more can be loaded from modules.

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Type conversions
#
# - Python does not perform automatic data type conversions.
# - However, you can often explicitly request out the conversion.

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Virtually any object in Python can be converted into a string:

# %%

# %% [markdown] lang="en"
#
# But of course there are cases where Python cannot convert the argument into the
# desired type:

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Other built-in functions

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %% tags=["keep"]
print(round(0.5), round(1.5), round(2.5), round(3.5))

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mini-workshop: Built-in Functions
#
# In this workshop your goal is to solve some tasks with predefined functions.
# Some of these functions have not yet been discussed. Use the [built-in-functions
# table](https://docs.python.org/3/library/functions.html#built-in-functions) to find
# suitable candidates.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Convert the number `1.5` into a string.

# %%

# %% [markdown] lang="en"
#
# Find the maximum of the numbers 2.5 and 1.7 using a built-in function.

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Convert the string "1.234" into a floating point number and add `2.345`.

# %%
