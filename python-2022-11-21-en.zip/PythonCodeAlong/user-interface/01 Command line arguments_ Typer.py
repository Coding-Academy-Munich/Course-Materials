# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Command line arguments: Typer</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Command line arguments_ Typer.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_350_cli/topic_110_command_line_arguments.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Processing Command Line Arguments: Argparse and Typer
#
#  - A command line application is sufficient for many applications
#  - Manual processing of command-line arguments is relatively time-consuming
#  - With `argparse`, Python offers a very good library that significantly simplifies many common use cases
#  - Even better: [Typer](https://typer.tiangolo.com/)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Components of Typer:
#
# - Class `app = typer.Typer()` to connect your own classes to Typer.
# - Decorator `app.command()` to define function commands.
# - Function parameters become positional arguments or named options.
# - Many functions of CLI applications are generated automatically by Typer.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Workshop
#
# - `Workshop_136_todo_list_v3`
# - Up to section "Command Line Arguments"
