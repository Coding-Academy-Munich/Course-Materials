# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>More Strings</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">10 More Strings.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_120_data_types/topic_230_a3_more_strings.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Comparison of strings

# %% tags=["keep"]
"a" == "a"

# %% tags=["keep"]
"A" == "a"

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
"A" < "B"

# %% tags=["keep"]
"A" < "a"

# %% tags=["keep"]
"a" < "A"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Strings are ordered as in the dictionary (lexicographically).

# %% tags=["keep"]
"ab" < "abc"

# %% tags=["keep"]
"ab" < "ac"

# %% tags=["keep"]
"ab" != "ac"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Inset: sorting lists/iterables
#
# Iterables can be sorted with the `sorted()` function. With the
# named argument `key`, a function can be specified that determines
# how the sorting is done:

# %% tags=["keep"]
numbers = [3, 8, -7, 1, 0, 2, -3, 3]

# %%

# %%

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
strings = ["a", "ABC", "xy", "Asdfgh", "foo", "bar", "quux"]

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Comparison of Unicode strings
#
# The built-in comparison functions work only for simple (ASCII) strings. For strings containing Unicode characters, sorting/comparison is more difficult.
#
# The default module for dealing with Unicode in Python is `locale`; it relies on the locale settings of the
# operating system:

# %%

# %% tags=["keep"]
my_strings = ["o", "oa", "oe", "ö", "oz", "sa", "s", "ß", "ss", "sz"]

# %%

# %%

# %% tags=["keep"]
locale.setlocale(locale.LC_COLLATE, "de_DE.UTF-8")

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# The locale settings are global per process and therefore mainly suitable
# to interact with the user.
#
# If you have to deal with strings in different languages,
# using libraries like `PyUCA` (written in Python and therefore
# easier to install) or `PyICU` (more complete implementation of the
# Unicode specification based on a C++ library) might be a good idea.

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # String literals (again)
#
# - String literals are enclosed in single or double quotes
#     - `"Hello, world!"`
#     - `'Hello world!'`
#     - It doesn't matter which form you choose, unless you want to
#       have double quotes in the string
#     - `"He says 'Huh?'"`
#     - `'She replies: "Exactly."'`

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - String literals, can contain Unicode characters:
#     - `"おはようございます"`
#     - `"😠🙃🙄"`

# %% tags=["keep"]
print("Er sagt 'Huh?'")
print('Sie antwortet: "Genau."')
print("おはようございます")
print("😠🙃🙄")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - Special characters can be specified with *escape notation*:
#     - `
# `, `\t`, `\`, `"`, `\'`, ...
#     - `\u`, `\U` for Unicode code points (16 or 32 bit)
#     - `\N{...}` for Unicode

# %% tags=["keep"]
print("a\tbc\td\n123\t4\t5")

# %% tags=["keep"]
print('"Let\'s go crazy", she said')

# %% tags=["keep"]
print("C:\\Users\\John")

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
print("\u0394 \u03b1 \t\U000003b2 \U000003b3")
print("\U0001F62E \U0001f61a \U0001f630")

# %% tags=["keep"]
print("\N{GREEK CAPITAL LETTER DELTA} \N{GREEK SMALL LETTER ALPHA}")
print("\N{smiling face with open mouth and smiling eyes} \N{winking face}")

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - String literals can also be enclosed in triple quotes
# - This type of literal can span multiple lines

# %% tags=["keep"]
"""Das ist
ein String-Literal,
das über mehrere
Zeilen geht."""

# %% tags=["keep"]
print(
    """Mit Backslash am Ende der Zeile \
kann der Zeilenvorschub unterdrückt werden."""
)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Concatenation of strings
#
# Strings can be concatenated with `+`:

# %% tags=["keep"]
"Ein" + " " + "String"
# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## String comparison (again)
#
# To compare strings with Unicode characters, it is convenient to use them in
# bring Unicode normal form.

# %% tags=["keep"]
s1 = "café"
s2 = "cafe\u0301"

# %%

# %% tags=["keep"]
import unicodedata

unicodedata.normalize("NFC", s1) == s1

# %%

# %%


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Finding substrings in strings
#
# The `in` operator also works with strings as arguments. To find the index
# of a substring in a string you can use the `index()` method.

# %%

# %%

# %%

# %%

# %%

# %%

# %%
