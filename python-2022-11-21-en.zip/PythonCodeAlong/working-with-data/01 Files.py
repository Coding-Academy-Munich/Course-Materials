# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Files</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">01 Files.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_310_working_with_data/topic_110_a2_files.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Files
#
# So far, all data that we have calculated is lost at the end of the program execution.
#
# The easiest way to persist data is to save it in a file.
#
# Before executing any code in this notebook, please verify that your current working
# directory does not contain any important data!

# %% tags=["keep"]
import os

# %% tags=["keep"]
os.getcwd()

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - With `open()` a file can be opened for reading or writing.
# - The `mode` parameter specifies whether the file is open for reading or writing
#   will:
#   - `r`: read
#   - `w`: writing. The content of the file is deleted
#   - `a`: writing. The new data is written at the end of the file.
#   - `x`: write. The file must not exist.
#   - `r+`: read and write.
# - If the letter `b` is appended to the end of `mode`, the file is saved as
#   binary file.

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
file = open("my-data-file.txt", "w")
file.write("The first line.\n")
file.write("The second line.\n")
file.close()

# %% tags=["keep"]
file = open("my-data-file.txt", "r")
contents = file.read()
file.close()
print(contents)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Files must always be closed with `close()`, even if the part of the program
#   in which the file is used throws an exception.
# - This could be done with `try ... finally`.
# - Python offers a more elegant construct for this:

# %% tags=["keep"]
with open("my-data-file.txt", "r") as file:
    contents = file.read()
print(contents)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Mode-Values for writing


# %% tags=["keep"]
with open("my-data-file.txt", mode="w") as file:
    file.write("Another line.\n")
    file.write("Yet another line.\n")

# %% tags=["keep"]
with open("my-data-file.txt", mode="r") as file:
    contents = file.read()
print(contents)

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
with open("my-data-file.txt", mode="a") as file:
    file.write("Let's try this again.\n")
    file.write("Until we succeed.\n")

# %% tags=["keep"]
with open("my-data-file.txt", "r") as file:
    contents = file.readlines()
print(contents)

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
# with open("my-data-file.txt", mode="x") as file:
#     file.write("Let's try this again.\n")
#     file.write("Until we succeed.\n")


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Mini-Workshop:  Reading and writing to files
#
# Write a function `write_text_to_file(text: str, file_name: str) -> None`,
# which writes the string `text` to the file `file_name` if the file *does not*
# exist and throws an exception of type `FileExistsError`,
# if the file exists.
#
# *Note:* Note the possible values for the `mode` argument of `open()`.

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Test the function by trying to write the text `Python 3.11` to the file
# `my-private-file.txt` twice in a row.

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Write a function `annotate_file(file_name: str) -> None` which
# - Prints out the content of the file `file_name` followed by the text
#   `(annotated version)` if the file exists
# - Prints out the text `No file found, we will bill the time we spent searching.`
#   if the file doesn't exist
#
# In both cases the text `Our invoice will be sent by mail.` is printed out.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%
