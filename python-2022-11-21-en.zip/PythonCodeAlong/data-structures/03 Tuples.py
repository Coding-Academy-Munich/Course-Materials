# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Tuples</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Tuples.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_150_collections/topic_150_b1_tuples.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Tuples
#
# Tuples are similar to lists but cannot be destructively modified. Functions
# and methods on lists that don't modify the list destructively are generally
# also available for tuples.


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Tuple literals
#
# - Elements separated by commas: `1, 2, 3, 4`
# - In many cases, tuples must be enclosed in parens: `(1, 2, 3)`


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Empty tuple


# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Singleton tuple


# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Heterogeneous tuple

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Operations on tuples
#
# - Many of the operations on lists can be applied to tuples.
# - The operations that change lists are not applicable.


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Constructing tuples

# %% tags=["keep"]
values = (1, 2, 3)
values

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Concatenation of tuples

# %% tags=["keep"]
values = (1, 2, 3)

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Tuples and indexing

# %% tags=["keep"]
values = (1, 2, 3)

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Functions and methods

# %% tags=["keep"]
values = (1, 2, 3, 1, 2, 1, 2)

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Looping over tuples

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Illegal operations


# %% tags=["keep"]
values = (1, 2, 3)

# %%

# %%
# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Random Tuples
#
# The following statements generate a tuple of random numbers of
# random length:

# %% tags=["keep"]
import random

random.seed(2022)
my_tuple = random.choices(range(1000), k=random.randint(5_000, 15_000))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# How many elements does `my_tuple` contain?

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Does the number 1 appear in `my_tuple`? If so, at which index is its first occurrence?

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Print a table of how many times each of the numbers 0 through 9 occurs
# in `my_tuple`.

# %%
