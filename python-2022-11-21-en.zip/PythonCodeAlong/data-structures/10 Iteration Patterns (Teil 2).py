# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Iteration Patterns (Teil 2)</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">10 Iteration Patterns (Teil 2).py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_150_collections/topic_158_b3_iteration_patterns2.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Transformation of lists

# %%

# %%

# %% [markdown] lang="en"
# ## Mini-Workshop: Square numbers
#
# Given the following list of numbers.

# %% lang="en" tags=["keep"]
numbers = [1, 7, 4, 87, 23]

# %% [markdown] lang="en"
# Create a new list containing the squares of the numbers in `numbers`.

# %% lang="en"

# %% [markdown] lang="en"
# Write a function `square(numbers)` that returns a new list with the
# squares the numbers in `numbers`.

# %% lang="en"

# %% lang="en"
