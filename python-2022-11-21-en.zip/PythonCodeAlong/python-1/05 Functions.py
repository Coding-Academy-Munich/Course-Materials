# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Functions</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">05 Functions.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_110_c3_functions.py</div> -->
#
#

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Functions

# %%

# %%

# %%

# %%

# %% tags=["keep"]
print(my_round(0.5), my_round(1.5), my_round(2.5), my_round(3.5))


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Mini workshop
#
# Write a function `greeting(name)` that prints a greeting in the form
# "Hello *name*!" to the screen, e.g.
# ```python
# >>> greeting("Max")
# Hi Max!
# >>>
# ```

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Methods

# %%

# %%

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Default and keyword arguments

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Type annotations

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Type annotations can contain parametric types, optional types, etc.
# (*Note:* in older Python versions, `list` cannot take type parameters.)

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%
