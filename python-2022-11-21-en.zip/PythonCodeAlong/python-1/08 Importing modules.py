# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Importing modules</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Importing modules.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_115_a3_modules.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Importing modules
#
# Much of Python's functionality is not implemented in the interpreter itself
# but rather provided by external modules (and packages). The default Python
# distribution includes more than 200 such modules.
#
# With the `import` statement you can make this functionality available:

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The functions from the `math` module can then be accessed with the syntax
# `math.floor`:

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# In a previous video we defined the following function to calculate the length of
# the hypotenuse in a right triangle from the two legs:

# %% tags=["keep"]
def pythagoras(a, b):
    c = (a**2 + b**2) ** 0.5
    return c

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The `pythagoras` function is available from the `math` module under the name `hypot`:

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# With the syntax `from`...`import`, names from a module can be imported into
# the current namespace:

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Modules can be renamed during import:

# %%

# %%

# %% [markdown] lang="en"
#
# Similarly for names imported with `from`:

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Modules
#

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# In the [`os` module](https://docs.python.org/3/library/os.html),
# Python implements functions that provide information about the
# operating system used and the environment of the Python process.
#
# Use the `getcwd()` function from the `os` module to get the working directory of
# the running Python process.

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Use the `cpu_count()` function from the `os` module to determine how many
# CPU cores your computer has (according to Python).

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The [`random` module](https://docs.python.org/3/library/random.html) offers
# various random number generators. Use its `randint()` function  to generate an
# integer between 1 and 6 (inclusive).
#
# Evaluate the cell several times to see that different numbers are generated.


# %%

# %%
