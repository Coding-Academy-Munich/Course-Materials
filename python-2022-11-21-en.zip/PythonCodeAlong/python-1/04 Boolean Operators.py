# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Boolean Operators</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Boolean Operators.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_140_control_flow/topic_112_b1_boolean_operators.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Operators on Boolean values

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### When is a logical expression true?
#
# | Operator | Operation                      | `True` if...                   |
# |:--------:|:-------------------------------|:-------------------------------|
# | and      | logical "and" (conjunction)    | both arguments `True`          |
# | or       | logical "or" (disjunction)     | at least one argument `True`   |
# | not      | logical "not" (negation)       | argument `False`               |

# %% [markdown] lang="en"
# ### Chaining comparisons

# %%

# %%

# %%

# %%

# %% [markdown] lang="en"
# ## Mini workshop: Operators, comparisons
#
# Given the following variable definitions:

# %% tags=["keep"]
var1 = 3 ** (3 * 4)
var2 = 4**3**2
var3 = (3**3) ** 3
var4 = (2**3) ** 4

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Is `var1` divisible by `var3` and at the same time `var2` divisible by `var4`?

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Are the variables `var1`, `var2`, `var3` and `var4` arranged in ascending order,
# i.e., does `var1` < `var2` and `var2` < `var3` and `var3` < `var4` hold?

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Are the variables `var1`, `var2`, `var3` and `var4` arranged in descending order,
# i.e., does `var1` > `var2` and `var2` > `var3` and `var3` > `var4` hold?

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Is the value of `var4` between `1_000` and `10_000`?

# %%
