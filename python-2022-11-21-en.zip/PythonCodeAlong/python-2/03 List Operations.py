# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>List Operations</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 List Operations.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_150_collections/topic_112_b1_list_operations.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Modification of list entries

# %% tags=["keep"]
numbers = [2, 4, 6, 8]
numbers

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## List membership

# %% tags=["keep"]
numbers = [5, 6, 7]

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Length of a list

# %% tags=["keep"]
numbers = [2, 4, 6, 8]
numbers

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Methods on Lists
#
# - Many operations on lists are implemented as so-called *methods*.
# - A method is very similar to a function, but belongs to an object.
# - The "object to which the method belongs" precedes the method name.
# - The syntax is `object.my_method()`.
# - The meaning is similar to `my_method(object)`.
# - Many methods destructively alter the object they operate on.


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Inserting and deleting items
#
# - Insertion and deletion are possible at any position.
# - If possible you should insert and delete elements at the end of a list since this is
#   more efficient.

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Append vs. Extend

# %% tags=["keep"]
numbers = [2, 3, 4]

# %%

# %% tags=["keep"]
numbers = [2, 3, 4]

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Extend vs. `+`


# %% tags=["keep"]
numbers = [2, 3, 4]

# %%

# %%

# %% tags=["keep"]
numbers = [2, 3, 4]

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Deleting and inserting at arbitrary positions


# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Sorting lists
#
#
# - Lists can be sorted with the `sort()` method. This changes the order of
#   the elements in the list on which the method is called.
# - The `sorted()` function can be used to create a new list that contains the
#   elements of the original list in sorted order.

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
numbers = [3, 8, 6, 1, 9, 2, 5, 4]
numbers

# %%

# %%

# %% tags=["keep"]
numbers = [3, 8, 6, 1, 9, 2, 5, 4]
numbers

# %%

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Color (Teil 2)
#
# Given the following lists:

# %% lang="en" tags=["keep"]
primary_colors = ["red", "green", "blue"]
mixed_colors = ["cyan", "yellow"]
colors = primary_colors + mixed_colors

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Check if yellow is a primary color, i.e., if the string `"yellow"` is
#   contained in `colors`
# - Is green a primary color?

# %% lang="en"

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - How many elements does the list `primary_colors` have?
# - How many elements does the list `mixed_colors` have?

# %% lang="en"

# %% lang="en"


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We forgot to include magenta in the mixed colors.
#
# - Check that the string `"magenta"` is not in `mixed_colors`.
# - Add `Magenta` to the mixed colors.
# - Check that the string `"magenta"` is now contained in `mixed_colors`.
# - How long is the list `mixed_colors` now?

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% lang="en"

# %% lang="en"

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - Change the first element in `colors` to `dark red`
# - What is the first element of `primary_colors` after this change?

# %% lang="en"

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# What is the third element of the list `colors`?

# %% lang="en"

# %% [markdown] lang="en"
# Add `Purple` as the second item in the list `colors`.

# %% lang="en"

# %% [markdown] lang="en"
# What is now the third element of the list `colors`?

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Delete the second item of the `colors` list

# %% lang="en"

# %% [markdown] lang="en"
#
# Sort the list `colors`.

# %% lang="en"

# %% [markdown] lang="en"
# What is now the first element of the list `colors`?

# %% lang="en"
