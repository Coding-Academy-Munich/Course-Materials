# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Arbitrary numbers of function arguments</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">08 Arbitrary numbers of function arguments.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_130_functions/topic_220_a3_multiple_args.py</div> -->


# %% [markdown] tags=["private"]
# Requires lists and dicts

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Any number of function arguments:
#
# You can define functions that can take any number of arguments:

# %%

# %%

# %% [markdown] lang="en"
# ## Mini workshop
#
# Write a function `print_lines(*args)` that can take any number of arguments and prints them all, one argument per line:
# ```
# >>> print_lines("hey", "you")
# hey
# you
# ```

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# This can also be combined with other arguments:

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Any number of named arguments:
#
# Likewise, a function can have any number of named arguments:

# %%

# %%

# %% [markdown] lang="en"
# It is possible to combine these two features:

# %%

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Mini workshop
#
# Write a function `print_named_lines(**kwargs)` that can take any number of
# Keyword arguments and prints them in the following form:
# ```python
# >>> print_named_lines(foo="My Foo", bar="My Bar", quux="My Quux")
# Key: foo -- value: My Foo
# Key: bar -- value: My Bar
# Key: quux -- value: My Quux
# ```

# %%

# %% tags=["keep"]
print_named_lines(foo="My Foo", bar="My Bar", quux="My Quux")

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## "Splicing" of arguments
#
# - If you have a list `args`, you can pass its values as positional arguments using the syntax `*args`.
# - If you have a dictionary `kwargs`, you can pass its key-value pairs as named arguments with the syntax `**kwargs`:

# %%

# %%

# %%

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%
