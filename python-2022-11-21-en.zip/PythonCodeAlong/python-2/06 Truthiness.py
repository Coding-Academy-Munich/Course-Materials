# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Truthiness</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Truthiness.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_140_control_flow/topic_130_b3_truthiness.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Truthiness
#
# The `if` statement can take any Python value as an argument,
# not just Boolean values.
#
# The following values are considered *not true*
#
# - `None` and `False`
# - `0` and `0.0` (and null values of other number types)
# - Empty strings, sequences and collections: ``
# - Some values of user-defined data types
#
# All other values are considered true.


# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def check(value):
    if value:
        print(f"{value!r} is truthy.")
    else:
        print(f"{value!r} is falsy.")

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## How is this used?

# %%

# %%

# %%
# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Truthiness
#
# For which values of `x` is `len(x) - 1` falsy?

# %% [markdown] lang="en" tags=["answer"]
# *Answer:* 

# %% [markdown] lang="en"
#
# Give two example values with different types.

# %%

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Is there a string `s` for which `s[0]` is falsy?

# %% [markdown] lang="en" tags=["answer"]
# *Answer:* 

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Find three different arguments for which the function `is_truthy_and_falsy()`
# returns the value `True`.
#
# *Note:* Please don't ever write code like `is_truthy_and_falsy()`!


# %% tags=["keep"]
def is_truthy_and_falsy(x):
    if not (len(x) - 1) and not x[0]:
        return True
    else:
        return False

# %%

# %%

# %%
