# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Workshop: Grid World</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Workshop_ Grid World.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/projects/project_160_grid_world.py</div> -->


# %% [markdown] lang="en"
# # Grid World
#
# The following sections we want to implement the basic components of a
# 2D role-playing game.

# %% [markdown] lang="en"
# ## Rectangular playing field (`Level`)
# - The size (w x h) is set when creating the playing field
# - The playing field can change its width and length (width, height)
#   and return the number of fields (size).
# - Every single "square" in the playing field is represented by a `Location` object
# - Each location knows its neighbors in the 4 cardinal points
#   (N, E, S, W)
# - In the case of locations that are on the edge, neighbors in directions that
#   would lie outside the playing field, refer to the location itself
# - Each location knows its Cartesian coordinates (w, h)
# - Every location knows the `Level` instance to which it belongs

# %% [markdown] lang="en"
# ## Factory to create a playing field (`LevelFactory`)
# - Can create levels with different dimensions (and possibly different difficulties)
# - Uses a `LevelPopulationStrategy` to distribute objects in the level (depending on the
#   desired difficulty)
# - Implement only the interface for `LevelPopulationStrategy`, no concrete strategy
# - How can you test `LevelFactory` in this situation?

# %% [markdown] lang="en"
# ## Abstract character
# - Create an `AbstractCharacter` class, that provides the following functionality:
#   - Query the name of the character
#   - Query the location where the character is
#   - Move the character around the field
#   - Character death
# - All significant events of the `AbstractCharacter` should
#   be observable with observers (creation, move, death)
# - `AbstractCharacter` should be outside of the core ring.
#   How can you handle the dependencies correctly?

# %% [markdown] lang="en"
# ## LevelPopulationStrategy (1)
# - Write a `LevelPopulationStrategy`,
#   `LevelPopulationStrategy_LeaveLevelEmpty`, that creates a level without any additional
#   elements.

# %% [markdown] lang="en"
# ## Players/NPCs
# - Subclass `AbstractCharacter` for players
#   and NPCs
# - Each character should now also have the following functions:
#   - `getAttitudeTowardsPlayer()` (neutral, friendly, hostile)
#   - `tick()` to periodically advance the behavior
# - The behavior of NPCs should be controlled by a behavior strategy
# - The "instructions" of the behavior strategy should be implemented
#   in the form of the Command Pattern
# - Implement behaviors and commands that move an NPCs in a random direction
# - Implement a command that moves a character
#   in a specific direction (selectable when creating the command)
# - Implement a builder for NPCs

# %% [markdown] lang="en"
# ## LevelPopulationStrategy (2)
# - Write a `LevelPopulationStrategy`
#   `LevelPopulationStrategy_DistributeRandomElements`, which creates a playing field
#   populated with randomly placed friendly and hostile NPCs. The number of NPCs should
#   depend on the number of fields (`Level.size()`) and the difficulty
# - Implement a function `Character.attack(...)` to attack other characters

# %% tags=["keep"]
