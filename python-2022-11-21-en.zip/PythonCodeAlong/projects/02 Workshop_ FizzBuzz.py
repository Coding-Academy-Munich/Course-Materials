# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Workshop: FizzBuzz</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Workshop_ FizzBuzz.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/projects/project_110_fizzbuzz.py</div> -->


# %% [markdown] lang="en"
# ## Extra Credits: FizzBuzz
#
# Write a function `fizz_buzz(n)` that prints the numbers from 1 to `n` but
#
# - replaces any number divisible by 3 with `fizz`
# - replaces every number divisible by 5 with `buzz`
# - replaces every number divisible by 3 and 5 with `FizzBuzz`
#
# For example, `fizz_buzz(31)` should produce the following output:
#
# ```
# 1
# 2
# Fizz
# 4
# Buzz
# Fizz
# 7
# 8
# Fizz
# Buzz
# 11
# Fizz
# 13
# 14
# FizzBuzz
# 16
# 17
# Fizz
# 19
# Buzz
# Fizz
# 22
# 23
# Fizz
# Buzz
# 26
# Fizz
# 28
# 29
# FizzBuzz
# 31
# ```

# %%

# %%

# %% tags=["keep"]
