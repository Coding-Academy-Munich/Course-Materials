# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>NumPy Basics</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 NumPy Basics.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_600_numpy/topic_120_a5_np_basics.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# # NumPy Basics

# %% tags=["keep"]
import numpy as np

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Vectors


# %% tags=["keep"]
v1 = np.array([3.0, 2.1, 4.2])
v2 = np.array([8.0, 8.9, 6.8])

# %%

# %%

# %%

# %%

# %% tags=["keep"]
v3 = np.array([1, 2, 3])

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Computation with Vectors
#
# ### Basic operations

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Maximum and minimum

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Aggregate functions and statistics

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Matrices

# %% tags=["keep"]
m1 = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
m1

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Form of matrices and transposition

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Indexing matrices

# %% tags=["keep"]
m1 = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
m1

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Calculating with matrices

# %% tags=["keep"]
m1 = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
m1

# %% tags=["keep"]
m2 = np.array([[1.0, 0.0], [0.0, 1.0], [2.0, 3.0]])
m2

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
