# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Handling errors</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Handling errors.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_170_exceptions/topic_112_a1_handling_exceptions.py</div> -->


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We have defined the following function to calculate integer square roots, which
# throws a `ValueError` if `n` is not a square number:

# %% tags=["keep"]
def int_sqrt(n: int) -> int:
    for m in range(n + 1):
        if m * m == n:
            return m
    raise ValueError(f"{n} is not a square number.")


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We could then use this function like this:


# %% tags=["keep"]
def print_int_sqrt(n):
    root = int_sqrt(n)
    print(f"The root of {n} is {root}.")


# %% tags=["keep"]
print_int_sqrt(9)


# %% tags=["keep"]
# print_int_sqrt(8)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# How do we write a `print_int_sqrt()` function that does not throw
# an error if `n` is not a square number?

# %% tags=["start"]
def print_int_sqrt(n):
    root = int_sqrt(n)
    print(f"The root of {n} is {root}.")

# %%


# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Exception handling
#
# - Exceptions can be handled with a `try`/`except` block
# - Any "matching" exceptions thrown during the execution of the `try` block result
#   in the execution of the `except` block
# - We say the exception was handled
# - After handling the Exception, the program continues to run after the `try`/`except`
#   block


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Workshop: Bank accounts (part 2)
#
# We have defined a class `BankAccount` that raises a `ValueError` in the following
# cases:
#
# - If a new `BankAccount` with a negative `balance` is created.
# - If `deposit` is called with a negative value.
# - When `withdraw` is called with a negative value if by withdrawing
#   the desired amount the `balance` attribute of the account would become
#   negative.


# %% [markdown] lang="en"
#
# Test the functionality of the class for both successful transactions,
# as well as for transactions that throw exceptions.
# Handle the exceptions that are thrown and print a useful message.

# %% tags=["keep", "subslide"] slideshow={"slide_type": "subslide"}
class BankAccount:
    def __init__(self, balance):
        if balance < 0:
            raise ValueError(
                f"Cannot create an account with negative balance: {balance}."
            )
        self.balance = balance

    def __repr__(self):
        return f"BankAccount({self.balance:.2f})"

    def deposit(self, amount: float):
        if amount > 0:
            self.balance += amount
        else:
            raise ValueError(f"Cannot deposit a negative amount: {amount}")

    def withdraw(self, amount: float):
        if amount <= 0:
            raise ValueError(f"Cannot withdraw a negative amount: {amount}")
        if amount > self.balance:
            raise ValueError(
                f"Cannot withdraw {amount} because it exceeds "
                f"the current balance of {self.balance}."
            )
        self.balance -= amount

# %%

# %%

# %%

# %%

# %%

# %%

# %%

# %%
