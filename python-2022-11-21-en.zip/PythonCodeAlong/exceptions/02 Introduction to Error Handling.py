# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.0
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Introduction to Error Handling</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Introduction to Error Handling.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_170_exceptions/topic_108_a1_intro_error_handling.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Error handling
#
# We want to write a function `int_sqrt(n: int) -> int` that calculates the
# "integer square root":
# - If `n` is a square number, i.e. has the form `m * m`, then `m` should
#   be returned.
# - What do we do if `n` is not a square number?
# - Um den Mechanismus, den Python verwendet, zu motivieren, besprechen wir erst
#   zwei andere Möglichkeiten Fehler zu behandeln

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - We can try to return an "error value" that is not a valid
#   result.
# - Here, e.g., a negative number


# %%

# %%

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Using this implementation is simple, but error-prone:


# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - #rror-handling code is interwoven with the "success case"

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - We can also return two values: Result and a success/error flag

# %%

# %%

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# -The problems with this solution are similar to the previous one.


# %%

# %%

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Both approaches have several problems:
#  - Error handling is optional. If it is not carried out, the computation
#    proceeds with an incorrect value.
#  - If the caller cannot handle the error itself, the error must be passed
#    through (possibly) multiple levels of function calls.
#  - That leads to
#    confusing code because the "interesting" path is intermingled with code to
#    handle errors.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Normal program logic is not affected
# - Error handling is enforced
# - Error detection is decoupled from error handling
# - Information about the error can be easily communicated to the handler
