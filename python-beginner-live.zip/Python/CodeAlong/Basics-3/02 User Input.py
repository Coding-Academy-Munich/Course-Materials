# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>User Input</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 User Input.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_140_control_flow/topic_150_a3_user_input.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # User input
#
#  - The `input()` function allows the user to enter text.
#  - Optionally, it can output an input prompt.
#  - The function returns the text entered by the user *as a string*.

# %%


# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Example: Conversion of temperatures
#
# We want to write an application that will ask the user for a temperature
# in Fahrenheit and return the corresponding temperature in degrees Celsius.


# %% lang="en"

# %% lang="en"

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We have to manually convert the return value of `input()` to a number if we want
# to calculate with it.


# %%

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}


# %% lang="en"


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We can print a message if the user doesn't type anything (and
# make the output a little nicer):

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We can exploit truthiness in the `if` statement:

# %% lang="en" tags=["keep"]
def convert_temperature_3():
    fahrenheit = input("Please enter the temperature in Fahrenheit: ")
    if fahrenheit:
        celsius = convert_fahrenheit_to_celsius(float(fahrenheit))
        print(f"{fahrenheit}F are {celsius}°C")
    else:
        print("Please enter a valid temperature.")

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Conversion into miles
#
# Write a function `convert_km_to_miles(km)` that converts the value `km` from
# kilometers to miles (i.e. the value in miles is returned).
#
# *Note:*
# - One kilometer equals $0,621371$ miles

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Test `convert_km_to_miles(km)` for 1 and 5 km.

# %% lang="en"

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Write a function `miles_app()` that reads a length in kilometers from the user
# and prints out the equivalent distance in miles. If the user enters an empty
# string, `Please enter a valid distance in km.` should be printed on the
# screen.
#
# *Notes*
# - A string can be converted to a float value with `float()`.
# - Use truthiness in the condition of the `if`-Statement.

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}


# %% lang="en"
# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Cinema price
#
# The Python-Cinema has the following entrance fees:
#
# - Infants under 2 years are free.
# - Children from 2-12 years pay 2 euros.
# - Teenagers aged 13-17 pay 5 euros.
# - Adults pay 10 euros.
# - Pensioners (over 65) pay 6 euros.
#
# Write a function `cinema_price(age)` that returns the price in Euros a person with
# age `age` has to pay.


# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Test the function `cinema_price()` for some representative values.

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Write a function `print_cinema_price(age)`, that prints a text of the following
# type on the screen:
#
# ```
# You are 1 year old. Your price is 0 Euro.
# You are 15 years old. Your price is 5 Euro.
# ```

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Test `print_cinema_price()` for representative values.

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Write a function `cinema_app()` that reads in an age and prints the cinema price for a
# person of this age in the format just described. Two example interactions:
#
# ```
# How old are they? 37
# You are 37 years old. Their price is 10 euros.
#
# How old are they? 12
# You are 12 years old. Their price is 2 euros.
# ```

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}


# %% lang="en"

# %%
