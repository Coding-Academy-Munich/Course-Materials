# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Assignment to Slices</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">04 Assignment to Slices.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_150_collections/topic_135_b3_assignment_to_slices.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Assignment to slices
#
# You can assign values to slices:

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Changing Priorities
#
# Given the following list of priorities:

# %% lang="en" tags=["keep"]
priorities = ["very low", "chill, man", "extremely high"]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Change the list `priorities` to the following list by assigning to a slice:
# ```python
# ['very low', 'low', 'medium', 'high', 'extremely high']
# ```

# %% lang="en" tags=["keep"]
priorities

# %% lang="en"

# %% lang="en"

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Use assignment to a slice to replace the contents of `priorities` with the
# numbers `5, 4, 3, 2, 1`.
#
# *Note:* Use a range for this.

# %% lang="en"
