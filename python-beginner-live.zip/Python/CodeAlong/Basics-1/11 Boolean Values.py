# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Boolean Values</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">11 Boolean Values.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_140_control_flow/topic_110_b1_booleans.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Comparisons, Boolean values

# %% [markdown] lang="en"
# Equality of values is tested with `==`:

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# The result of a comparison is a boolean value
#
# - `True`
# - `False`

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Equality of numbers

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ### Caution: Rounding errors!

# %%

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Inequality of numbers
#
# The `!=` operator tests whether two numbers are different

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Comparison of numbers

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Comparison operators on other types
#
# The comparison operators can also be applied to many other types
# (more details later).

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ### The value `None`
#
# `None` is a value used by Python to indicate the absence of a useful value:
# Jupyter doesn't print `None` as a cell's value:

# %%

# %%

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The operator `is` is often used to check for `None` values:

# %%

# %% [markdown] lang="en"
#
# `is` checks for object identity and cannot generally be substituted for `==`.

# %% [markdown] lang="en"
# ## Mini workshop: Comparisons
#
# Is $2^{16}$ larger than $32\,000\,\,/\,\,2$?

# %%

# %% [markdown] lang="en"
# Is $72$ divisible by $3$ without a remainder?

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Given the following variable definitions:

# %% tags=["keep"]
var1 = 2**2**4
var2 = 3**12
var3 = 100 * 200 * 300
var4 = 4**3**2

# %% [markdown] lang="en"
#
# Is the maximum of `var1` and `var2` greater than the minimum of `var3` and `var4`?

# %%
