# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Classes</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">02 Classes.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_200_object_orientation/topic_120_a2_classes.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# # Custom data types
#
# Let us now turn to the definition of user-defined data types (classes):

# %%


# %% [markdown] lang="en"
#
# Class names are in pascal case (i.e. capital letters separate components of
# names), e.g. `MyVerySpecialClass`.

# %% [markdown] lang="en"
#
# In the following we will use
# [Python Tutor](https://tinyurl.com/python-classe-point-v0) to implement
# the `Point` class.

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Instances of custom classes are created by calling the class name as a function.
# Some built-in operators and Functions can be used without extra effort:


# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %% [markdown] lang="en"
#
# Much like dictionaries can be assigned new entries, one can assign new *attributes*
# to user-defined data types, but the `.` notation is used instead of the indexing
# notation `[]`:

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Unlike dictionaries, we typically *do not* create any *new* attributes for an
# instance after creation!
#
# Instead, all instances should have the same shape. We initialize all attributes of
# an object when it is constructed. This can be done with the `__init__()` method.
#
# The `__init__()` method always has (at least) one parameter, named `self` by
# convention:

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# The values of attributes can be changed:

# %%

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# In many cases, when constructing an object, we would like to specify the attributes
# of the instance. This is made possible by passing additional arguments to the
# `__init__()` method.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# # Motor Vehicles (Part 1)
#
# Define a class `MotorVehicle` whose instances describe motor vehicles.
# Every car should have attributes `manufacturer` and `license_plate`.


# %% lang="en"

# %% [markdown] lang="en"
# Create two motor vehicles:
# - a BMW with license plate "M-BW 123"
# - a VW with license plate "WOB-VW 246"
# and store them in variables `bmw` and `vw`

# %% lang="en"

# %% [markdown] lang="en"
# Create a new instance of `MotorVehicle` with manufacturer BMW and registration number
# "M-BW 123" and store it in a variable `bmw2`.

# %% lang="en"

# %% [markdown] lang="en"
#
# How can you determine whether `bmw` and `bmw2` (or `bmw` and `vw`) describe
# the same vehicle?

# %% lang="en"

# %% lang="en"
