# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Workshop: Employees
#
# In the following we will implement a class hierarchy for employees of a company:
#
# - Employees can be either workers or managers
# - Each employee of the company has a name, a personnel number and a
#   base salary
# - For each worker, the accumulated overtime and the hourly wage
#   are stored in attributes.
# - A worker's salary is calculated as 13/12 times the
#   base salary plus overtime pay
# - Each manager has an individual bonus
# - A manager's salary is calculated as 13/12 times the
#   base salary plus bonus
#
# Implement Python classes `Employee`, `Worker` and `Manager` with
# appropriate attributes and a method `salary()` that calculates the salary.

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}

# %%

# %%

# %%

# %% [markdown]
#
# Create a worker named Hans, personnel number 123, a base salary of
# 36000.0 Euros, who worked 3.5 hours of overtime at 40.0 euros each.
# Print out the salary.

# %%

# %% [markdown]
#
# Schreiben sie Assertions, die die Funktionalität der Klasse `Worker` testen.

# %% [markdown]
#
# Write assertions to test the functionality of the class `Worker`.

# %%

# %% [markdown] lang="en"
# Create a manager named Sepp, personnel number 834, who is a
# base salary of 60000.0 euros and a bonus of 30000.0 euros. Print out
# the salary.

# %%

# %% [markdown] lang="en"
# Test the functionality of the class `Manager`.

# %%

# %%

# %%
