# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Control Structures</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">06 Control Structures.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_140_control_flow/topic_120_b1_control_flow.py</div> -->
#
#

# %% [markdown] lang="en"
# # `if` statements
#
# - We want to write a program that determines if a number is a lucky number or not:
#     - 7 is a lucky number
#     - all other numbers are not.
# - We need the `if` statement for this:

# %% tags=["subslide"] lang="en" slideshow={"slide_type": "subslide"}
def is_lucky_number(number):
    if number == 7:
        print("lucky number")
    else:
        print("not a lucky number")


# %% lang="en"
is_lucky_number(1)

# %% lang="en"
is_lucky_number(7)


# %% lang="en" tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def is_lucky_number_1(number):
    print("Is", number, "a lucky number?")

    if number == 7:
        print("Yes!")
    else:
        print("Unfortunately no.")

    print("We wish you all the best.")


# %% lang="en" tags=["keep"]
is_lucky_number_1(1)

# %% lang="en" tags=["keep"]
is_lucky_number_1(7)


# %% lang="en" tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
def is_lucky_number_2(number):
    if number == 7:
        print(number, "is a lucky number!")
        print("You must be having a great day!")
    else:
        print(number, "is unfortunately not a lucky number.")
        print("Maybe you should stay in bed today.")
        print("We wish you all the best anyway.")


# %% lang="en" tags=["keep"]
is_lucky_number_2(1)

# %% lang="en" tags=["keep"]
is_lucky_number_2(7)

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Structure of an `if` statement (incomplete):
#
# ```python
# if <condition>:
#     # Body that runs if <condition> is true
# else:
#     # Body that is executed if <condition> is false
# ```
# - Only the `if` and the first body are necessary
# - If an `else` is present, the corresponding body must not be empty

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini workshop: Adult

# %% [markdown] lang="en"
#
# Write a function `print_of_age(age)` that prints `of age` on the screen if
# `age >= 18` and `minor` otherwise.

# %% lang="en"
def print_of_age(age):
    if age < 18:
        print("minor")
    else:
        print("of age")


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Test `print_of age(age)` with the values 17 and 18.

# %% lang="en"
print_of_age(17)
print_of_age(18)
# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Even number

# %% [markdown] lang="en"
#
# Write a function `is_even(number)` that returns `True`,
# if `number` is even and `False` if `number` is odd.

# %% lang="en"
def is_even(number):
    return number % 2 == 0


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Write assertions that check that `is_even()` returns the correct result
# for arguments 0, 1 and 8.

# %% lang="en"
assert is_even(0)
assert not is_even(1)
assert is_even(8)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Write a function `print_is_even(number)` that
#
# - prints `{number} is even.` on the screen if `number` is even and
# - Prints `{number} is odd.` to the screen if `number` is not
#   is straight.
#
# Use the `is even()` function to check if `number` is even.

# %% lang="en"
def print_is_even(number):
    if is_even(number):
        print(f"{number} is even.")
    else:
        print(f"{number} is odd.")


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Test `print_is_even(number)` with the values 0, 1 and 8.

# %% lang="en"
print_is_even(0)
print_is_even(1)
print_is_even(8)

# %%
# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-Workshop: Shortened output


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Write a function `fits_in_line(text: str, line_length: int = 72)`,
# which returns `True` or `False` depending on whether `text` fits into a line of
# length `line_length`:
# ```python
# >>> fits_in_line("Hello")
# True
# >>> fits_in_line("Hello", 3)
# False
# ```
#
# *Note:* You can determine the length of a string using the `len()` function:
# ```python
# >>> len("abcd")
# 4
# ```

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def fits_in_line(text: str, line_length: int = 72):
    return len(text) <= line_length


# %%
fits_in_line("Hello")

# %%
fits_in_line("Hello", 3)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Write a function `print_line(text: str, line_length:int = 72)`,
# that
# * prints `text` to the screen if that is possible in a line of length
#   `line_length`
# * prints `...` if that is not possible.
#
# ```python
# >>> print_line("Hello")
# Hello
# >>> print_line("Hello", 3)
# ...
# >>>
# ```

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def print_line(text: str, line_length: int = 72):
    if fits_in_line(text, line_length=line_length):
        print(text)
    else:
        print("...")


# %%
print_line("Hallo")

# %%
print_line("Hallo", 3)
