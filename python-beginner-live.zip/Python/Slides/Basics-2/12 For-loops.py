# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>For-loops</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">12 For-loops.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_150_collections/topic_120_b1_for_loops.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Iteration over lists
#
# In Python, you can iterate over lists using the `for` loop.
#
# The `for` loop corresponds to the range-based for from C++,
# `for-in`/`for-of` from JavaScript or the `for-each` loop
# from Java, not the classic `for` loop
# from C, C++ or Java.

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
number_list = [0, 1, 2, 3, 4]
number_list

# %%
for number in number_list:
    print("Number is:", number)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Syntax of `for` loops
#
# ```pythons
# for <element-var> in <list>:
#     <body>
# ```

# %% [markdown] lang="en"
# ### Mini workshop
#
# Write a function `print_all(items: list)` that prints the elements of a
# list `items` to the screen, one item per line:
#
# ```python
# >>> print_all([1, 2, 3])
# 1
# 2
# 3
# >>>
# ```
# What happens if you call the function with a string as an argument,
# e.g. `print_all("abc")`

# %% tags=["subslide"] slideshow={"slide_type": "subslide"}
def print_all(items: list):
    for item in items:
        print(item)


# %%
print_all([1, 2, 3])

# %%
print_all("abc")  # type: ignore

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Workshop: Shopping List
#
# Define variables
# - `my_shopping list` holding a list containing the strings `tea` and `coffee`
# - `another_shopping list`, holding a different list also containing the
#   strings `tea` and `coffee`

# %% lang="en"
my_shopping_list = ["tea", "coffee"]
another_shopping_list = ["tea", "coffee"]


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Define a function `print_shopping_list(shopping_list)` that prints the
# shopping list passed as argument:
#
# ```
# Shopping List:
#   tea
#   coffee
# ```

# %% lang="en"
def print_shopping_list(shopping_list):
    print("Shopping List:")
    for item in shopping_list:
        print(" ", item)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Test the function `print_shopping list(shopping list)` with both
# shopping lists.

# %% lang="en"
print_shopping_list(my_shopping_list)

# %% lang="en"
print_shopping_list(another_shopping_list)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# Define a function `buy(product, shopping_list)`, that adds `product` to
# `shopping_list`.

# %% lang="en"
def buy(product, shopping_list):
    shopping_list.append(product)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Add `butter` and `bread` to the shopping list `my_shopping_list`.

# %% lang="en"
buy("butter", my_shopping_list)
buy("bread", my_shopping_list)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Print out both shopping lists again.

# %% lang="en"
print_shopping_list(my_shopping_list)

# %% lang="en"
print_shopping_list(another_shopping_list)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# What happens when you add `butter` and `bread` to the shopping list
# `my_shopping list` again?

# %% lang="en"
buy("butter", my_shopping_list)
buy("bread", my_shopping_list)
print_shopping_list(my_shopping_list)
