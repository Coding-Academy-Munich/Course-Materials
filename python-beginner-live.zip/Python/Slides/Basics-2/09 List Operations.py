# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>List Operations</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">09 List Operations.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_150_collections/topic_112_b1_list_operations.py</div> -->


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Modification of list entries

# %% tags=["keep"]
numbers = [2, 4, 6, 8]
numbers

# %%
numbers[1]

# %%
numbers[1] = 10
numbers

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## List membership

# %% tags=["keep"]
numbers = [5, 6, 7]

# %%
5 in numbers

# %%
3 in numbers

# %%
3 not in numbers

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# ## Length of a list

# %% tags=["keep"]
numbers = [2, 4, 6, 8]
numbers

# %%
len(numbers)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Methods on Lists
#
# - Many operations on lists are implemented as so-called *methods*.
# - A method is very similar to a function, but belongs to an object.
# - The "object to which the method belongs" precedes the method name.
# - The syntax is `object.my_method()`.
# - The meaning is similar to `my_method(object)`.
# - Many methods destructively alter the object they operate on.


# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# ## Inserting and deleting items
#
# - Insertion and deletion are possible at any position.
# - If possible you should insert and delete elements at the end of a list since this is
#   more efficient.

# %%
numbers = [2, 3, 4]
numbers.append(10)
numbers

# %%
numbers = [2, 3, 4]
numbers.extend([10, 20])
numbers

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Append vs. Extend

# %% tags=["keep"]
numbers = [2, 3, 4]

# %%
numbers.append([10, 20])
numbers

# %% tags=["keep"]
numbers = [2, 3, 4]

# %%
numbers.extend([10, 20])
numbers

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Extend vs. `+`


# %% tags=["keep"]
numbers = [2, 3, 4]

# %%
numbers.extend([10, 20])

# %%
numbers

# %% tags=["keep"]
numbers = [2, 3, 4]

# %%
numbers + [50, 60]

# %%
numbers

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ### Deleting and inserting at arbitrary positions


# %%
numbers = [2, 3, 4, 5]
numbers.pop()
numbers

# %%
numbers.insert(1, 10)
numbers

# %%
numbers.pop(1)
numbers

# %%
del numbers[1]
numbers

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Sorting lists
#
#
# - Lists can be sorted with the `sort()` method. This changes the order of
#   the elements in the list on which the method is called.
# - The `sorted()` function can be used to create a new list that contains the
#   elements of the original list in sorted order.

# %% tags=["subslide", "keep"] slideshow={"slide_type": "subslide"}
numbers = [3, 8, 6, 1, 9, 2, 5, 4]
numbers

# %%
numbers.sort()

# %%
numbers

# %% tags=["keep"]
numbers = [3, 8, 6, 1, 9, 2, 5, 4]
numbers

# %%
sorted(numbers)

# %%
numbers


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Color (Teil 2)
#
# Given the following lists:

# %% lang="en" tags=["keep"]
primary_colors = ["red", "green", "blue"]
mixed_colors = ["cyan", "yellow"]
colors = primary_colors + mixed_colors

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - Check if yellow is a primary color, i.e., if the string `"yellow"` is
#   contained in `colors`
# - Is green a primary color?

# %% lang="en"
"yellow" in primary_colors

# %% lang="en"
"green" in primary_colors

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# - How many elements does the list `primary_colors` have?
# - How many elements does the list `mixed_colors` have?

# %% lang="en"
len(primary_colors)

# %% lang="en"
len(mixed_colors)


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# We forgot to include magenta in the mixed colors.
#
# - Check that the string `"magenta"` is not in `mixed_colors`.
# - Add `Magenta` to the mixed colors.
# - Check that the string `"magenta"` is now contained in `mixed_colors`.
# - How long is the list `mixed_colors` now?

# %% lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
"magenta" in mixed_colors

# %% lang="en"
mixed_colors.append("magenta")

# %% lang="en"
"magenta" in mixed_colors

# %% lang="en"
len(mixed_colors)

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# - Change the first element in `colors` to `dark red`
# - What is the first element of `primary_colors` after this change?

# %% lang="en"
colors[0] = "dark red"
colors

# %% lang="en"
primary_colors[0]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# What is the third element of the list `colors`?

# %% lang="en"
colors[2]

# %% [markdown] lang="en"
# Add `Purple` as the second item in the list `colors`.

# %% lang="en"
colors.insert(1, "Purple")

# %% [markdown] lang="en"
# What is now the third element of the list `colors`?

# %% lang="en"
colors[2]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Delete the second item of the `colors` list

# %% lang="en"
colors.pop(1)
colors

# %% [markdown] lang="en"
#
# Sort the list `colors`.

# %% lang="en"
colors.sort()
colors

# %% [markdown] lang="en"
# What is now the first element of the list `colors`?

# %% lang="en"
colors[0]
