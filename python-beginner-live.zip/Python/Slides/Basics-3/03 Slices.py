# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
# ---

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
#
# <div style="text-align:center; font-size:200%;">
#   <b>Slices</b>
# </div>
# <br/>
# <div style="text-align:center;">Dr. Matthias Hölzl</div>
# <br/>
# <!-- <div style="text-align:center;">03 Slices.py</div> -->
# <!-- <div style="text-align:center;">python_courses/slides/module_150_collections/topic_130_b3_slices.py</div> -->
#
#

# %% [markdown] lang="en" tags=["slide"] slideshow={"slide_type": "slide"}
# ## Slices
#
# With the notation `list[m:n]` you can extract a "sublist" of `list`.
#
# - The first element is `list[m]`
# - The last element is `list[n-1]`

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Simple slices

# %% tags=["keep"]
string_list = ["a", "b", "c", "d", "e"]

# %%
string_list[1:3]

# %%
string_list[1:1]

# %%
string_list[0 : len(string_list)]

# %%
string_list[0:100]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Slices without end values

# %% tags=["keep"]
string_list = ["a", "b", "c", "d", "e"]

# %%
string_list[:3]

# %%
string_list[1:]

# %%
string_list[:]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Slices with Stride $>$ 1


# %% tags=["keep"]
string_list = ["a", "b", "c", "d", "e", "f", "g", "h"]
string_list[1], string_list[7]

# %%
string_list[1:7:2]

# %%
string_list[1:8:2]

# %%
string_list[1::2]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Slices with negative stride


# %% tags=["keep"]
string_list = ["a", "b", "c", "d", "e"]
string_list[1], string_list[4]

# %%
string_list[4:1:-1]

# %%
string_list[4:0:-1]

# %%
string_list[4:-1:-1]

# %%
string_list[4::-1]

# %%
list(reversed(string_list))

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
#
# ## Mini-workshop: Slices
#
# Given the following list:

# %% tags=["keep"]
my_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Extract from `my_list` a list with all elements except the first two.

# %%
my_list[2:]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# From `my_list` extract a list consisting of the 2nd and 3rd elements.

# %%
my_list[1:3]

# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Extract from `my_list` a new list containing all elements except the
# first and last contains.

# %%
my_list[1:-1]


# %% [markdown] lang="en" tags=["subslide"] slideshow={"slide_type": "subslide"}
# Extract from `my_list` a new list containing all elements with odd index
# (i.e. the elements at position 1, 3, 5, 7 and 9).

# %%
my_list[1::2]
